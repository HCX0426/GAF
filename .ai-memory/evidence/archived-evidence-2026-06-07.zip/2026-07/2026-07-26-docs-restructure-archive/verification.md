# Verification

## 验证步骤

### 1. check_doc_path_drift 0 violations
```
$ conda run -n gaf python scripts/hooks/check_doc_path_drift.py --no-fail
[doc-path-drift] scanning 1757 files under D:\code\GAF
[doc-path-drift] 0 violation(s), 294 file(s) skipped (whitelist)
```
✅ 通过：归档后白名单扩展生效，0 violations。

### 2. docs-index.md 路径更新
```
$ grep "2026-07-25-docs-ai-memory-restructure" .ai-memory/meta/docs-index.md
33:- `docs/plans/archived/2026-07/2026-07-25-docs-ai-memory-restructure.md`
35:- `docs/specs/archived/2026-07/2026-07-25-docs-ai-memory-restructure.md`
```
✅ 通过：docs-index.md 已更新到 archived/ 路径。

### 3. pre-commit governance batch Passed (10 checks)
```
$ conda run -n gaf python -m pre_commit run gaf-governance-batch --all-files
GAF governance batch (10 checks, single venv — 3.2x speedup).......................Passed
```
✅ 通过：10 项 governance check 全部 PASS。

### 4. backend pytest 全通过 (commit 41a64e86 时验证)
```
$ conda run -n gaf python -m pytest backend/ -x -n 8 -q
2039 passed, 3 warnings in 252.02s (0:04:12)
```
✅ 通过：2039 个测试全部通过。

### 5. agent pytest 全通过 (commit 41a64e86 时验证)
```
$ conda run -n gaf python -m pytest agent/tests/ -x -q
1806 passed, 2 skipped in 163.78s (0:02:43)
```
✅ 通过：1806 个测试全部通过。

### 6. plan §9 待办清单全部 [x] 完成
- [x] §2 实施前实测确认
- [x] §3 P0 阶段实施 (commit b9c4b3e0)
- [x] §3.3 P0 验证清单全部通过
- [x] §4 P1 阶段实施 (commit ee4fb4e1)
- [x] §4.3 P1 验证清单全部通过
- [x] §5 P2 阶段实施 (commit 41a64e86)
- [x] §5.3 P2 验证清单全部通过 (9/10 项 + 第 7 项 start_gaf.sh 不跑)
- [x] §9.1 中途发现的问题修复
- [x] §9.2 实施完成后归档
- [x] plan 文档归档
- [x] spec 文档归档
- [x] 承载体文档归档

✅ 通过：spec 2026-07-25-docs-ai-memory-restructure 全部闭环。

## 闭环 commit 历史
- P0: b9c4b3e0 (双线索建立 + spec 目录合并)
- P1: ee4fb4e1 (lessons 改名 + evidence active/archived + 自我进化)
- P2: 41a64e86 (根目录收敛 + 引用同步 hook + 文档同步检查)
- 归档: <this commit> (spec/plan/承载体归档 + 修复记录 + 白名单扩展)
