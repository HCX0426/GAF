# Solution

## 修复方案

### 1. 归档操作 (4 个 git mv)
- `docs/plans/2026-07-25-docs-ai-memory-restructure.md` → `docs/plans/archived/2026-07/`
- `docs/specs/active/2026-07-25-docs-ai-memory-restructure.md` → `docs/specs/archived/2026-07/`
- `.ai-memory/spec-context/2026-07-25-docs-restructure-context.md` → `.ai-memory/evidence/archived/2026-07/`
- `.ai-memory/evidence/active/2026-07-26-docs-restructure-p0/` → `.ai-memory/evidence/archived/2026-07/2026-07-26-docs-restructure-p0/`

### 2. plan 文档新增 §9.1 + §9.2 章节
- §9.1 中途发现与修复记录: P0 (4 项) + P1 (7 项) + P2 (9 项) + 共性问题汇总 (3 条教训)
- §9.2 实施完成后归档清单: 4 个归档操作 + 归档前/后必做事项
- §9 待办清单全部 [x] 完成

### 3. check_doc_path_drift.py 白名单扩展
新增白名单片段：
- `docs/specs/archived/` — 历史 spec 归档
- `docs/plans/archived/` — 历史 plan 归档
- `.ai-memory/evidence/archived/` — 归档 evidence 含旧路径作为历史记录

### 4. 索引同步 (auto-regenerated)
- `conda run -n gaf python scripts/bootstrap/sync_docs_index.py` → docs-index.md 41 docs indexed, 0 stale
- `conda run -n gaf python scripts/governance/sync_spec_index.py` → spec-index.md 重新生成

## 关键决策

**Q: 为什么 [skip-doc-sync] 跳过 R4 规则？**
A: R4 规则检测「模块重命名/删除 → 全仓库引用同步」。归档操作 4 个 git mv 触发 R 状态，但路径变化是归档合理结果，且已跑 sync_docs_index + sync_spec_index + check_doc_path_drift (0 violations) 完成索引同步。R4 的本意是防止意外重命名导致引用断裂，归档操作不属于此场景。

**Q: 为什么归档到 2026-07/ 而不是 2026-07-26/？**
A: 归档按月组织（YYYY-MM），与 evidence/archived/ 现有结构一致（2026-06/、2026-07/）。日级粒度会导致归档目录过多。
