# Problem

## 症状
spec 2026-07-25-docs-ai-memory-restructure P0/P1/P2 三阶段全部实施完成，但 spec/plan/承载体文档仍位于 active/ 路径下，未归档。同时 plan 文档缺少中途发现问题的修复记录章节，无法满足 spec §6.3 P2 验证清单第 11 项「实施复盘」要求。

## 影响
- 文档生命周期不闭环：active/ 路径堆积已完成 spec/plan，影响 AI 加载效率
- 中途发现的问题无记录：P0/P1/P2 实施期发现的 20 个问题（P0: 4 + P1: 7 + P2: 9）未沉淀，下次类似重构会重复踩坑
- check_doc_path_drift.py 白名单不足：归档后 spec/plan 文档移到 archived/，未加白名单导致 192 violations 误报

## 复现
```
$ conda run -n gaf python scripts/hooks/check_doc_path_drift.py --no-fail
[doc-path-drift] 192 violation(s), 294 file(s) skipped (whitelist)
```
