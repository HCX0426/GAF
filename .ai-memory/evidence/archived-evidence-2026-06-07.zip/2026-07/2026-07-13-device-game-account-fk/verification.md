---
maintainer: AI
source: GAF task 1.4 — Device.game_account FK
load_when: [evidence, 3-step-evidence]
priority: medium
symptom: [window-centric, device-model, game-account-fk, runtime-binding]
solution: TDD 5-step — write failing test, add FK, generate migration, run tests, commit
related_files:
  - backend/agents/models.py
  - backend/agents/migrations/0013_device_game_account_fk.py
  - backend/tasks/tests/test_window_centric_models.py
created_by: AI
last_updated: 2026-07-13
---
## Verification（验证）

### V1: Failing test before implementation (TDD red)

$ conda run -n gaf python -m pytest backend/tasks/tests/test_window_centric_models.py::DeviceFieldsTest -v
预期：1 failed (test_device_has_game_account_fk), 1 passed (test_device_retains_game_profile_fk)
实测：FAILED as expected — "Device.game_account FK should be added"

### V2: Migration generated and applied

$ cd backend && conda run -n gaf python manage.py makemigrations agents --name device_game_account_fk
预期：生成 0013_device_game_account_fk.py
实测：agents\migrations\0013_device_game_account_fk.py created

$ cd backend && conda run -n gaf python manage.py migrate agents
预期：Applying agents.0013_device_game_account_fk... OK
实测：OK

### V3: All tests pass after implementation (TDD green)

$ conda run -n gaf python -m pytest backend/tasks/tests/test_window_centric_models.py -v
预期：10 passed (8 prior + 2 new DeviceFieldsTest)
实测：10 passed in 22.84s

### V4: Commit verifies pre-commit hooks pass

$ git commit -m "feat(agents): add Device.game_account FK for runtime binding"
预期：pre-commit hooks 全部通过，commit 创建成功
