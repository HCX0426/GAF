# TD-014 Solution

## Approach: Option B (consumer inline translation)

Frontend continues to send DB numeric Device.id values (consistent with `device.id` used elsewhere). The backend consumer translates them to agent-side device_id strings before forwarding to the agent. This is transparent to the frontend — no new API endpoint needed.

## Changes

### Backend: `backend/protocol/consumers.py`
- Added `Optional` to typing imports
- Modified `screenshot_stream_control` method: when `device_ids` is non-empty, call new `_map_db_device_ids_to_agent` to translate DB ids → agent device_id strings before building the agent payload
- Added `_map_db_device_ids_to_agent(self, db_device_ids) -> Optional[list[str]]`:
  - Queries `Agent` by `self.agent_id`, returns None if unknown
  - Normalizes ids to int (skips invalid)
  - Queries `Device.objects.filter(agent=agent, id__in=int_ids)`
  - Constructs agent device_id strings:
    - Windows + window_handle → `f"windows-hwnd-{hwnd}"`
    - Windows + no handle → `f"windows-title-{dev.name}"`
    - Emulator → `str(dev.id)`
  - Returns None if no matches (so consumer falls back to passing original ids)

### Frontend: `frontend/src/pages/Devices/DeviceCenterPage.tsx`
- Added `streamDeviceIds: number[]` state (empty = all devices, backward compatible)
- Added multi-select `Select` (mode="multiple") in the toolbar showing all devices with type emoji + name
- Modified auto-start stream `useEffect`: dependency array includes `streamDeviceIds`, payload includes `device_ids` when non-empty
- Modified `handleRefreshStream` callback: includes `device_ids` in stop+start payloads when non-empty

### i18n: `frontend/src/i18n/locales/deviceCenter.ts`
- Added 3 keys × 4 locales (zh-CN, en-US, ja-JP, ko-KR):
  - `stream_filter_label` — aria-label / select label
  - `stream_filter_all` — "all devices" option text
  - `stream_filter_placeholder` — placeholder when nothing selected

### Tests: `backend/protocol/tests/test_screenshot_stream_control.py`
- 10 unit tests covering:
  - No agent_id (pre-register) → None
  - Unknown agent → None
  - Empty input → None
  - Invalid ids skipped → None
  - Windows with handle → `windows-hwnd-{hwnd}`
  - Windows without handle → `windows-title-{name}`
  - Emulator → `str(device.id)`
  - Mixed devices (set comparison, order-insensitive)
  - String numeric ids accepted (parsed to int)
  - Cross-agent isolation (devices from other agent excluded)

## Backward Compatibility
- Empty `streamDeviceIds` = all devices (no `device_ids` in payload, same as before)
- Backend `device_ids=None` or `[]` = all devices (no translation, same as before)
- Existing global "refresh stream" button still works (now respects filter)
