# TD-014 Problem

## Symptom
P-004 R37-P2 A3 added `deviceIds?: string[]` param to `useScreenshotStream` hook and `framesByDevice` state, and the backend consumer transparently passes through `device_ids`. However, A3 only added a global "refresh stream" button — no per-device filter UI. The root cause is an identifier-layer mismatch: frontend `Device.id` is a DB numeric PK, but the agent's `device.device_id` is a constructed string (`windows-hwnd-{hwnd}`, `windows-title-{name}`, or `str(device.id)` for emulators). The backend had a forward mapping (`_map_agent_device_id` for screenshot_frame → frontend) but no reverse mapping (DB Device.id → agent device_id string for request_screenshot_stream → agent).

## Impact
- Per-device screenshot stream filter UI unavailable — user can only globally start/stop the entire agent's stream, cannot "watch only one device"
- Partially mitigated by TD-009 dedup (static frames not resent), but multi-device still needs N × capture_time sequential processing
- Does not block core functionality, only affects fine-grained control in multi-device scenarios

## Root Cause
Identifier layer difference between DB (numeric PK) and agent (constructed string). Reverse mapping query/logic was missing in the backend consumer.
