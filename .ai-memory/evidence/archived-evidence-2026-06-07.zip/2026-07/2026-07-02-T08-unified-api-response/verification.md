# T08 Verification

- `ruff check core/` — passed with no errors.
- `pytest core/tests/test_responses.py -v` — 15 tests passed.
- `python manage.py check --settings=config.settings.dev` — no issues.
- `pytest accounts/tests/test_accounts.py -q` — 16 existing tests passed,
  confirming the default disabled mode preserves native DRF behavior.
- `mypy core/` — blocked by pre-existing environment issue
  `Plugin "mypy_django_plugin" does not define entry point function "plugin"`,
  unrelated to this change.
