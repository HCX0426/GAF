# T08 Problem

The GAF API used DRF's default response format with no unified envelope and no
application-level error codes. Frontend and agent clients had to inspect HTTP
status codes and heterogeneous DRF error shapes (`detail`, field-level dicts,
etc.), which complicates client-side error handling and makes i18n harder.

The API contract (`docs/standards/api-contract.md`) and backend conventions
(`docs/standards/backend-conventions.md`) already documented the target shape
`{ code, message, data }` and 4-digit error codes, but no implementation existed.
