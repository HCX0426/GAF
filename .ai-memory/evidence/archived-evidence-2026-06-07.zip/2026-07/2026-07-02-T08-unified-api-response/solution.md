# T08 Solution

Created a new Django app `core` with the unified response infrastructure:

- `core/error_codes.py` — `ErrorCode` enum defining 4-digit codes by area:
  0 success, 1xxx generic, 2xxx auth, 3xxx business, 4xxx rate-limit,
  5xxx third-party.
- `core/responses.py` — `unified_response(...)` helper producing the
  `{ code, message, data }` envelope.
- `core/exceptions.py` — `BusinessException` for business errors and
  `unified_exception_handler` for DRF exceptions. The handler maps standard DRF
  exceptions to 4-digit codes.
- `core/middleware.py` — `UnifiedResponseMiddleware` wraps JSON responses in the
  unified envelope when enabled.
- `core/tests/test_responses.py` — unit and integration tests covering the
  helper, exception handler, middleware, and a real DRF login endpoint.

Wired everything into `config/settings/base.py`:
- Added `"core"` to `INSTALLED_APPS`.
- Added `core.middleware.UnifiedResponseMiddleware` to `MIDDLEWARE`.
- Set `REST_FRAMEWORK["EXCEPTION_HANDLER"]` to `core.exceptions.unified_exception_handler`.
- Added `GAF_UNIFIED_RESPONSE_ENABLED` setting (default `False`) so existing
  clients keep the native DRF format until they opt in.

Updated `docs/standards/api-contract.md` and `docs/standards/backend-conventions.md`
to reflect the implemented, gated behavior.
