---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, verification-step, evidence-verification]
solution: Verification — agent 2026 通过 + backend 823 通过 (共 2849 用例全绿)
related_files:
  - .ai-memory/evidence/2026-07-27-execution-path-unification/problem.md
  - .ai-memory/evidence/2026-07-27-execution-path-unification/solution.md
  - agent/tests/test_engine_node_control_flow.py
  - agent/tests/test_parser_linear_mode.py
  - backend/tasks/tests/test_tasks.py
created_by: AI
last_updated: 2026-07-27
---
## Verification（验证）

$ conda run -n gaf python -m pytest agent/tests/ --tb=short -q
$ conda run -n gaf python -m pytest backend/tasks/tests/ backend/protocol/tests/ backend/executions/tests/ backend/pipeline/tests/ backend/scheduler/tests/ backend/tests/test_integration.py --tb=short -q

预期：agent 2026 passed, 2 skipped；backend 823 passed, 1 warning；共 2849 用例全绿
