---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, solution-step, evidence-solution]
solution: Solution — 执行路径归一化：chain 并入 pipeline 引擎
related_files:
  - .ai-memory/evidence/2026-07-27-execution-path-unification/problem.md
  - .ai-memory/evidence/2026-07-27-execution-path-unification/verification.md
  - agent/src/core/orchestrator.py
  - agent/src/engine/node.py
  - agent/src/engine/parser.py
  - backend/tasks/migrations/0049_chain_to_pipeline_unification.py
created_by: AI
last_updated: 2026-07-27
---
## Solution（解决步骤）

1. 删除 chain 死代码：`agent/src/core/chain.py` + orchestrator 的 `_execute_chain`/`_execute_step`/`_run_action`/`_handle_retry`/`_handle_fallback`
2. PipelineNode 扩展字段：`agent/src/engine/node.py` 新增 pre_verify/post_verify/retry/fallback/continue_on_error
3. Parser 支持线性模式：`agent/src/engine/parser.py` 无 edges 时按 nodes 顺序自动链接
4. handler 入口归一：`agent/src/client/handler.py` handle_task_assign 委托 execute_pipeline
5. 数据迁移：`backend/tasks/migrations/0049_chain_to_pipeline_unification.py` chain→pipeline schema 转换
