---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, problem-step, evidence-problem]
solution: Problem — GAF 有两条执行路径 (chain/pipeline)，能力不对等且代码重复
related_files:
  - .ai-memory/evidence/2026-07-27-execution-path-unification/solution.md
  - .ai-memory/evidence/2026-07-27-execution-path-unification/verification.md
  - scripts/check_3step_evidence.py
created_by: AI
last_updated: 2026-07-27
---
## Problem（症状 / 触发条件）

GAF 任务执行有两条路径（chain / pipeline），存在架构盲区：
1. 现象：chain 模式任务（如 BD2 登录）通过 `_execute_chain` 执行，未接入 StructuredLogger，导致主流任务无 JSONL 结构化日志
2. 触发条件：执行 chain 模式任务时，AI 诊断工具无法读取 JSONL 日志
3. 影响范围：所有 chain 模式任务（BD2 登录等主流任务），`execution_snapshot.structured_log_path` 字段永远为空
