---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-21-spec57-td295-rbac-db-perf/
load_when: [evidence, spec-57, td-295]
priority: high
symptom: [rbac-fix, n+1-fix, db-index-add, textfield-maxlength]
solution: spec-57 TD-295 解决方案 — 方案 A (N167 35/35 AI 自决), 4 类修复同步落地
related_files:
  - backend/accounts/permissions.py
  - backend/gaf_ai/views_skill.py
  - backend/gaf_ai/views_evaluation.py
  - backend/scheduler/views.py
  - backend/agents/views.py
  - backend/pipeline/views.py
  - backend/settings/views.py
  - backend/resources/views.py
  - backend/monitors/views.py
  - backend/protocol/models.py
  - backend/accounts/models.py
  - backend/accounts/migrations/0017_td295_db_index_textfield.py
  - backend/accounts/migrations/0018_td295_loginhistory_ip_index.py
  - backend/protocol/migrations/0003_td295_db_index_textfield.py
created_by: AI
last_updated: 2026-07-21
---
## Solution（修复方案 / 实施步骤）

方案 A (N167 35/35, 领先方案 B 5 分, AI 自决) — 4 类同步落地:

### 1. RBAC 加严 (10 处)

每处加 `permission_classes = [IsAuthenticated, RoleBasedPermission]` + `required_permission = '<perm>'`:
- `gaf_ai/views_skill.py` CustomSkillViewSet → execute
- `gaf_ai/views_evaluation.py` ModelEvaluationViewSet → llm_use
- `scheduler/views.py` RecoveryLogViewSet → view; TimeWindowViewSet → manage
- `agents/views.py:2459` PlatformCapabilitiesView → view
- `pipeline/views.py:380,396` PipelineValidateView + PipelineEstimateTimeView → execute
- `settings/views.py:80` LLMConfigViewSet → manage
- `resources/views.py:745,858` TemplateVersionViewSet → execute; TagViewSet → manage

7 处个人操作 KEEP (accounts CurrentUser/ChangePassword/TOTPSetup/Verify/Disable/UserSession/LoginHistory — 用户自管, 不需角色分级)

### 2. N+1 select_related (5 处)

viewset 类属性 queryset 加 select_related / prefetch_related:
- `resources/views.py` ResourcePackViewSet: `select_related('game_profile').prefetch_related('custom_tasks', 'scheduled_tasks', 'templates')`
- `resources/views.py` TemplateVersionViewSet: `select_related('created_by', 'template')`
- `resources/views.py` TagViewSet: `prefetch_related('templates')`
- `monitors/views.py` MonitorRuleViewSet: `select_related('resource_pack')`
- `monitors/views.py` MonitorEventViewSet: `select_related('agent', 'resource_pack', 'acknowledged_by')`

剩余 41 处函数内 queryset (serializer 多数无 FK) 留 TD-300 后续治理

### 3. DB index (3 处)

- `protocol/models.py` MessageFrameLog.trace_id: 加 `db_index=True`
- `protocol/models.py` MessageFrameLog.message_type: 加 `db_index=True`
- `accounts/models.py` LoginHistory.ip_address: 加 `db_index=True`

### 4. TextField max_length (1 处)

- `accounts/models.py` GameAccount.encrypted_password: `TextField(max_length=512)` (AES-256-GCM 密文长度上限)

### 5. Migration (3 个新文件)

- `accounts/migrations/0017_td295_db_index_textfield.py` (encrypted_password max_length)
- `accounts/migrations/0018_td295_loginhistory_ip_index.py` (ip_address db_index)
- `protocol/migrations/0003_td295_db_index_textfield.py` (trace_id + message_type db_index)

### 6. 测试 setup 修正

- `gaf_ai/tests/test_model_evaluation.py:252` 测试 user 加 `role=User.Role.OPERATOR` (llm_use 权限)
- `scheduler/tests/test_scheduler_timewindow.py:28` 测试 user 改 `role=User.Role.ADMIN` (manage 权限)

### N167 评分

| 维度 | A (4 类同步) | B (RBAC only) | C (DB only) |
|---|---|---|---|
| 1 架构长远性 | 5/5 | 3/5 | 3/5 |
| 2 全局归一化 | 5/5 | 4/5 | 4/5 |
| 3 新旧兼容 | 5/5 | 5/5 | 5/5 |
| 4 业务完善 | 5/5 | 3/5 | 3/5 |
| 5 性能 | 5/5 | 2/5 | 4/5 |
| 6 安全 | 5/5 | 5/5 | 2/5 |
| 7 长期维护 | 5/5 | 5/5 | 5/5 |
| **总分** | **35/35** | **27/35** | **30/35** |

方案 A 领先 5 分, 满足 spec-49 AI 自决阈值 (≥19 且领先 ≥5), 选定 A
