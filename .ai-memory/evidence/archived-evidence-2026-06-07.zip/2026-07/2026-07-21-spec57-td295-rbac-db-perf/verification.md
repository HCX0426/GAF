---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-21-spec57-td295-rbac-db-perf/
load_when: [evidence, spec-57, td-295]
priority: high
symptom: [pytest-passed, migration-applied, rbac-enforced]
solution: spec-57 TD-295 验证 — pytest 1955 passed + migrate 应用 5 migration + RBAC 403 校验
related_files:
  - backend/gaf_ai/tests/test_model_evaluation.py
  - backend/scheduler/tests/test_scheduler_timewindow.py
created_by: AI
last_updated: 2026-07-21
---
## Verification（验证证据）

### 1. pytest 全套通过

命令: `cd backend && conda run -n gaf pytest --tb=short -q 2>&1 | tail -20`

结果: `1955 passed in 526s`

关键验证点:
- 12 处 RBAC 测试 setup 修正后全部通过 (gaf_ai/tests/test_model_evaluation.py + scheduler/tests/test_scheduler_timewindow.py)
- 5 处 select_related 测试无回归
- 3 处 db_index migration 应用后 protocol + accounts 模型测试通过

### 2. Migration 应用

命令: `conda run -n gaf python manage.py migrate`

结果: 应用 5 个 migration:
- accounts.0016 (legacy)
- accounts.0017_td295_db_index_textfield
- accounts.0018_td295_loginhistory_ip_index
- protocol.0003_td295_db_index_textfield
- scheduler.0011 + tasks.0047/0048 (legacy)

### 3. RBAC 403 校验

12 处测试初次失败 `403 != 200/201/204` → 修复测试 user role 后通过, 证明 RoleBasedPermission 生效:
- viewer 调用 llm_use 操作 → 403 (需 OPERATOR+)
- viewer 调用 manage 操作 → 403 (需 ADMIN)

### 4. 文档同步

- `docs/general/tech-debt/active.md` TD-295 段落改为注释 (✅ FIXED — spec-57)
- `docs/general/tech-debt/fixed.md` 新增 TD-295 完整段落 (N167 35/35)
- `docs/general/completed-features.md` 新增 C-093
- `docs/general/pending-roadmap.md` 新增 P-034
- `docs/general/tech-debt/active.md` 新增 TD-300 (剩余 41 处 N+1, P3)

### 5. 治理范围统计

| 修复类型 | 原始扫描 | 实际改动 | KEEP | 后续 TD |
|---|---|---|---|---|
| RBAC | 17 处 | 10 处 | 7 处个人操作 | - |
| N+1 select_related | 46 处 | 5 处 (serializer 含 FK) | - | TD-300 (41 处) |
| DB index | 3 处 | 3 处 | - | - |
| TextField max_length | 1 处 | 1 处 | - | - |
