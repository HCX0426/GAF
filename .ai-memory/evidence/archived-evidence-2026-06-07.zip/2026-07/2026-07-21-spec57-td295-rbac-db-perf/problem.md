---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-21-spec57-td295-rbac-db-perf/
load_when: [evidence, spec-57, td-295]
priority: high
symptom: [rbac-missing, n+1-query, db-index-missing, textfield-unbounded]
solution: spec-57 TD-295 问题 — 10 处 ViewSet 缺 RoleBasedPermission + 5 处 N+1 select_related + 3 处 db_index + 1 处 TextField max_length
related_files:
  - .trae/specs/2026-07-20-spec57-td295-rbac-db-perf.md
  - docs/general/tech-debt/fixed.md
created_by: AI
last_updated: 2026-07-21
---
## Problem（症状 / 触发条件）

TD-295 后端 RBAC + DB 性能治理 — 4 类问题:

1. **RBAC 缺失**: 10 处 ViewSet (gaf_ai/views_skill/views_evaluation + scheduler/views × 2 + agents/views + pipeline/views × 2 + settings/views + resources/views × 2) 仅 `IsAuthenticated` 不校验角色, viewer 可执行 manage 操作
2. **N+1 查询**: 5 处 viewset 类属性 `queryset = X.objects.all()` 对应 serializer 含 FK 字段 (resources × 3 + monitors × 2), list 接口每行触发额外 FK 查询
3. **DB index 缺失**: `MessageFrameLog.trace_id` / `MessageFrameLog.message_type` / `LoginHistory.ip_address` 高频检索字段无 db_index, P99 latency 偏高
4. **TextField 无界**: `GameAccount.encrypted_password = TextField()` 无 max_length, 缺 DB 级约束 + MaxLengthValidator, payload 攻击风险

影响范围: 全部后端 viewset + protocol/accounts 模型; pytest 1955 passed 但 RBAC 加严后 12 处测试 setup 需要补 role

触发条件: spec-55 后 L3-1 全量扫描 [B] 类 (维度 ② 代码层 + ⑥ 业务逻辑层 + ⑦ 数据层)
