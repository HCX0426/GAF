---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-15-td110-phase4-frontend-dag-pipeline/
load_when: [evidence, 3-step-evidence, td110, frontend, dag-editor, n112]
priority: high
symptom: [td110-phase4, dag-editor, pipeline-node, n112-cross-layer]
solution: TD-110 Phase 4 — 前端 DAG editor 支持 Pipeline 节点 (N112 4 步配套)
related_files:
  - frontend/src/types/models.ts
  - frontend/src/api/tasks.ts
  - frontend/src/pages/Ops/ScheduledTasks/DagEditorPage.tsx
  - frontend/src/i18n/locales/scheduledTasks.ts
  - docs/general/specs/2026-07-14-td110-routine-taskchain-converter.md
created_by: AI
last_updated: 2026-07-15
---
## Problem（症状 / 触发条件）

Phase 1 在后端给 TaskChainNode 加了 node_type + pipeline FK，Phase 2/3 打通了 dispatch + routine.json 转换器。但前端 DAG editor (`DagEditorPage.tsx`) 仍然只支持添加 Task 节点 — 节点添加 Modal 没有选项，DagNode.data 类型只有 task_id/task_name，无法显示或创建 PIPELINE 类型节点。N112 跨层配套硬约束要求后端字段变更后必须 4 步同步到前端 (types + api + UI)，Phase 4 必须闭合这个缺口。

## Solution（解决步骤）

1. frontend/src/types/models.ts — 新增 `ChainNodeType = 'task' | 'pipeline'` 类型 + `TaskChainNode` interface (镜像 backend `TaskChainNodeSerializer`)。扩展 `DagNode.data` 加 `node_type?`, `pipeline_id?`, `pipeline_name?` 三个可选字段 — 默认 `'task'` 向后兼容现有 dag_data blob。
2. frontend/src/api/tasks.ts — 新增 3 个 typed helper: `fetchChainNodes(chainId, nodeType?)`, `createChainNode(payload)`, `deleteChainNode(nodeId)`。chain-scoped (按 chain_id 过滤)，typed 用 `TaskChainNode`。区别于 `@/api/misc.ts` 的 untyped helper（task-scoped, 用于 TaskDependencyGraph 的 task-to-task 依赖）。
3. frontend/src/pages/Ops/ScheduledTasks/DagEditorPage.tsx — 重写 Add Node Modal 为 Tabs(Task | Pipeline)。新增 `handleAddPipeline(pipelineId, pipelineName)` 创建 `node_type='pipeline'` 节点。新增 `getNodeDisplayName(data)` + `getNodeVisual(data)` helper — pipeline 节点用 ApartmentOutlined 紫色 (#722ed1)，task 节点用 NodeIndexOutlined 蓝色 (#1677ff)。状态栏 selected name 也走 `getNodeDisplayName`。useEffect 多加载 listPipelines。
4. frontend/src/i18n/locales/scheduledTasks.ts — 4 locale (zh-CN/en-US/ja-JP/ko-KR) 各加 9 keys: `button.add_pipeline`, `button.add_node`, `chain.node_type.task`, `chain.node_type.pipeline`, `chain.tooltip.add_pipeline`, `empty.no_pipelines`, `modal.add_node_title`, `modal.add_node_tab_task`, `modal.add_node_tab_pipeline`。

## Verification（验证）

$ cd frontend; npx tsc --noEmit 2>&1 | Select-String -Pattern "error TS" | Measure-Object -Line
预期：0
实际：0 (零 TS 错误，零回归)

$ cd frontend; npx tsc --noEmit 2>&1 | Select-String -Pattern "DagEditorPage|scheduledTasks|i18n|api/tasks|types/models"
预期：无匹配
实际：无匹配 (本次新增/修改的 4 个文件均无 TS 错误)

N112 跨层配套 4 步验证:
1. backend TaskChainNodeSerializer 加 pipeline + pipeline_name ✅ (Phase 1, commit d3605beb)
2. frontend types 同步 ✅ (本 Phase — types/models.ts TaskChainNode + DagNode.data)
3. frontend API 调用更新 ✅ (本 Phase — api/tasks.ts typed helpers)
4. frontend UI 组件更新 ✅ (本 Phase — DagEditorPage.tsx Tabs + Pipeline 图标)

UI 变更明细:
- 节点添加 Modal: Tabs 切换 Task / Pipeline
- DAG 节点渲染: ApartmentOutlined (紫 #722ed1) for Pipeline / NodeIndexOutlined (蓝 #1677ff) for Task
- 节点详情: getNodeDisplayName 按 node_type 渲染 task_name 或 pipeline_name
