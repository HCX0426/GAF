---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-15-td110-phase4-frontend-dag-pipeline/
load_when: [evidence, 3-step-evidence, td110, frontend, dag-editor, n112]
priority: high
symptom: [td110-phase4, dag-editor, pipeline-node, n112-cross-layer]
solution: TD-110 Phase 4 — Solution 步骤详情
related_files:
  - frontend/src/types/models.ts
  - frontend/src/api/tasks.ts
  - frontend/src/pages/Ops/ScheduledTasks/DagEditorPage.tsx
  - frontend/src/i18n/locales/scheduledTasks.ts
created_by: AI
last_updated: 2026-07-15
---
## Solution（解决步骤）

1. **types/models.ts** — 新增 `ChainNodeType = 'task' | 'pipeline'` 类型别名。新增 `TaskChainNode` interface (字段与 backend `TaskChainNodeSerializer` 一致: id/chain/node_type/task/task_name/pipeline/pipeline_name/parent/parent_task_name/parent_pipeline_name/condition/order)。扩展 `DagNode.data` 加 `node_type?`, `pipeline_id?`, `pipeline_name?` 三个可选字段 — 向后兼容现有 dag_data 中无 node_type 的旧节点 (默认按 'task' 渲染)。

2. **api/tasks.ts** — 在 `deleteTaskChain` 后追加 chain-node 管理 section: 3 个 typed helper:
   - `fetchChainNodes(chainId, nodeType?)` — GET /pipeline/chain-nodes/?chain_id=&node_type=
   - `createChainNode(payload)` — POST /pipeline/chain-nodes/ with `{chain, node_type, task?, pipeline?, parent?, condition?, order?}`
   - `deleteChainNode(nodeId)` — DELETE /pipeline/chain-nodes/:id/
   注释说明与 `@/api/misc.ts` 旧 untyped helper 的边界 (misc.ts 按 task_id 查 — 用于 TaskDependencyGraph 的 task-to-task 依赖图; tasks.ts 按 chain_id 查 — 用于 TaskChain DAG 编排)。

3. **DagEditorPage.tsx** — 完整重写:
   - 新增 helper: `getNodeDisplayName(data)` 按 node_type 返回 pipeline_name 或 task_name; `getNodeVisual(data)` 返回 {icon, color} (pipeline=ApartmentOutlined 紫色, task=NodeIndexOutlined 蓝色)。
   - `DagTaskNode` 组件用 helper 渲染 — border 颜色按 node_type 变 (紫/蓝)，body 显示 "Pipeline"/"Task" secondary label。
   - state: 加 `pipelines: PipelineSummary[]` + `addNodeTab: 'task' | 'pipeline'`。
   - useEffect: 多加 `listPipelines({page:1, page_size:200})` 加载 Pipeline 列表。
   - 新增 `handleAddPipeline(pipelineId, pipelineName)` — 创建 `node_type='pipeline'` 节点 (id=`pipeline_${id}_${ts}`)。
   - Add Node Modal 用 `<Tabs items={[{key:'task',...},{key:'pipeline',...}]} />` 替换原单一 task 列表 — Task tab 保持原 UI (绿色 enabled tag)，Pipeline tab 用 ApartmentOutlined 紫色图标 + version tag。
   - 工具栏按钮文案 `add_task` → `add_node`，点击默认开 task tab。
   - 状态栏 selected name 走 `getNodeDisplayName`。

4. **i18n/locales/scheduledTasks.ts** — 4 locale 各加 9 keys: button.add_pipeline / button.add_node / chain.node_type.{task,pipeline} / chain.tooltip.add_pipeline / empty.no_pipelines / modal.add_node_title / modal.add_node_tab_{task,pipeline}。

5. **spec 状态表** — Phase 4 状态 ⏳ → ✅，evidence 写入 commit hash (回填)。
