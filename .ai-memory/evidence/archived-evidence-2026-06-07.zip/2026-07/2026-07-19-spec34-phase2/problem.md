# spec34 Phase 2 — Problem

## 背景
Phase 1 提供了 AuditMixin + @audit_action + audit_constants 基础设施 (commit bd0dda95),
但 0 个生产 ViewSet 调用 log_audit。

## Phase 2 范围
接入 3 个最敏感 app 的 ViewSet:
1. `backend/accounts/` — 用户/2FA/密码/会话/游戏账号/API Key/Agent Token
2. `backend/settings/` — LLM 配置/Feature Flag/App Settings/无人值守策略/清理/诊断
3. `backend/tasks/` — 任务/自定义任务/定时任务/市场/文件夹/绑定/批量/克隆/执行

## 验收门槛
- accounts (70 tests) + settings (6 tests) + tasks (119 tests) + gaf_core (31 tests) 全过
- 无 regression
- 敏感字段 (password/token/api_key/secret) 自动 redact
