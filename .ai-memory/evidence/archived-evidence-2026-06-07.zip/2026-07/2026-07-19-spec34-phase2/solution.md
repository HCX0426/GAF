# spec34 Phase 2 — Solution

## 执行方式
3 subagent 并行 (N172 模式):
- Subagent A: accounts app (33 View 类, 接入 17 个, 跳过 16 个纯查询/只读)
- Subagent B: settings app (3 ViewSet + 3 function-based view)
- Subagent C: tasks app (12 View 类, 接入 10 个, 跳过 1 只读 + 1 deferred)

主会话补漏: Phase 1 缺 `AuditResourceType.MARKETPLACE` 常量, subagent C 回退了
MarketplaceViewSet 接入。主会话在 `audit_constants.py` 补常量 + 接入 MarketplaceViewSet。

## 接入汇总 (3 app)

### accounts (Subagent A) — `backend/accounts/views.py`

**A. AuditMixin (7 ViewSet)**:
- UserViewSet (USER) + _build_audit_details (username/email/role diff)
- MeView (USER) + _build_audit_details
- GameAccountViewSet (GAME_ACCOUNT) + _build_audit_details (无 encrypted_password)
- GameAccountGroupViewSet (GAME_ACCOUNT_GROUP) + 重写 perform_create (注入 owner)
- GameAccountRotationViewSet (ROTATION_RULE) + 重写 perform_create
- APIKeyViewSet (API_KEY) + 重写 perform_create + _build_audit_details (无 key_hash)
- UserSessionViewSet (USER_SESSION) + audit_log_*=False (GenericViewSet 无 model mixin, dead hook 显式禁用)

**B. 显式 log_audit (13 处)**:
- CreateAdminView / ChangePasswordView / RegisterView / SetupView / CustomTokenObtainPairView
- TOTPSetupView / TOTPVerifySetupView / TOTPDisableView / Login2FAView
- PasswordResetRequestView / PasswordResetConfirmView
- AgentTokenViewSet.create/destroy / UserSessionViewSet.destroy

**C. @audit_action (6 个)**:
- UserViewSet.reset_password (UPDATE, USER)
- GameAccountViewSet.test_login / batch_check / batch_import / bind_resource
- UserSessionViewSet.logout_all_others

**跳过 (16 个)**: CheckAdminView / SystemHealthView / DeviceScanView / ImportExamplePacksView /
ExamplePacksView / EnvCheckView / InitStatusView / CustomTokenRefreshView /
LoginHistoryViewSet / AuditLogViewSet / GameAccountViewSet.game_options /
LoginHistoryViewSet.all_history / 4 OAuth views (全 GET)

### settings (Subagent B) — `backend/settings/views.py`

**A. AuditMixin (3 ViewSet)**:
- LLMConfigViewSet (LLM_CONFIG) + _build_audit_details (sensitive_extra={"api_key"})
- FeatureFlagViewSet (FEATURE_FLAG) + _build_audit_details
- AppSettingsViewSet (APP_SETTINGS) + 内联 perform_update (保留 updated_by 注入) + _build_audit_details

**B. 显式 log_audit (3 function-based view)**:
- unattended_strategy_view (CREATE/UPDATE 自动判别, UNATTENDED_STRATEGY)
- cleanup_view (EXECUTE, APP_SETTINGS)
- generate_diagnostic (EXECUTE, APP_SETTINGS)

**跳过**: agent_debug_view / wait_when_background_view (建议 follow-up) /
config_generator_view / config_migration_view (工具型, 不持久化) / 所有 GET

### tasks (Subagent C) — `backend/tasks/views.py`

**A. AuditMixin (5 ViewSet)** + 主会话补 1 个:
- TaskViewSet (TASK) + _build_audit_details
- CustomTaskViewSet (CUSTOM_TASK) + 重写 perform_create (保留 created_by)
- ScheduledTaskViewSet (SCHEDULED_TASK) + 重写 perform_create
- TaskFolderViewSet (TASK_FOLDER) + 重写 perform_create (保留 owner)
- MarketplaceViewSet (MARKETPLACE) — 主会话补 (Phase 1 缺常量, subagent C deferred)

**B. 显式 log_audit (6 APIView)**:
- TaskBindDevicesView (UPDATE, TASK)
- TaskBindAccountsView (UPDATE, TASK)
- TaskParallelConfigView (UPDATE, TASK) + build_diff_details
- TaskBulkActionView (UPDATE/DELETE/EXPORT, TASK) — action 映射字典
- TaskCloneView (CREATE, TASK) — source_task_id + new_task_id
- TaskExecuteView (EXECUTE, TASK)

**C. @audit_action (3 个)**:
- TaskViewSet.execute (EXECUTE, TASK)
- TaskViewSet.cancel (UPDATE, TASK)
- ScheduledTaskViewSet.toggle (UPDATE, SCHEDULED_TASK)

**跳过**: TaskExecutionViewSet (只读) / TaskViewSet.validate (GET) /
CustomTaskViewSet.validate (GET) / MarketplaceViewSet.my_published (GET) /
task_version_list_view (GET) / task_version_save_view (follow-up)

## 关键设计决策

### 1. AuditMixin 优先
任何有 `perform_*` hook 的 ViewSet 都用 AuditMixin (DRY), 无 hook 的才退回显式 log_audit
或 @audit_action 装饰器。

### 2. perform_create 重写冲突解决
CustomTaskViewSet / ScheduledTaskViewSet / TaskFolderViewSet / GameAccountGroupViewSet /
GameAccountRotationViewSet / APIKeyViewSet 原有 perform_create 调 `serializer.save(kwargs)`
会绕过 AuditMixin。解决方法: 子类 perform_create 内显式 `serializer.save(...)` + 条件调
`self._log_audit(AuditAction.CREATE, serializer.instance)`。

### 3. UserSessionViewSet dead hook 显式禁用
GenericViewSet 无 Create/Update/Destroy model mixin, AuditMixin.perform_* 是 dead code。
通过 `audit_log_create = audit_log_update = audit_log_destroy = False` 显式声明 intent,
避免后续维护者误以为 hook 会触发。destroy() 方法内显式调 log_audit。

### 4. CustomTokenObtainPairView 登录审计
TokenObtainPairView (simplejwt) 无 perform_create hook。重写 post(), 调 super().post()
后, 仅当 status=200 且非 2FA 流程时 (避免对 requires_2fa 临时 token 流程也写审计),
通过 username 反查 user 写 LOGIN 审计; 2FA 用户在 Login2FAView 单独审计。

### 5. 敏感字段保护
所有 details dict 都通过 `filter_sensitive_fields()` 过滤。额外敏感字段通过 `extra_sensitive`
参数扩展 (如 LLMConfigViewSet 的 `{"api_key"}`)。密码相关字段 (password/new_password/
totp_secret/token/key_hash) 永不进 details — `_build_audit_details` 实现只挑 safe fields。

### 6. lazy import 防循环
所有 `from accounts.audit import log_audit` 在函数体内 import, 避免模块加载顺序问题。

### 7. TaskBulkActionView action 映射
通过类属性 `_BULK_ACTION_TO_AUDIT` 字典明确映射 bulk action slug → AuditAction 常量,
避免散落的 if/else。export 虽是只读但仍然审计 (大宗数据外泄追踪)。
