---
task: Remove legacy browser-automation spec directory
date: 2026-07-09
---

# Problem

`.trae/specs/browser-automation/` contained only a single `spec.md` (2026-06-22) with no `tasks.md` or `checklist.md`. During the arch-governance cleanup spec audit, it was identified as a stale spec:

- The described Playwright/browser-use capability is already documented in `project_rules.md §1.2`.
- The concrete E2E scenarios are already implemented under `scripts/e2e/`.
- The login selector described in the spec (`input[autocomplete="username"]`) does not match the current login page, making the spec misleading if executed literally.

Keeping an orphaned spec without executable tasks/checklists creates documentation drift.
