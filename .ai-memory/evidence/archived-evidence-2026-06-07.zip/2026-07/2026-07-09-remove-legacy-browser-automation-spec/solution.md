---
task: Remove legacy browser-automation spec directory
date: 2026-07-09
---

# Solution

1. Verified that no code, skill, or active spec references `.trae/specs/browser-automation/spec.md` as an execution plan.
2. Removed the empty `.trae/specs/browser-automation/` directory.
3. Updated `.trae/specs/arch-governance-cleanup/spec.md` §Impact to reflect that the `browser-automation` spec was deleted and its capability is now carried by `project_rules.md §1.2` + `scripts/e2e/`.
