---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, verification-step, evidence-verification, monthly-check, slimming]
solution: spec-44 verification — 99 tests PASS in 12.39s / git diff --stat 仅 1 个文件 / G 类 8 项全标记已迁自动 / 检查项总览表合计行含 (月度跑 76)
related_files:
  - docs/general/monthly-health-check.md
  - scripts/tests/test_doc_health_consumed.py
  - scripts/tests/test_doc_health_patch.py
  - scripts/tests/test_doc_health_check.py
  - scripts/tests/test_doc_health_forget.py
created_by: AI
last_updated: 2026-07-20
---
## Verification（验证）

$ cd d:\code\GAF && conda run -n gaf pytest scripts/tests/test_doc_health_consumed.py scripts/tests/test_doc_health_patch.py scripts/tests/test_doc_health_check.py scripts/tests/test_doc_health_forget.py --tb=short -q
  → 99 passed in 12.39s (15+20+47+17, 无回归)

$ cd d:\code\GAF && git diff --stat docs/general/monthly-health-check.md
  → 1 file changed, ~30 insertions, ~5 deletions (仅 monthly-health-check.md 改动)

$ cd d:\code\GAF && rg "已迁自动 \(spec-41" docs/general/monthly-health-check.md
  → 11 matches (frontmatter summary 1 + 顶部迁移说明 1 + G 类标题 1 + G1-G8 每项 8)

$ cd d:\code\GAF && rg "月度跑 76" docs/general/monthly-health-check.md
  → 2 matches (frontmatter summary + 检查项总览表合计行)

$ cd d:\code\GAF && rg "跳过 G 类" docs/general/monthly-health-check.md
  → 2 matches (执行流程步骤 2 + 顶部迁移说明)

预期:
- 99 tests PASS (无回归, spec-44 仅文档改动, 不影响代码/测试)
- git diff --stat 仅 1 个文件 (monthly-health-check.md)
- G 类 8 项 (G1-G8) 全标记 "✅ 已迁自动 (spec-41)"
- 检查项总览表合计行含 "(月度跑 76)" + "(月度 ~80-95 min)"
- 执行流程步骤 2 含 "跳过 G 类, 已由 gaf_init.sh 自动跑"
- frontmatter summary 含 "19 类" + "G 类已迁自动 spec-41" + "月度跑 76 项"
- 顶部迁移说明段含 8 项迁移映射 (G1-G8 → spec-41 维度)
- 低风险: 仅文档改动, 无代码/测试改动, 无回归风险
- 回退方案: `git revert <commit>` 即可恢复
