---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, problem-step, evidence-problem, monthly-check, slimming]
solution: spec-44 problem — monthly-health-check.md G 类 8 项已被 spec-41 doc_health_check.py 7 维度覆盖, 但月度文件未标记"已迁自动", 导致月度检查时仍手动跑 G 类 8 项, 浪费 ~5-10 min
related_files:
  - docs/general/monthly-health-check.md
  - scripts/governance/doc_health_check.py
  - .trae/specs/2026-07-20-spec44-monthly-check-slimming.md
created_by: AI
last_updated: 2026-07-20
---
## Problem（症状 / 触发条件）

spec-41 已交付 `scripts/governance/doc_health_check.py` 7 维度静态检查 (commit `ebaa134b`, 47 tests PASS, 1.0s), 通过 `gaf_init.sh` 在每次对话开头自动跑。7 维度 (d1_overlap / d2_bloat / d3_count_drift / d4_path_drift / d5_frontmatter / d6_staleness / d7_index_consistency) 完全覆盖 `docs/general/monthly-health-check.md` G 类 (文档与 AI 记忆一致性) 8 项检查 (G1-G8)。

但月度检查文件未标记"已迁自动",导致:
1. 月度检查时仍手动跑 G 类 8 项 (G1 docs/ 索引 / G2 AI 记忆同步 / G3 Skills 副本 / G4 lessons front-matter / G5 failure-modes 索引 / G6 skill 引用 / G7 path 引用 / G8 脚本引用), 浪费 ~5-10 min
2. 检查项总览表仍标 G 类 8 项, 虚高月度检查项数 (84 项中 8 项已冗余)
3. frontmatter summary 仍标 "12 类", 与实际 19 类 (A-S) 不符

触发条件: spec-42 §1.4 非目标声明 "月度检查瘦身 (12 类→5 类) → spec-44" + spec-43 完成后 P-012 接修。

影响范围: `docs/general/monthly-health-check.md` (单文件改动, frontmatter + 顶部迁移说明 + 检查项总览表 + 执行流程 + G 类标题 + G1-G8 每项迁移映射注释)。
