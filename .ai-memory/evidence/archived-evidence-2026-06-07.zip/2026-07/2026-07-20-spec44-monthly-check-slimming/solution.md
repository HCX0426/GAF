---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, solution-step, evidence-solution, monthly-check, slimming]
solution: spec-44 solution — 3 Phase 实施: Phase 1 G 类 8 项标记已迁自动 + frontmatter / Phase 2 检查项总览表 + 执行流程 / Phase 3 全量回归 + commit
related_files:
  - docs/general/monthly-health-check.md
  - .trae/specs/2026-07-20-spec44-monthly-check-slimming.md
  - .trae/plans/2026-07-20-spec44-monthly-check-slimming.md
created_by: AI
last_updated: 2026-07-20
---
## Solution（解决步骤）

1. **Phase 1**: 改 `docs/general/monthly-health-check.md` frontmatter:
   - `summary: "全面 12 类可执行检查项"` → `"全面 19 类可执行检查项 (G 类已迁自动 spec-41, 月度跑 76 项)"`
   - `last_updated: 2026-07-13` → `2026-07-20`
   - 文件顶部 (frontmatter 之后, `# GAF 月度健康检查指南` 之前) 加迁移说明段 (15 行 blockquote, 含 8 项迁移映射 G1-G8 → spec-41 维度)
   - G 类标题: `## G. 文档与 AI 记忆一致性` → `## G. 文档与 AI 记忆一致性 ✅ 已迁自动 (spec-41, 2026-07-20)` + 类标题下加迁移说明 blockquote
   - G1-G8 每项标题下加迁移映射 blockquote (如 `> **✅ 已迁自动 (spec-41)**: d7_index_consistency + d5_frontmatter (gaf_init.sh 自动跑)`)
   - 保留 G 类原有内容 (不删除, 作为历史参考 + 迁移映射证据)

2. **Phase 2**: 改 `docs/general/monthly-health-check.md` 检查项总览表 + 执行流程:
   - 检查项总览表 G 类行: `| G | 文档与 AI 记忆一致性 | 8 | 5 min |` → `| G | 文档与 AI 记忆一致性 ✅ 已迁自动 (spec-41, 月度跳过) | 8 | 5 min |`
   - 检查项总览表合计行: `| **合计** | | **84** | **~85-100 min** |` → `| **合计** | | **84 (月度跑 76)** | **~85-100 min (月度 ~80-95 min)** |`
   - 执行流程步骤 2: `按 A-L 顺序逐类执行检查` → `按 A-S 顺序逐类执行检查 (**跳过 G 类, 已由 gaf_init.sh 自动跑**)`

3. **Phase 3**: 全量回归 + commit:
   - 跑 `pytest scripts/tests/test_doc_health_*.py --tb=short -q` 验证 99 tests PASS (15+20+47+17, 无回归)
   - 跑 `git diff --stat` 确认仅 1 个文件改动 (monthly-health-check.md)
   - 填 3-step evidence (本文件 + problem.md + verification.md)
   - 更新 spec-44 状态表 3 Phase 全 ✅ + frontmatter status: ✅ done
   - 追加 completed-features.md C-071
   - 更新 pending-roadmap.md P-012 标 ✅
   - (N176 单对话单 commit) `git add -A && git commit -m "docs(spec-44): monthly check slimming (G class 8 items migrated to spec-41 auto)"`
   - 回填 commit hash 到 spec-44 状态表 + C-071
