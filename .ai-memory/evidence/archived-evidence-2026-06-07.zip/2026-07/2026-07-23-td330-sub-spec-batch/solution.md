---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, solution-step, evidence-solution]
solution: TD-330 sub-spec 26-30 批量治理 — 按 A/B/C 三类分治推进 hex → antd token
related_files:
  - .ai-memory/evidence/2026-07-23-td330-sub-spec-batch/problem.md
  - .ai-memory/evidence/2026-07-23-td330-sub-spec-batch/verification.md
  - docs/general/tech-debt/active.md
  - frontend/src/pages/Tasks/TaskStudio/RecordingStepper.tsx
  - frontend/src/pages/Tasks/Editor.tsx
  - frontend/src/pages/Tasks/TaskStudio/RecordingsPage.tsx
  - frontend/src/pages/Accounts/components/AccountLoginTester.tsx
  - frontend/src/pages/Ops/Monitors/index.tsx
created_by: AI
last_updated: 2026-07-23
---
## Solution（解决步骤）

1. spec-118 合并治理 5 文件 9 hex: RecordingStepper.tsx (#d9d9d9/#f5f5f5) + Editor.tsx (#e6f4ff/#f0f0f0) + RecordingsPage.tsx (#1677ff/#f5f5f5) + AccountLoginTester.tsx (#888) + Monitors/index.tsx (2 处 #999),模式: 加 theme.useToken() + hex → token.colorBorder/colorFillQuaternary/colorPrimaryBg/colorBorderSecondary/colorPrimary/colorTextTertiary
2. 在 frontend 目录执行 `npx tsc --noEmit` 验证 0 errors
3. 在 docs/general/tech-debt/active.md 更新 TD-330 状态行 + 修复方案验证计数 (66→57) + sub-spec 进度段 + 下一候选行
4. git add 5 文件 + active.md + spec 文件,执行 `git commit -m "spec-118: ..."`
