---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, problem-step, evidence-problem]
solution: TD-330 sub-spec 26-30 批量治理 — frontend hex color 残留 57 处需降到 < 50
related_files:
  - .ai-memory/evidence/2026-07-23-td330-sub-spec-batch/solution.md
  - .ai-memory/evidence/2026-07-23-td330-sub-spec-batch/verification.md
  - docs/general/tech-debt/active.md
created_by: AI
last_updated: 2026-07-23
---
## Problem（症状 / 触发条件）

TD-330 frontend 全仓 hex color 治理推进至 spec-117 后,全局 hex 计数 232→66,但仍未达验收标准 < 50 处。剩余 19 文件含 hex color,其中 5 文件已评估为 C 类保留 (业务调色板/品牌色/暗色终端/彩色背景白文字),其余 14 文件含可治理的 A 类 hex (antd 语义色对应)。

**触发条件**: 循环模式下继续推进 TD-330 sub-spec,需在 2026-07-23 跨日后创建 evidence 目录通过 governance batch hook 校验。

**影响范围**: frontend/src/pages/ 下 14 文件,涉及 Tasks/Accounts/Ops/Resources 模块。
