---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, verification-step, evidence-verification]
solution: TD-330 sub-spec 26-30 批量治理验证 — tsc 0 errors + hex grep 清零 + governance batch Passed
related_files:
  - .ai-memory/evidence/2026-07-23-td330-sub-spec-batch/problem.md
  - .ai-memory/evidence/2026-07-23-td330-sub-spec-batch/solution.md
  - frontend/src/pages/Tasks/TaskStudio/RecordingStepper.tsx
  - frontend/src/pages/Tasks/Editor.tsx
  - frontend/src/pages/Tasks/TaskStudio/RecordingsPage.tsx
  - frontend/src/pages/Accounts/components/AccountLoginTester.tsx
  - frontend/src/pages/Ops/Monitors/index.tsx
created_by: AI
last_updated: 2026-07-23
---
## Verification（验证）

$ cd d:\code\GAF\frontend && npx tsc --noEmit
预期: exit code 0, 无 stdout 输出 (0 errors)

$ grep -rn "#[0-9a-fA-F]\{3,8\}" frontend/src/pages/Tasks/TaskStudio/RecordingStepper.tsx frontend/src/pages/Tasks/Editor.tsx frontend/src/pages/Tasks/TaskStudio/RecordingsPage.tsx frontend/src/pages/Accounts/components/AccountLoginTester.tsx frontend/src/pages/Ops/Monitors/index.tsx
预期: No matches found (5 文件 hex 全部清零)

$ cd d:\code\GAF && git commit -m "spec-118: ..."
预期: GAF governance batch Passed + commit 成功 (exit code 0)
