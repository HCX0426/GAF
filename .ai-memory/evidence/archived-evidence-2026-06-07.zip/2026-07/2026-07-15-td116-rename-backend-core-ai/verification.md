# TD-116 Verification — backend/core/ + backend/ai/ rename → gaf_core/ + gaf_ai/

> **Spec**: `docs/general/specs/2026-07-15-td116-rename-backend-core-ai.md`
> **Commits**: `1c722a09` (Phase 1) → `94f3e5cd` (Phase 2) → `ef55df18` (Phase 3) → Phase 4 (doc sync)
> **Date**: 2026-07-15

## Problem

`backend/core/` (Django app) and `backend/ai/` (Django app) shared top-level package names with `agent/src/core/` and `agent/src/ai/` (agent packages). When pytest-django auto-configured Django (`pythonpath = ["backend"]`), `django.setup()` cached the backend versions in `sys.modules`, causing all 46 agent test files to fail collection with `ModuleNotFoundError`.

Previous workaround (TD-117): `agent/conftest.py` evicted `core.*` and `ai.*` from `sys.modules` before agent tests ran — a "下游 workaround 适配架构缺陷" anti-pattern (§2.0 三原则禁止).

## Solution

Direction A (§2.0.4 N151 + §2.0.5 四维度): rename backend apps to `gaf_core` and `gaf_ai`, unifying on `gaf_*` prefix (Django best practice). 4 Phase implementation:

- **Phase 1** (`1c722a09`): `git mv backend/core backend/gaf_core` + new `apps.py` (GafCoreConfig, `label='gaf_core'`) + data migration `0004_rename_app_label.py` (UPDATE django_migrations SET app) + ~19 import updates. `db_table='core_log_entry'` preserved (no schema change).
- **Phase 2** (`94f3e5cd`): `git mv backend/ai backend/gaf_ai` + new `apps.py` (GafAiConfig) + data migration `0004` + 32 import updates + 60 `@mock.patch('ai.X.Y')` → `@mock.patch('gaf_ai.X.Y')` string updates. `db_table='ai_*'` preserved. Also fixed N158 lesson `related_files` frontmatter (pre-commit validator caught stale paths).
- **Phase 3** (`ef55df18`): Removed `agent/conftest.py` `_CONFLICTING_NAMESPACES` sys.modules eviction. Only `sys.path.insert(0, .../agent/src)` remains.
- **Phase 4**: Full regression + doc sync.

## Verification

### manage.py check
```
System check identified no issues (0 silenced).
```

### showmigrations
```
gaf_core
 [X] 0001_initial_logentry
 [X] 0002_add_logentry_trace_id
 [X] 0003_logentry_dedup_fields
 [X] 0004_rename_app_label
gaf_ai
 [X] 0001_initial
 [X] 0002_customskill
 [X] 0003_agent_session
 [X] 0004_rename_app_label
```
8/8 [X] applied — both renamed apps fully migrated.

### Backend full test suite
```
Ran 1397 tests in 502.472s

OK
```
1397 passed, 0 failures. (The `[DatabaseLogHandler] Failed to persist log` messages are expected — they come from tests that exercise the log handler during test DB teardown.)

### Agent tests (no workaround)
```
1398 passed, 2 skipped in 92.98s
```
1398 passed, 2 skipped, **0 collection errors** — without `--ignore`, without `sys.modules` cleanup. This is the key TD-116 success criterion: agent tests now run cleanly via pytest with zero workaround.

### ruff
```
ruff check agent/conftest.py → All checks passed!
ruff check backend/gaf_ai/   → 0 errors
ruff check backend/gaf_core/ → 0 errors (TD-118 5 pre-existing in other files, registered separately)
```

### pre-commit hooks
All 11 hooks pass on every commit (including `gaf-lessons-updated` frontmatter validator after N158 `related_files` sync).

## Doc sync

- `docs/general/design/architecture-overview.md` §9.3 + §9.5: `[ai]` → `[gaf_ai]`, `[core]` → `[gaf_core]` (links + inline paths)
- `docs/general/analysis/GAF-optimal-solution.md` §四 row 12: `backend/ai/` → `backend/gaf_ai/`
- `docs/backend/operations/llm-integration-design.md`: 8 `backend/ai/` → `backend/gaf_ai/` replace_all
- `docs/general/tech-debt/active.md` TD-116: 🔧 待修 → ✅ FIXED (4 Phase commit hashes + evidence)
- `docs/general/completed-features.md`: C-038 added
- `.ai-memory/lessons/agent-impl_2026-07-12-n158-langgraph-agent-implementation.md`: `related_files` + inline paths updated to `gaf_ai/` + historical note about TD-116 rename

## Conclusion

TD-116 ✅ FIXED. The top-level package name collision between backend Django apps and agent packages is eliminated at the root cause (backend rename) rather than masked by a conftest.py workaround. Agent tests run cleanly via pytest with zero sys.modules manipulation.
