---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-09-n151-architecture-first/
load_when: [evidence, 3-step-evidence, N151, TD-061]
priority: high
symptom: [n151-verification, sync-skills-check, td-061-inventory]
solution: sync_skills.py --check 4副本一致 + DB盘点脚本验证 + pre-commit hook 通过
related_files:
  - .ai-memory/evidence/2026-07-09-n151-architecture-first/problem.md
  - .ai-memory/evidence/2026-07-09-n151-architecture-first/solution.md
  - scripts/sync_skills.py
created_by: AI
last_updated: 2026-07-09
---
## Verification（验证）

$ conda run -n gaf python scripts/sync_skills.py --check
预期: 4 副本一致 (decision-tree / loading-strategy / tech-stack / version-compat)

$ conda run -n gaf python .trash/td061_db_inventory.py
预期: tasks.Pipeline=5行真实数据 + 4个FK引用; pipeline.Pipeline=4行测试数据 + 1个自引用FK

$ git add <N151 files> && git commit -m "docs(rules): add N151..."
预期: pre-commit hook 通过 (3-step evidence dir 已创建)

$ git log --oneline -1
预期: 看到 N151 commit hash
