---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-09/
load_when: [evidence, 3-step-evidence, N151, TD-061]
priority: high
symptom: [n151-rule-creation, td-061-decision-memo, l1-4-layer-distribution]
solution: N151 L1 4层分发 + TD-061 N151 5步流程决策备忘录
related_files:
  - .trae/rules/project_rules.md
  - .ai-memory/lessons/2026-07-08-n151-architecture-first-for-major-changes.md
  - docs/architecture/pipeline-model-consolidation-decision.md
created_by: AI
last_updated: 2026-07-09
---
## Solution（解决步骤）

1. 创建 N151 lesson: `.ai-memory/lessons/2026-07-08-n151-architecture-first-for-major-changes.md` (5步流程 + Y/N检查表 + 同根因家族)
2. L1 4层分发: lessons + meta/failure-modes.md + meta/yn-matrices.md §2 ㉕ + summaries/architecture-mistakes.md §0
3. project_rules.md 硬约束: §2.0.4 大修改架构视角原则 + §6.4 N151索引行 + §6.5 通用硬约束3条
4. skill 更新: gaf-orchestrator/SKILL.md refactor分支 + gaf-task-execution/SKILL.md §3
5. TD-061 盘点: DB行数 + schema + FK引用 + 前端调用 + Agent处理 + WebSocket推送 (4维度)
6. TD-061 决策备忘录: `docs/architecture/pipeline-model-consolidation-decision.md` (N151 5步流程, 推荐方案B)
