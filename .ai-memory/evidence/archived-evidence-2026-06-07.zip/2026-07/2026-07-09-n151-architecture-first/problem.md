---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-09/
load_when: [evidence, 3-step-evidence, N151, TD-061]
priority: high
symptom: [n151-architecture-first, td-061-pipeline-split-brain, major-change-architecture]
solution: N151 规则创建 + TD-061 架构决策备忘录;用户反馈"ai自决也要从架构看"
related_files:
  - .trae/rules/project_rules.md
  - .ai-memory/lessons/2026-07-08-n151-architecture-first-for-major-changes.md
  - docs/architecture/pipeline-model-consolidation-decision.md
created_by: AI
last_updated: 2026-07-09
---
## Problem（症状 / 触发条件）

用户反馈："ai自决也要从架构看，这得加进规则或者skill里，所有大修改都以架构来看"

1. 现象：AI 自决权（N109/N113/N115/N127）缺乏"架构视角"约束，可能凭"最小改动"自决大修改方向
2. 触发条件：TD-061 Pipeline split-brain 架构决策时，用户明确否定"最小化原则"用于架构决策
3. 影响范围：所有 >500行/架构变更/跨模块/DB迁移/API契约变更的大修改

连带问题：TD-061 两套 Pipeline 并存（tasks.Pipeline + pipeline.Pipeline），schema 不一致、职责分裂、前端调用混乱，需架构决策
