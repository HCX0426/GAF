---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-15-td110-phase3-routine-converter/
load_when: [evidence, 3-step-evidence, td110, routine-converter]
priority: high
symptom: [td110-phase3, routine-converter, chain-pipeline-node, missing-converter]
solution: TD-110 Phase 3 — Solution 步骤详情
related_files:
  - backend/pipeline/services.py
  - backend/pipeline/management/commands/import_routine.py
  - backend/pipeline/views.py
  - backend/pipeline/tests/test_routine_converter.py
created_by: AI
last_updated: 2026-07-15
---
## Solution（解决步骤）

1. backend/pipeline/services.py — 加 `RoutineImportError` 异常 + `convert_routine_to_chain()` 函数。函数步骤：检查 file 存在 → 读 JSON → 校验 name + tasks 字段 → 按 order 排序 → 用 `Pipeline.objects.filter(name=...)` 解析每个 pipeline（多个匹配 raise RoutineImportError）→ `transaction.atomic()` 里 `TaskChain.objects.get_or_create(name + game_profile_id)`（已存在则替换 description + 清旧节点）→ 创建 8 个 `node_type=PIPELINE` 的 TaskChainNode。
2. backend/pipeline/management/__init__.py + commands/__init__.py — 新建 management 包（pipeline app 之前没有 management/commands 目录）。
3. backend/pipeline/management/commands/import_routine.py — Django BaseCommand，add_arguments 接收 `routine_path` positional + `--game-profile` required + `--user` optional。handle() 解析 user → 调 `convert_routine_to_chain()` → 捕获 `RoutineImportError` 转 `CommandError`。成功输出 `Successfully imported routine → TaskChain [<name>] (id=..., nodes=8, is_default=True)`。
4. backend/pipeline/views.py — `TaskChainViewSet.execute` action 改为按 node_type 渲染 `first_ref_name`（pipeline.name 或 task.name）+ 加 `first_node_type` 字段。新增 `import_routine` action 处理 `POST /api/v2/pipeline/task-chains/import_routine/`：参数校验 → 调 service → 201 + TaskChainSerializer。
5. backend/pipeline/tests/test_routine_converter.py — 14 个测试分 4 类：ConvertRoutineToChainTests (4)、ConvertRoutineErrorPathTests (3)、ImportRoutineManagementCommandTests (3)、ImportRoutineAPITests (4)。用真实 BD2 routine.json 路径，setUp 创建 8 个匹配 name 的 Pipeline 行。
6. backend/pipeline/tests/test_chain_executor.py — 把现有测试的 `data['first_task_name']` 改成 `data['first_ref_name']` + 加 `first_node_type='task'` 断言（Phase 2 改了字段名但漏改测试，pre-commit 后 pytest 暴露）。
