---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-15-td110-phase3-routine-converter/
load_when: [evidence, 3-step-evidence, td110, routine-converter]
priority: high
symptom: [td110-phase3, routine-converter, chain-pipeline-node, missing-converter]
solution: TD-110 Phase 3 — routine.json 转 TaskChain 转换器 (service + command + API)
related_files:
  - backend/pipeline/services.py
  - backend/pipeline/management/commands/import_routine.py
  - backend/pipeline/views.py
  - backend/pipeline/tests/test_routine_converter.py
  - docs/general/specs/2026-07-14-td110-routine-taskchain-converter.md
created_by: AI
last_updated: 2026-07-15
---
## Problem（症状 / 触发条件）

TD-110 Phase 1+2 已经让 TaskChainNode 支持 node_type=PIPELINE 并打通了 dispatch 分流，但 BD2 仓库自带的 `resources/BrownDust-II/routine.json` (8 个 pipeline 执行顺序) 仍然无法变成可执行的 TaskChain — 没有导入路径，用户只能手动在 UI 里逐个创建 8 个 PIPELINE 节点。Routine.json 的 8 个 pipeline name 必须解析到 DB 中的 Pipeline 行才能挂到 TaskChainNode 上，缺少这层转换器，Phase 1+2 的能力对最终用户不可达。

## Solution（解决步骤）

1. 在 `backend/pipeline/services.py` 加 `convert_routine_to_chain(routine_path, game_profile_id, user=None)`：读 routine.json → 按 `tasks[].order` 排序 → 用 `Pipeline.objects.filter(name=...)` 解析（多个匹配报错 refuse to guess）→ `transaction.atomic()` 里 `get_or_create` chain + 删旧节点 + 创建 8 个 `node_type=PIPELINE` 节点（幂等：相同 name + game_profile 复用 chain）。
2. 新建 `backend/pipeline/management/commands/import_routine.py` — Django management command `manage.py import_routine <path> --game-profile N [--user U]`，调用 service 并捕获 `RoutineImportError` 转 `CommandError`。
3. 在 `backend/pipeline/views.py` 的 `TaskChainViewSet` 加 `@action(detail=False, methods=['post'], url_path='import_routine')` → `POST /api/v2/pipeline/task-chains/import_routine/`，body `{routine_path, game_profile_id}`，成功 201 + `TaskChainSerializer(chain)`，错误 400。同时把 `execute` action 的 `first_task_name` 改名为 `first_ref_name`（按 node_type 渲染 task.name 或 pipeline.name），加 `first_node_type` 字段。
4. 新建 `backend/pipeline/tests/test_routine_converter.py` (14 个测试)，覆盖 BD2 8 节点转换 + 4 个错误路径 + management command 3 场景 + API 4 场景。

## Verification（验证）

$ conda run -n gaf ruff check backend/pipeline/services.py backend/pipeline/views.py backend/pipeline/management/ backend/pipeline/tests/test_routine_converter.py
预期：All checks passed! (exit 0)

$ conda run -n gaf pytest backend/pipeline/tests/test_routine_converter.py --tb=short -q
预期：14 passed

$ conda run -n gaf pytest backend/pipeline/tests/ --tb=short -q
预期：244 passed, 1 warning (230 existing + 14 new, 零回归)

实际输出（commit 2026-07-15 Beijing）：
- ruff: All checks passed!
- test_routine_converter.py: 14 passed in 15.82s
- 全 pipeline tests: 244 passed, 1 warning in 62.30s
