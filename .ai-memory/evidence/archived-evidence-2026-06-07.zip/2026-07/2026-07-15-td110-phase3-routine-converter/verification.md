---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-15-td110-phase3-routine-converter/
load_when: [evidence, 3-step-evidence, td110, routine-converter]
priority: high
symptom: [td110-phase3, routine-converter, chain-pipeline-node, missing-converter]
solution: TD-110 Phase 3 — Verification 验证结果
related_files:
  - backend/pipeline/services.py
  - backend/pipeline/management/commands/import_routine.py
  - backend/pipeline/views.py
  - backend/pipeline/tests/test_routine_converter.py
  - docs/general/specs/2026-07-14-td110-routine-taskchain-converter.md
created_by: AI
last_updated: 2026-07-15
---
## Verification（验证）

$ conda run -n gaf ruff check backend/pipeline/services.py backend/pipeline/views.py backend/pipeline/management/ backend/pipeline/tests/test_routine_converter.py
预期：All checks passed!
实际：All checks passed! (exit 0)

$ conda run -n gaf pytest backend/pipeline/tests/test_routine_converter.py --tb=short -q
预期：14 passed
实际：14 passed in 15.82s

$ conda run -n gaf pytest backend/pipeline/tests/ --tb=short -q
预期：244 passed, 1 warning (230 existing + 14 new, 零回归)
实际：244 passed, 1 warning in 62.30s (修正 test_chain_executor.py first_task_name → first_ref_name 后零回归)

测试覆盖明细 (test_routine_converter.py 14 tests):
- ConvertRoutineToChainTests:
  - test_convert_routine_creates_chain_with_8_pipeline_nodes — 8 节点 + node_type=PIPELINE + 顺序 1..8 + condition 透传
  - test_convert_routine_pipeline_not_found_raises — 未知 pipeline name → RoutineImportError
  - test_convert_routine_sets_is_default_true — is_default=True
  - test_convert_routine_idempotent — 二次导入复用 chain + 替换节点（删除 stale mutation）
- ConvertRoutineErrorPathTests:
  - test_missing_routine_file_raises — 路径不存在
  - test_invalid_json_raises — 非法 JSON
  - test_ambiguous_pipeline_name_raises — 多个 Pipeline 同名（refuse to guess）
- ImportRoutineManagementCommandTests:
  - test_management_command_creates_chain — 成功路径
  - test_management_command_unknown_user_raises — 未知 user → CommandError
  - test_management_command_missing_pipeline_raises — DB 缺 Pipeline → CommandError
- ImportRoutineAPITests:
  - test_api_import_routine_creates_chain — 201 + chain 数据
  - test_api_import_routine_missing_path_returns_400 — 缺 routine_path
  - test_api_import_routine_missing_profile_returns_400 — 缺 game_profile_id
  - test_api_import_routine_invalid_path_returns_400 — 路径不存在
