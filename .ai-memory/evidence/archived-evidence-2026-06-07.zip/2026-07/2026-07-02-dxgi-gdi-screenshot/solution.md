# Solution: Add backend platform implementations

1. Added `backend/device_bridge/platforms/windows/_dxgi.py` — a pure-ctypes
   DXGI Desktop Duplication capture module adapted from the proven agent-side
   `agent/src/platforms/windows/dxgi_capture.py`. It exposes `DXGICapture`
   with `initialize()`, `capture()`, and `release()` returning a BGR numpy array.
2. Updated `WindowsScreenshotHandler`:
   - `_capture_dxgi()` initializes `DXGICapture`, converts the BGR frame to
     JPEG, and always calls `release()` in a `finally` block.
   - `_capture_gdi()` delegates to the existing BitBlt implementation because
     both methods use the same GDI32 `BitBlt` primitive.
   - `_check_method_available()` now reports DXGI/GDI availability by checking
     whether the corresponding platform module can be found via
     `importlib.util.find_spec`, removing ruff F401 false positives from the
     previous import-in-try pattern.
3. Added `backend/device_bridge/tests/test_screenshot.py` with mocked tests
   covering availability, DXGI success/failure paths, and GDI delegation.
