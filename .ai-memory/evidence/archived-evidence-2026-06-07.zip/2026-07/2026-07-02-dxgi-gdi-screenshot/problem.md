# Problem: DXGI and GDI screenshot backends were stubs

`backend/device_bridge/platforms/windows/screenshot.py` exposed five methods
(WGC / BitBlt / PrintWindow / DXGI / GDI) but `DXGI` and `GDI` returned hard-
coded failure responses. This left Windows PC window capture without the full
method chain described in the architecture docs and prevented benchmarking from
selecting DXGI for high-performance full-desktop capture.
