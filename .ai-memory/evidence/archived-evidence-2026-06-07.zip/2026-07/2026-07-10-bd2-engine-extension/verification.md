# BD2 引擎扩展 — TD-013 + P-006 验证证据

> **日期**: 2026-07-10
> **相关**: TD-013 (BD2 skeleton pipeline 条件分支缺失) + P-006 (pipeline schema 扩展)
> **Commits**: 75311b9 + 47d7d10 + 0a31940 + 9d03e92

---

## 一、Problem（问题）

TD-013 登记于 2026-07-06：BD2-AUTO → GAF 迁移时，2 个 pipeline 的复杂条件分支节点被简化为单一路径：

1. **map_collection.json** — `click_chapter_7` 简化为单一 `template_match`（第七章1.png），缺少第七章2.png 备用模板和 swipe 滑动寻找 fallback。当章节入口不在默认位置时 pipeline 卡死。

2. **pass_activity.json** — `quick_battle_step` 的 if-elif 判断（检测"无法快速战斗"→ 跳过速战或执行速战）未实现，线性 pipeline 在已达 MAX 次数时 click_max 节点失败。

**根因**：GAF 引擎的 `branch` 节点只支持基于变量值的二元跳转，无法直接表达"模板匹配成功与否 → 多目标候选 → 滑动重试"的组合逻辑。

---

## 二、Solution（解决方案）

### 2.1 新增 2 个组合节点（commit 47d7d10）

**`template_match_any`** — 多模板任一匹配：
- config: `templates: List[str]` + `threshold` + `click_on_match` + 可选 `roi`/`scale`
- 顺序尝试每个模板，第一个匹配成功的返回结果
- 通过 `run_child` 创建 `template_match` 子节点 spec 复用现有匹配能力
- 成功时写 `{id}_match_result` 变量（与 template_match 一致）

**`swipe_until`** — 循环滑动直到模板出现：
- config: `templates: List[str]`（多备选）+ `x1/y1/x2/y2` + `max_swipes` + `delay_between`
- 循环：匹配 → 成功则返回 → 失败则 swipe 一次 → 等待 → 重试
- 通过 `run_child` 调用 `template_match_any` + `swipe` 子节点
- `max_swipes` 硬上限防止死锁

### 2.2 提取公共 `_child_runner.py`（commit 75311b9）

从 `composite_match.py` 提取 `_run_child` 函数到 `engine/nodes/_child_runner.py` 作为公共 `run_child()`，供 `composite_match` + `template_match_any` + `swipe_until` 三处复用（DRY 原则）。

### 2.3 修复 2 个 BD2 pipeline（commit 0a31940）

**map_collection.json**：
- `click_chapter_7`: `template_match` → `swipe_until`
- 支持 `[第七章1.png, 第七章2.png]` + `max_swipes: 3`
- 滑动坐标 (960,800)→(960,300) 向上滑（章节列表向下滚动）

**pass_activity.json**：
- `quick_battle` if-elif: 插入 `wait_check_block` + `check_quick_battle_blocked`（检测无法快速战斗.png）+ `branch_quick_battle`
- branch 用 `eq null` 判断变量：未阻止（None）→ click_max；已阻止（dict）→ press_esc_dismiss_block

### 2.4 backend schema 同步（commit 9d03e92）

- `ALL_NODE_TYPES` 添加 `template_match_any` + `swipe_until` + `direct_hit`（预存补全，N150）
- `node_required` 添加对应必填字段

---

## 三、Verification（验证）

### 3.1 单元测试（3 步验证 — N128）

**Step 1: Glob 确认文件存在**
```
agent/src/engine/nodes/_child_runner.py          ✅ 存在
agent/src/engine/nodes/template_match_any.py      ✅ 存在
agent/src/engine/nodes/swipe_until.py             ✅ 存在
agent/tests/test_template_match_any.py            ✅ 存在
agent/tests/test_swipe_until.py                   ✅ 存在
```

**Step 2: Grep 确认注册装饰器**
```
@register_node("template_match_any")  → template_match_any.py:30  ✅
@register_node("swipe_until")         → swipe_until.py:46         ✅
```

**Step 3: pytest 确认测试通过**
```
tests/test_template_match_any.py: 13 passed  ✅
tests/test_swipe_until.py:        11 passed  ✅
tests/test_composite_match.py:    27 passed  ✅ (无回归)
───────────────────────────────────────────
Total:                            51 passed
```

### 3.2 全量 agent 测试无回归

```
1215 passed, 9 failed, 2 skipped (84.25s)
```

9 个 failed 全部是预存错误（非本轮变更导致）：
- `test_pipeline_engine.py` 3 个：模板图片加载失败（需要真实 .png 文件）
- `test_device_abstraction.py` 1 个：模拟器发现（环境相关）
- `test_resource_monitor.py` 2 个：MagicMock 断言
- `test_retry.py` 2 个：WebSocket 重试 mock
- `test_screenshot_dxgi.py` 1 个：DXGI 释放

另 3 个收集错误（`test_input_*` / `test_window_pos_mouse_hook`）：`_INPUT_UNION` import 缺失，预存错误（登记 TD-062）。

### 3.3 backend schema 验证

```python
from pipeline.schema import ALL_NODE_TYPES
assert 'template_match_any' in ALL_NODE_TYPES  ✅
assert 'swipe_until' in ALL_NODE_TYPES         ✅
assert 'direct_hit' in ALL_NODE_TYPES          ✅ (预存补全)
```

### 3.4 pipeline JSON 验证

```python
# map_collection.json
d = json.load(open('resources/BrownDust-II/pipelines/map_collection.json'))
assert any(n['type']=='swipe_until' for n in d['nodes'])  ✅
# swipe_until config: templates=[第七章1.png, 第七章2.png], max_swipes=3

# pass_activity.json
d = json.load(open('resources/BrownDust-II/pipelines/pass_activity.json'))
br = [n for n in d['nodes'] if n['type']=='branch'][0]
assert br['config']['condition_variable'] == 'check_quick_battle_blocked_match_result'  ✅
assert br['config']['true_node_id'] == 'click_max'      ✅
assert br['config']['false_node_id'] == 'press_esc_dismiss_block'  ✅
```

### 3.5 节点注册验证

```python
from engine.node import PIPELINE_NODE_REGISTRY
assert 'template_match_any' in PIPELINE_NODE_REGISTRY  ✅ -> TemplateMatchAnyNode
assert 'swipe_until' in PIPELINE_NODE_REGISTRY         ✅ -> SwipeUntilNode
```

---

## 四、结论

TD-013 两处条件分支缺失已全部修复：
- map_collection: swipe_until 多模板 + 滑动重试 ✅
- pass_activity: branch + template_match if-elif ✅

P-006 pipeline schema 扩展已完成：新增 2 个组合节点 + backend schema 同步。

**状态标记**：
- TD-013: 🔧 待修 → ✅ FIXED (commits 75311b9 + 47d7d10 + 0a31940 + 9d03e92)
- P-006: ⏳ 待实现 → ✅ 已完成

**已知遗留（B 类后续 Phase）**：
- 前端编辑器节点 palette 未添加新节点类型（B 类，本轮不执行）
- 2 个 BD2 pipeline 的 e2e 验证（滑动坐标/branch 逻辑需实际游戏环境校准）
- `_INPUT_UNION` 预存 import 错误（登记 TD-062）
