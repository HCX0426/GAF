# spec34 Phase 1 — Solution

## 文件清单 (4 个)

### 1. `backend/gaf_core/audit_constants.py` (新建)

**AuditResourceType 类** — 37 个 string 常量, 覆盖前端 AuditLogPage 已有 8 个 +
Phase 2-3 新增 29 个 (user/task/device/agent/pipeline/resource/plugin/schedule/
notification/monitor/qa/gamestate/execution/chain_step/session/event/log/
config/role/permission/group/device_group/game_account/chain/template/
debug_session/breakpoint/screenshot/clipboard/file_transfer/...)。

`all_values()` classmethod 返回所有合法值 set (供未来模型层 choices 验证用)。

**AuditAction** — re-export `AuditLog.Action` (8 项 TextChoices: LOGIN/LOGOUT/
CREATE/UPDATE/DELETE/ENABLE/DISABLE/EXECUTE)。

**SENSITIVE_FIELD_NAMES** — frozenset, 21 个敏感字段名 (password/token/secret/
api_key/credential/authorization/cookie/private_key/...)。小写比较, 否认表模式。

**get_client_ip(request)** — `X-Forwarded-For` 第一 IP (逗号分隔) → `REMOTE_ADDR`
fallback; 39 字符截断 (IPv6 max length); 接受任何有 `META` 属性的对象 (DRF Request
或 HttpRequest 均可)。

**filter_sensitive_fields(data, extra_sensitive=None)** — 输入 dict, 输出新 dict
(保留敏感键的存在性, 值替换为 `"<redacted>"`); 接受调用方额外敏感字段 set。

### 2. `backend/gaf_core/mixins/audit.py` (新建)

**AuditMixin 类** — DRF ViewSet mixin, 类属性配置 + perform_* hook:
- `audit_resource_type: str | None = None` (None 时 fallback 到 instance._meta.model_name)
- `audit_resource_id_attr: str = "pk"` (resource_id 从该属性取)
- `audit_log_create/update/destroy: bool = True` (per-action 开关)
- `perform_create` → `_log_audit(CREATE, instance)`
- `perform_update` → 先 `get_object()` 缓存 old_instance, super().perform_update, 再 `_log_audit(UPDATE, instance, old_instance=old_instance)`
- `perform_destroy` → 先 `_log_audit(DELETE, instance)` 再 super().perform_destroy
- `_log_audit` lazy import `accounts.audit.log_audit` (防循环 import)
- `_build_audit_details(action, instance, old_instance=None) -> dict` 默认空 dict,
  子类可重写以提供 before/after diff

**@audit_action(action, resource_type, resource_id_kw="pk") 装饰器** —
包裹 `@action` 方法 (装饰器就近原则: 必须在 `@action` 内层):
- 调原方法 → 成功后写审计 (异常自动 re-raise, 不写)
- details = `{endpoint, method, kwargs}`
- resource_id 从 URL kwargs 取 (默认 "pk")

**build_diff_details(before, after, sensitive_extra=None) -> dict** —
helper 用于子类 `_build_audit_details`:
- `{before: {...}, after: {...}}` 形状
- before=None 仅 after (create); after=None 仅 before (delete)
- 自动调 `filter_sensitive_fields`

### 3. `backend/gaf_core/mixins/__init__.py` (修改)

原仅导出 `JWTAuthMixin`, 新增 re-exports:
- `AuditAction, AuditMixin, AuditResourceType, audit_action, build_diff_details`

调用方统一从 `gaf_core.mixins` import, 无需知道文件布局。

### 4. `backend/gaf_core/tests/test_audit_mixin.py` (新建, 31 tests)

8 个测试类:
1. `TestAuditMixinPerformCreate` (3 tests) — perform_create 写 CREATE 审计
2. `TestAuditMixinPerformUpdate` (4 tests) — perform_update 写 UPDATE + old_instance 传入
3. `TestAuditMixinPerformDestroy` (3 tests) — perform_destroy 写 DELETE
4. `TestAuditMixinConfiguration` (5 tests) — audit_log_create=False 等开关 + audit_resource_type fallback
5. `TestAuditActionDecorator` (5 tests) — @audit_action 成功写审计 + 异常不写
6. `TestBuildDiffDetails` (4 tests) — before/after 形状 + 敏感字段 redact
7. `TestGetClientIp` (4 tests) — X-Forwarded-For / REMOTE_ADDR / 截断 / 空 META
8. `TestLogAuditIntegration` (3 tests) — 端到端写入 AuditLog 行 + AuditResourceType 唯一性

**测试 fixtures**:
- `_FakeInstance` — mock 模型实例 (pk + 任意 attrs + _meta.model_name)
- `_FakeSerializer` — mock DRF serializer (.instance + .save())
- `_DummyViewSet` — 真实 AuditMixin 子类 (重写 get_object 返回 _old_instance,
  避免 ModelViewSet 默认 queryset 依赖)

**修复历程** (2 个 test bug):
1. `test_build_audit_details_hook_called_with_correct_args` — _HookedViewSet 原继承
   `AuditMixin, viewsets.ModelViewSet` (无 get_object 重写), old_instance 永远 None;
   改继承 `_DummyViewSet` (有 get_object 返回 _old_instance)
2. `test_audit_log_row_created` — 断言 `ip_address is None` 错误 (APIRequestFactory
   默认设置 REMOTE_ADDR='127.0.0.1', get_client_ip 正确返回该值); 改为
   `== "127.0.0.1"`

## 关键设计决策

### 为什么用 Mixin 而非装饰器全包?
- DRF ViewSet 已有 perform_create/update/destroy hook, mixin 覆盖最自然
- 类属性配置 (`audit_resource_type` 等) 比 decorator args 更易继承/重写
- @audit_action 装饰器仅用于 `@action` 自定义端点 (无法走 perform_*)

### 为什么 lazy import?
`gaf_core.mixins.audit` import `accounts.audit` 会触发 `accounts.models` 加载,
而 `accounts.models` 可能 import `gaf_core.mixins`, 形成循环。lazy import (函数体内
import) 延迟到调用时, 模块加载时无循环。

### 为什么 sensitive fields 用 deny-list?
- allow-list 需列举所有合法字段, 维护成本高 (40+ ViewSet, 字段数 100+)
- deny-list 集中管理已知敏感字段名 (password/token/...), 误判风险低
- 调用方可通过 `extra_sensitive` 临时扩展 (per-resource)
