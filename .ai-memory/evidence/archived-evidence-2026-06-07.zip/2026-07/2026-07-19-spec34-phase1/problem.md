# spec34 Phase 1 — Problem

## 背景
AuditLog 模型自 R37-P3 Stage 7 Task 20a (2026-07-08) 从 tasks 迁到 accounts 后,
`accounts/audit.py::log_audit` 0 调用方 (审计日志数据 = 0 行), 形同虚设。

L3-1 全量扫描 (2026-07-19) 在 §3 集成层 + §6 业务逻辑层标记为 P0 缺陷:
> 审计日志基础设施存在但未接入, 任何资源变更 (用户/任务/设备等) 都无审计追踪。

## Phase 1 范围
Phase 1 是基础设施层, 不接入任何 ViewSet。产物:
1. `backend/gaf_core/audit_constants.py` — 全仓库共享常量 + helper
2. `backend/gaf_core/mixins/audit.py` — AuditMixin + @audit_action 装饰器
3. `backend/gaf_core/mixins/__init__.py` — re-exports
4. `backend/gaf_core/tests/test_audit_mixin.py` — 31 个测试用例

## 验收门槛
- 31/31 tests pass
- AuditMixin.perform_create/update/destroy 自动调 log_audit
- @audit_action 装饰器仅成功时写审计
- 敏感字段自动 redact
- get_client_ip 支持 X-Forwarded-For + REMOTE_ADDR
