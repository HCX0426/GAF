# spec34 Phase 1 — Verification

## 测试运行

```
$ conda run -n gaf python -m pytest backend/gaf_core/tests/test_audit_mixin.py --tb=short -q
...............................                                          [100%]
31 passed in 14.31s
```

**结果**: 31/31 passed (14.31s)

## 测试覆盖矩阵

| 测试类 | 测试数 | 覆盖内容 |
|--------|--------|---------|
| TestAuditMixinPerformCreate | 3 | perform_create 写 CREATE 审计 + log_create 开关 |
| TestAuditMixinPerformUpdate | 4 | perform_update 写 UPDATE + old_instance 传入 + log_update 开关 |
| TestAuditMixinPerformDestroy | 3 | perform_destroy 写 DELETE + log_destroy 开关 |
| TestAuditMixinConfiguration | 5 | audit_resource_type fallback (model_name) + audit_resource_id_attr |
| TestAuditActionDecorator | 5 | @audit_action 成功写审计 + 异常 re-raise 不写 + resource_id_kw |
| TestBuildDiffDetails | 4 | before/after 形状 + 敏感字段 redact + extra_sensitive |
| TestGetClientIp | 4 | X-Forwarded-For 第一 IP + REMOTE_ADDR + 截断 + 空 META |
| TestLogAuditIntegration | 3 | 端到端写入 AuditLog 行 + AuditResourceType 37 常量唯一性 |
| **总计** | **31** | |

## 关键断言验证

### AuditMixin.perform_create
- ✅ 调 `log_audit(CREATE, instance)` 1 次
- ✅ `resource_type` 从 `audit_resource_type` 类属性取
- ✅ `resource_id` 从 `instance.pk` 取
- ✅ `audit_log_create=False` 时不写审计

### AuditMixin.perform_update
- ✅ `old_instance` 通过 `get_object()` 在 super().perform_update 之前取
- ✅ 传入 `_log_audit(UPDATE, instance, old_instance=old_instance)`
- ✅ `_build_audit_details` hook 收到正确 args (action, instance, old_instance)

### @audit_action 装饰器
- ✅ 成功时写审计 (1 次)
- ✅ 异常时 re-raise + 不写审计
- ✅ resource_id 从 URL kwargs 取
- ✅ details 含 endpoint + method + kwargs

### build_diff_details
- ✅ before=None → `{after: {...}}` (create)
- ✅ after=None → `{before: {...}}` (delete)
- ✅ 敏感字段值替换为 `"<redacted>"` (保留键存在性)
- ✅ extra_sensitive 临时扩展 deny-list

### get_client_ip
- ✅ X-Forwarded-For "1.2.3.4, 5.6.7.8" → "1.2.3.4" (取第一 IP)
- ✅ 无 X-Forwarded-For → REMOTE_ADDR
- ✅ > 39 字符截断 (IPv6 max length)
- ✅ 无 META → None

### AuditResourceType
- ✅ 37 个常量值唯一 (无重复)
- ✅ all_values() 返回所有合法值 set

### log_audit 端到端
- ✅ AuditLog 行实际写入测试 DB
- ✅ user 关联正确
- ✅ resource_id == "1"
- ✅ ip_address == "127.0.0.1" (APIRequestFactory 默认)

## Lint / Type check
- ✅ pre-commit hooks 全过 (ruff + mypy + format)

## 文件清单
- `backend/gaf_core/audit_constants.py` (新建, ~80 行)
- `backend/gaf_core/mixins/audit.py` (新建, ~120 行)
- `backend/gaf_core/mixins/__init__.py` (修改, 8 → 22 行)
- `backend/gaf_core/tests/test_audit_mixin.py` (新建, ~500 行)

## Phase 1 完成判据
- ✅ 31/31 tests pass
- ✅ AuditMixin + @audit_action + build_diff_details 全部 export 自 `gaf_core.mixins`
- ✅ audit_constants.py 提供共享常量 + helper
- ✅ 敏感字段自动 redact
- ✅ lazy import 防循环
