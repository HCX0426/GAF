# Verification: spec-15 5 Phase 修复验证

## 自动化验证

### sync_skills.py --check ✅
```
✅ 4 skills + 1 rule 副本一致 (4 skill 副本 + 1 rule 副本):
   GAF 根(workspace root): 4 skill + 1 rule
   决策树权威源: gaf-orchestrator (v9.0 单一权威源)
   父级同步: 已禁用 (v8.5: GAF 即 workspace 根)
```

### sync_ai_memory.py ✅
```
✅ sync_ai_memory: regenerated=4 skipped=104 read-only=0 conflict=0 warning=117
```
- lessons_count=54 不变 (符合预期, spec-15 不新增 lesson 文件)

### Grep 验证 "10 个 topic sub-file" 在 active 文档 ✅
- project_rules.md: 0 处 (L12/L36/L496 全部改为 8)
- 5 个 gaf-* skills: 0 处 (gaf-orchestrator/gaf-reflect-and-evolve/gaf-knowledge-base/gaf-lesson-router 全部改为 8)
- yn-matrices.md: 0 处 (本身不含 "10 个" 计数)
- _misc.md: 0 处 (L10 "10 → 8" 已修复)
- 历史记录保留: specs/ + completed-features.md (历史 spec 不改)

### Grep 验证 "13 个 topic" 在 .ai-memory ✅
- .ai-memory/README.md L111: 0 处 (改为 "20 个 topic")

## pre-commit hook 验证

### gaf-3step-evidence ✅ (创建 evidence 目录后通过)
- 目录: .ai-memory/evidence/2026-07-18-spec15-drift-fix/
- 文件: problem.md + solution.md + verification.md

### gaf-yn-matrices-index ✅ (扩展正则后通过)
- 修复: scripts/hooks/check_yn_matrices_index.py L56-57
- 正则: `[①-⑳㉑-㉛]` → `[①-⑳㉑-㊿]` (覆盖 1-50 圆圈数字)
- 验证: _workflow.md 的 ㉝/㉞/㉟/㊱ ### heading 现在能被正确匹配

## 手动验证 (N166 L3-5 — 但用户限制 "其他的先不检查")

按用户原始指令 "其他的先不检查，就一直检查这个" + spec-15 是纯文档 drift 修复 (无业务代码改动), L3-5 实测验证 (浏览器/WS/Agent) 不适用。验证以自动化检查 (sync_skills/sync_ai_memory/Grep) + pre-commit hook 通过为准。

## 阶段状态表

| Phase | 内容 | 状态 | 验收 evidence |
|:-----:|------|:----:|--------------|
| 1 | rules + handbook (R7-1 + R7-2) | ✅ | project_rules.md 3 处 "10→8" + handbook L139 "N162→N157" |
| 2 | yn-matrices (R7-3 + R7-4) | ✅ | yn-matrices.md L32 追加 N164/N165/N166 + _misc.md L10 "10→7" 改 "10→8" |
| 3 | 5 skills (R7-5 ~ R7-9) | ✅ | 4 skills "10→8" + gaf-lesson-router L19-30 重组 + gaf-reflect-and-evolve L67 "N162→N164+N166" |
| 4 | README + tech-debt (R7-10 + R7-11 + R7-12) | ✅ | .ai-memory/README.md "13→20 topic" + TD-140 "10→8" + TD-187 sub-file 列表更新 |
| 5 | 验证 + commit | ✅ | sync_skills --check + sync_ai_memory + Grep 全部通过; pre-commit hook 2 个根因修复 |

## commit

- commit hash: (待 commit 后回填)
- 文件变更: 16 files changed (13 修改 + 1 新增 spec-15 + 2 evidence + 1 hook 修复)
