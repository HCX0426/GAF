# Problem: spec-14 后遗 sub-file 计数 drift

## 症状

spec-14 Phase 2 合并 3 个 yn-matrices sub-file (`_concurrency.md` + `_browser-automation.md` + `_control-message-routing.md`) 到 `_misc.md` (10→8 sub-file), 但未同步更新引用方的 sub-file 计数 + N## 引用。Round 7 L3-1 子 agent A 扫描发现 12 处 drift (10 [A] + 2 [B])。

## 影响

- AI 加载决策受影响: gaf-lesson-router/SKILL.md L20-30 把已合并的 topic (concurrency/browser-automation/control-message-routing) 当独立 sub-file 加载, AI 实际 Read 会失败 (文件不存在)
- 文档计数不一致: project_rules.md / handbook / 5 skills / yn-matrices.md / _misc.md 多处 "10 个" 应为 "8 个"
- N## 引用错误: handbook L139 "N126/N128/N162" 中 N162 已 dormant; gaf-reflect-and-evolve L67 "spec 文件 → N162" 同样引用 dormant N##
- 数学错误: _misc.md L10 "10 → 7" 应为 "10 → 8" (10 - 3 + 1 = 8)

## 根因

spec-14 Phase 5 只清理了 loading-strategy 引用, 未清理 sub-file 计数引用 + N## 引用。spec-14 改动不完整。

## 范围

12 个 drift 问题:
- 10 [A] 类 (R7-1 ~ R7-9 + R7-12): P1/P2, 均 < 10 行 diff
- 2 [B] 类 (R7-10 + R7-11): tech-debt/active.md 内部描述过期 (TD-140/TD-187)
