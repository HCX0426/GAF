# Solution: spec-15 5 Phase 修复 12 处 drift

## Phase 1: rules + handbook (R7-1 + R7-2)
- R7-1: project_rules.md 3 处 "10 个" → "8 个" (L12 mermaid / L36 5层职责 / L496 §6.4)
- R7-2: ai-operating-handbook.md L139 "N126/N128/N162" → "N126/N128/N157"
  - N162 已 dormant (合并到 N160), 不应引用
  - N157 = AI memory 文档虚构实现, 与本段 "related_files 猜路径" / "引用 skill/doc/path 不验证" 主题一致

## Phase 2: yn-matrices (R7-3 + R7-4)
- R7-3: yn-matrices.md L32 workflow 行追加 N164, N165, N166 (实际 _workflow.md 含这些 N## 的 ### heading)
- R7-4: _misc.md L10 "10 → 7" → "10 → 8" (数学错误: 10 - 3 + 1 = 8, 不是 7)

## Phase 3: 5 个 gaf-* skills (R7-5 ~ R7-9)
- R7-5: gaf-orchestrator/SKILL.md L248 "10 个" → "8 个"
- R7-6: gaf-reflect-and-evolve/SKILL.md L98 "10 个" → "8 个"
- R7-7: gaf-knowledge-base/SKILL.md L57 "10 个" → "8 个"
- R7-8: gaf-lesson-router/SKILL.md L19-30 "10 个" + 删除 3 个旧 topic 行 (concurrency/browser-automation/control-message-routing) + 追加 misc 合并行
- R7-9: gaf-reflect-and-evolve/SKILL.md L67 "N162" → "N164 + N166"
  - N164 = L1/L2 不加载教训内容 (与 spec 文件场景相关)
  - N166 = L3 持续评估循环 + 沉淀纪律 (与 spec 文件场景相关)

## Phase 4: .ai-memory/README + tech-debt (R7-10 + R7-11 + R7-12)
- R7-12: .ai-memory/README.md L111 "13 个 topic" → "20 个 topic"
- R7-10: tech-debt/active.md TD-140 "10 个 sub-file" → "8 个 sub-file" + 注释追加 spec-14 合并说明
- R7-11: tech-debt/active.md TD-187 更新 sub-file 列表 (删除 3 个已合并文件名, 加 _misc/_refactor-dimensions/_workflow)

## Phase 5: 验证 + commit
- sync_skills --check ✅
- sync_ai_memory ✅ (lessons_count=54 不变)
- Grep "10 个 topic sub-file" 在 active 文档: 0
- Grep "13 个 topic" 在 .ai-memory: 0

## 附带修复 (pre-commit hook 失败根因修复)

commit 时 2 个 pre-commit hook 失败, 按 §3.3 N150 根因修复:

1. **gaf-3step-evidence hook**: 需要 evidence 目录 (2026-07-18-spec15-drift-fix/)
2. **gaf-yn-matrices-index hook**: 正则 `[①-⑳㉑-㉛]` 只到 ㉛(27), 但 _workflow.md 用 ㉝(28)/㉞(29)/㉟(35)/㊱(36) 超出范围
   - 修复: 扩展正则到 `[①-⑳㉑-㊿]` (1-50) 覆盖所有圆圈数字
   - 文件: scripts/hooks/check_yn_matrices_index.py L56-57
