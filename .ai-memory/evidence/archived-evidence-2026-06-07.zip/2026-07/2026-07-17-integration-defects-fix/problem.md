## Problem（症状 / 触发条件）

集成层 4 个缺陷导致 task 执行流程断裂 + 死代码堆积:

1. **I1 (P0) WS task.result 协议不一致**: agent 完成 task 后发送 `task.result` 消息 (含 success 字段), 但 `backend/agents/consumers.py:108-117` handler_map 无 `task.result` 处理器 → backend 回复 `{'type': 'error', 'message': '未知的消息类型: task.result'}` → TaskExecution.status 永远停留 `running` + Device.status 永远停留 `BUSY`
2. **I2 (P1) devices/discover 死端点**: `frontend/src/api/devices.ts` 的 `discoverDevices()` 调用 `POST /devices/discover/`, 但 `DeviceCenterPage.tsx` 的 `handleDiscover` 实际用的是 `apiScanDevices` → `discoverDevices()` 是死代码, 在 store/page/test 3 处残留引用
3. **I3 (P2) backend/agent_client.py 双套并存**: 441 行独立 stub 进程, `handle_task_dispatch` 是 mock 实现 (sleep 0.2s 后报 success), 与真实 `agent/src/` 重叠, 无真实 import
4. **I4 (P2) backend/docs/ 死 app**: Django scaffold 残留 — apps.py 存在, models.py/views.py 是空模板, urls.py 注册空 router, 已注册到 `config/settings/base.py:49` INSTALLED_APPS

影响范围: backend/agents + frontend/src/{api,stores,pages/Devices} + backend/{agent_client.py,docs/,config/settings}
