## Solution（解决步骤）

1. 在 `backend/agents/consumers.py:108-117` handler_map 添加 `'task.result': self._handle_task_result`, 新建 `_handle_task_result(self, data)` 根据 `success` 字段分发到 `_handle_task_completed` / `_handle_task_failed`
2. 删除 `frontend/src/api/devices.ts` 的 `discoverDevices()` 函数 + `frontend/src/stores/useDeviceStore.ts` 的 import/interface/implementation + `frontend/src/pages/Devices/DeviceCenterPage.tsx` 的 destructure + `frontend/src/pages/Devices/__tests__/Devices.test.tsx` 的 mock
3. 将 `backend/agent_client.py` 移动到 `.trash/backend-agent_client-20260716.py` (grep 确认无真实 import, 仅 window_info.py 注释引用)
4. 将 `backend/docs/` 目录移动到 `.trash/backend-docs-20260716/` + 从 `backend/config/settings/base.py:49` INSTALLED_APPS 删除 `"docs"`
5. 在 `docs/general/tech-debt/active.md` 追加 TD-128~TD-133 (B1-B5/B7: FK on_delete/字段冗余/废弃字段/e2e 缺口/死端点)
