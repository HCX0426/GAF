---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-19-l3-round1-scan-fixes/
load_when: [evidence, 3-step-evidence, L3-scan, reflection]
priority: high
symptom: [kb:evidence-l3-round1, A-class-fixes, subagent-parallel]
solution: [A] 类 8 项小修复 (subagent 并行 2 个) + [B] 类 TD-259 汇总登记
related_files:
  - .ai-memory/evidence/2026-07-19-l3-round1-scan-fixes/problem.md
  - .ai-memory/evidence/2026-07-19-l3-round1-scan-fixes/verification.md
  - docs/general/tech-debt/active.md
created_by: AI
last_updated: 2026-07-19
---
## Solution（修复方案 + 实际执行）

### [A] 类 8 项小修复 (subagent 并行, 每个 < 500 行 diff)

#### subagent 1: 前端 3 项 (47 文件)
1. **Space `orientation` → `direction`** (P0, 31 文件 63 处) — antd v6 Space prop 名是 `direction`, `orientation` 被静默忽略导致水平渲染。全局替换 `<Space orientation="vertical">` → `<Space direction="vertical">`
2. **interveneModal executionId 类型** (P1, 1 行) — `frontend/src/pages/Ops/Executions/index.tsx:590` `executionId: ''` (string) → `executionId: 0` (number), 与 line 158 `useState<{...; executionId: number}>` 一致
3. **dayjs.locale 集中** (P1, 14 文件) — 13+ 文件模块顶层重复 `dayjs.locale('zh-cn')`, 移到 `frontend/src/main.tsx` 入口处一次性调用, 删除文件内重复调用

#### subagent 2: 后端 5 项 (4 文件)
4. **system_status_view 权限收紧** (P1, 1 行) — `backend/monitors/views.py:154` `AllowAny` → `IsAuthenticated`, 防止未登录用户探测系统规模
5. **WS 字段归一化 "data" → "payload"** (P1, 3 处) — `accounts/services.py:30` + `tasks/views.py:147,371` 的 `channel_layer.group_send(..., {"data": ...})` → `{"payload": ...}`, 与 protocol/consumers.py + 前端 WS client 一致
6. **transaction.on_commit** (P1, 1 处) — `protocol/consumers.py:609` `advance_chain_execution.delay(...)` → `transaction.on_commit(lambda: advance_chain_execution.delay(...))`, 防止事务未提交时 Celery 读旧数据
7. **N+1 修复** (P1, 2 处) — `tasks/views.py` TaskExecutionViewSet + TaskViewSet 加 `select_related` + `prefetch_related` (queryset 属性 + get_queryset 方法两处都改, 符合 §2.0 三原则)
8. **事务包裹** (P1, 2 处) — `tasks/views.py` execute action (TaskExecution.create + game_accounts.update) + cancel action (for 循环 save) 用 `with transaction.atomic():` 包裹; execute 的 dispatch_task.delay 用 transaction.on_commit; 删除 line 131 死代码 `[e.id for e in running_executions]`

### [B] 类 TD-259 汇总登记 (主会话)

- active.md 顶部清单追加 TD-259 行 (P2 汇总)
- active.md 底部追加 TD-259 详细段 (32 项按 9 维度分组, 每项含位置/现象/修复方向)
- [B] 类含: P0 大改动 (AuditLog 接入) + P1 大改动 (execution_intervene_view select_for_update + .catch + ACK) + P2/P3 (30+ 项)
- [B] 类何时修: 按优先级 + 维度分批接修; P0 (AuditLog + TD-141 提升) 优先

### 执行方式 (N172 subagent 并行)

- 2 个 general_purpose_task subagent 并行 (前端 + 后端, 无文件冲突)
- 主会话同时登记 [B] 类 TD-259
- subagent 完成后 git add -A 暂存, 主会话统一 commit
- N175 落地检查: subagent 1 (3 项) + subagent 2 (5 项) + 主会话 (TD-259) = 8 [A] + 1 [B] 全部落地
