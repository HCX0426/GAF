---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-19-l3-round1-scan-fixes/
load_when: [evidence, 3-step-evidence, L3-scan, reflection]
priority: high
symptom: [kb:evidence-l3-round1, verification, tsc-pytest-pass, grep-confirm]
solution: 前端 tsc 0 errors + vitest 153 passed; 后端 pytest 252 passed + django check 0 issues; grep 确认 3 项归一化
related_files:
  - .ai-memory/evidence/2026-07-19-l3-round1-scan-fixes/problem.md
  - .ai-memory/evidence/2026-07-19-l3-round1-scan-fixes/solution.md
  - docs/general/tech-debt/active.md
created_by: AI
last_updated: 2026-07-19
---
## Verification（验证命令 + 实际输出）

### subagent 1 前端验证 (在 `d:\code\GAF\frontend` 下)

```
$ npx tsc --noEmit
# exit 0, 0 errors (1.25s)

$ npx vitest run
# 20 test files / 153 tests passed, 0 failed (20.25s)

$ Grep `orientation="vertical"` 全仓
# 0 匹配 ✓ (除 react-resizable-panels 的 Group, 非本任务范围)

$ Grep `dayjs.locale('zh-cn')` 全仓
# 只在 frontend/src/main.tsx:17 出现 1 次 ✓
```

### subagent 2 后端验证 (在 `d:\code\GAF` 下)

```
$ conda run -n gaf python -m pytest backend/tasks/ backend/monitors/ backend/protocol/ --tb=short -q
# 252 passed in 49.58s ✓ (3 app 全套, 全过)

$ conda run -n gaf python -m django check --settings=config.settings.dev
# System check identified no issues (0 silenced) ✓

$ Grep `channel_layer.group_send` 中 `"data":` 发送端
# 只剩 protocol/tests/test_message_frame.py:507 (兼容代码测试, 符合任务要求不应改) ✓
```

### N175 落地检查

- subagent 1 (前端): 3 项 [A] 类 → 47 文件 (Space 31 文件 + interveneModal 1 + dayjs 14 + main.tsx 1)
- subagent 2 (后端): 5 项 [A] 类 → 4 文件 (monitors/views + accounts/services + protocol/consumers + tasks/views)
- 主会话: [B] 类 TD-259 登记 → 1 文件 (active.md)
- 合计: 8 [A] + 1 [B] 全部落地, 无丢失 ✓

### 性能基线 (N171)

- pytest 252 tests / 49.58s: 3 app 全套, 超 30s 基线但 < 60s, 可接受 (全套非单文件)
- django check < 5s ✓
- tsc 1.25s ✓
- vitest 20.25s: 20 文件全套, < 30s 全套基线 ✓
- governance batch 1.30s (9/10 passed, 仅 3-step evidence fail 因本次未创建 evidence 目录, 本 evidence 创建后修复)

### git commit evidence

- commit message: `fix(l3-1): [A] class 8 small fixes (frontend 3 + backend 5) + TD-259 [B] class registration`
- 50 files changed, 136 insertions(+), 129 deletions(-)
- pre-commit hooks: governance batch (9/10 passed after evidence created) + N105 MM state guard passed
