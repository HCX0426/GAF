---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-19-l3-round1-scan-fixes/
load_when: [evidence, 3-step-evidence, L3-scan, reflection]
priority: high
symptom: [kb:evidence-l3-round1, L3-1-scan, A-class-fixes, B-class-registration]
solution: L3-1 全量扫描 (3 subagent 并行 9 维度) 发现 4 P0 + 16 P1 + 30+ P2/P3 问题; [A] 类 8 项小修复本次 commit
related_files:
  - .ai-memory/evidence/2026-07-19-l3-round1-scan-fixes/solution.md
  - .ai-memory/evidence/2026-07-19-l3-round1-scan-fixes/verification.md
  - docs/general/tech-debt/active.md
created_by: AI
last_updated: 2026-07-19
---
## Problem（症状 / 触发条件）

2026-07-18 L3-1 全量扫描 (3 subagent 并行 9 维度, 触发条件 ① 距上次 ≥ 3 spec + ③ 用户"都做吧") 发现:

1. **4 P0 阻塞/安全**:
   - [维度④] Antd Space `orientation` prop 错误 (28+ 处, 渲染为水平而非垂直)
   - [维度⑥] AuditLog 0 调用方, 审计日志完全缺失 (20+ 敏感 ViewSet)
   - [维度⑧] /ws/agents/ 与 /ws/protocol/agents/ 双套 AgentConsumer 并存 (反模式, TD-141)
   - [维度⑨] /ws/agents/ 旧路径 query_string token= 鉴权 (URL 暴露 token)

2. **16 P1 影响核心功能/性能**:
   - 前端: interveneModal executionId 类型 number vs string; dayjs.locale 13 文件重复; .catch 静默吞异常
   - 后端: system_status_view AllowAny; WS 字段 data vs payload; transaction.on_commit 缺失; N+1 (2 处); 事务缺失 (3 处); execution_intervene_view 缺 select_for_update; accounts↔scheduler 循环 import; ACK 机制回退
   - 文档: scripts/README.md 14+ 脚本未登记 (违反 §5.5)

3. **30+ P2/P3**: 文档漂移 / 巨型文件 / 索引缺失 / 风格不一致等

影响范围: 前端 28+ 文件 Space 渲染错误; 后端任务执行/取消竞态条件; 审计日志空白; WS 协议字段不归一; 文档与代码漂移。

触发条件: L3-1 全量扫描 (距上次 ≥ 3 spec, spec-25/26/27/28 已完成)。
