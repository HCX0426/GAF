# Solution

## Spec
`docs/general/specs/2026-07-17-ai-thinking-workflow-rules-sync.md` (5 阶段, §4.10 Spec 分阶段协议)

## Phase 1: skill 层 N166/N167 同步 (A1-A4, A7)
- A1: gaf-reflect-and-evolve §7 四维度→七维度评分模板 (满分 21, 阈值 ≥19 且领先 ≥5)
- A2: gaf-task-execution step_5 commit 粒度 "每大阶段 1 次" → "任务粒度自决" + 状态文档同步
- A3: gaf-orchestrator 新增 "L3 持续评估循环" 段 (6 步: L3-1 扫描→L3-2 分级→L3-3 spec→L3-4 终止→L3-5 实测→L3-6 七维度)
- A4: 沉淀纪律 4 层分发归一 (gaf-lesson-router §3 单一权威源, 其他 skill 引用)
- A7: gaf-orchestrator refactor step_3 "四维度评分自决" → "七维度评分自决"

## Phase 2: 思维链归一 (A5-A6)
- A5: project_rules §3.6 自治边界 N## 列表归一 (8 项含 N111/N155 → 9 项 N109/N113/N115/N127/N151/N161/N163/N166/N167, 单一权威源 ai-operating-handbook.md)
- A6: 版本号策略统一 (project_rules §0 标题 v8.4→v9.1; gaf-orchestrator 头部删 version: 9.0; failure-modes.md 精简 v9.0/v9.1/v9.3 混合注释)

## Phase 3: 规则文档索引同步 (A8-A11)
- A8: N152 lesson 文件重命名 api-design_ → cross-layer-sync_ (与 failure-modes.md 索引 + N112 家族对齐)
- A9: failure-modes.md 124 行 → 105 行 (≤120 P5 硬约束 ✅)
- A10: lessons/README.md 补全 N165/N166/N167 (workflow 13→15, command-errors 2→3, 50 活跃)
- A11: ai-operating-handbook.md L3 表 version-compat.md → version-sync.md (实际文件名)

## Phase 4: 关键 [B] 类修复
- B1: documentation 分支 load_skills 加 gaf-lesson-router + task_type 映射表同步
- B2: gaf-orchestrator 闭环步骤第 6 步 "git gaf-commit" → "普通 git commit"
- B3: sub-file 计数 10 → 11 (3 处: project_rules §6.4 + gaf-reflect-and-evolve §6 + gaf-orchestrator §3.2)
- B4: failure-modes.md Dormant 表补全 8 条家族合并子条目 (N107/N110/N114/N113/N115/N127/N128/N130/N147/N153/N155/N162/N163)
- B5: gaf-task-execution step_5 加 "更新 completed-features.md + pending-roadmap.md 状态标记"

## 修改文件 (12 个)
1. .trae/skills/gaf-orchestrator/SKILL.md (L3 段 + 七维度 + version + B1 + B2 + B3)
2. .trae/skills/gaf-task-execution/SKILL.md (step_5 + after_commit)
3. .trae/skills/gaf-reflect-and-evolve/SKILL.md (§7 七维度 + §3 归一 + B3)
4. .trae/rules/project_rules.md (§3.6 归一 + §0 标题 + §6.4 计数)
5. .ai-memory/meta/failure-modes.md (版本精简 + Dormant 补全)
6. .ai-memory/meta/ai-operating-handbook.md (version-sync 修正)
7. .ai-memory/lessons/README.md (N165/N166/N167 补全)
8. .ai-memory/lessons/cross-layer-sync_2026-07-09-n152-drf-pagination-array-mismatch.md (重命名)
9. .ai-memory/agent-protocol.md (auto-maintained, sync 重生成)
10. .ai-memory/api-endpoints.md (auto-maintained, sync 重生成)
11. .ai-memory/error-codes.md (auto-maintained, sync 重生成)
12. .ai-memory/pipeline-nodes.md (auto-maintained, sync 重生成)
