---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-22-td323-skill-timestamps/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-td323, skill-frontmatter-drift, stale-updated-field]
solution: TD-323 problem — 5 SKILL.md frontmatter `updated` 字段滞后于 body 实际内容
related_files:
  - .ai-memory/evidence/2026-07-22-td323-skill-timestamps/solution.md
  - .ai-memory/evidence/2026-07-22-td323-skill-timestamps/verification.md
  - .trae/skills/gaf-orchestrator/SKILL.md
  - .trae/skills/gaf-lesson-router/SKILL.md
  - scripts/bootstrap/sync_skills.py
created_by: AI
last_updated: 2026-07-22
---
## Problem（症状 / 触发条件）

5 个 gaf-* SKILL.md 的 frontmatter `updated` 字段状态滞后:
- gaf-orchestrator: `updated: 2026-07-17` (滞后 4 天, body 含 v9.5 2026-07-21 内容)
- gaf-knowledge-base: `updated: 2026-07-16` (滞后 3 天)
- gaf-task-execution: `updated: 2026-07-17` (滞后 1 天)
- gaf-reflect-and-evolve: `updated: 2026-07-17` (滞后 3 天)
- gaf-lesson-router: **缺 updated 字段** (frontmatter 只有 name + description)

影响: AI/用户读 frontmatter 误判为旧版本, 但 body 实际已是最新; 违反 SSOT 原则.
触发条件: 任何修改 SKILL.md body 内容的 commit 都不会自动更新 frontmatter `updated` 字段.
