---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-22-td323-skill-timestamps/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-td323, skill-frontmatter-drift, sync-skills-update-timestamps]
solution: TD-323 solution — 扩展 sync_skills.py 加 --update-timestamps 命令 + 补 gaf-lesson-router frontmatter
related_files:
  - .ai-memory/evidence/2026-07-22-td323-skill-timestamps/problem.md
  - .ai-memory/evidence/2026-07-22-td323-skill-timestamps/verification.md
  - scripts/bootstrap/sync_skills.py
  - scripts/tests/test_sync_skills_timestamps.py
created_by: AI
last_updated: 2026-07-22
---
## Solution（解决步骤）

1. 扩展 `scripts/bootstrap/sync_skills.py`:
   - 新增 `TIMESTAMP_SKILLS = ALL_SKILLS + ["gaf-lesson-router"]` 常量 (5 个 SKILL.md)
   - 新增 `_FRONTMATTER_RE` / `_FRONTMATTER_UPDATED_RE` regex 常量
   - 新增 3 个辅助函数: `get_skill_last_commit_date(skill_md_path)` (调 `git log -1 --format=%cs`) / `parse_frontmatter_updated(text)` / `update_frontmatter_updated(text, new_date)`
   - 新增 `cmd_update_timestamps(args)` 函数 + `--update-timestamps` argparse flag
   - `--check` 模式扩展: 检测 `updated` 字段与 git log 不一致 → WARN (非阻塞)

2. 补 `.trae/skills/gaf-lesson-router/SKILL.md` frontmatter `version: 9.1` + `updated: 2026-07-18` 字段 (原 frontmatter 只有 name + description)

3. 跑同步: `python scripts/bootstrap/sync_skills.py --update-timestamps` 同步 4 个滞后 SKILL.md (gaf-orchestrator 2026-07-17→21, gaf-knowledge-base 2026-07-16→19, gaf-task-execution 2026-07-17→18, gaf-reflect-and-evolve 2026-07-17→20)

4. 新建 `scripts/tests/test_sync_skills_timestamps.py` (8 tests: parse_frontmatter_updated ×3 + update_frontmatter_updated ×3 + get_skill_last_commit_date ×2)

5. 迁移 TD-323 从 `docs/general/tech-debt/active.md` 到 `fixed.md`, 跑 `sync_tech_debt_counts.py` 同步计数 (active=14, fixed=292, wontfix=30)
