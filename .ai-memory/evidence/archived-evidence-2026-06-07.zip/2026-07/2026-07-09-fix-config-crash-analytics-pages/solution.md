---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-09/fix-config-crash-analytics-pages/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [frontend, backend, config-management, crash-reports, analytics, white-screen, 500, ModuleNotFoundError, import-error]
solution: Use importlib.util.spec_from_file_location to load agent modules under unique names; update CrashReports.tsx and AnalyticsDashboard.tsx imports to match current API exports.
related_files:
  - backend/settings/views.py
  - frontend/src/pages/Ops/CrashReports.tsx
  - frontend/src/pages/Ops/AnalyticsDashboard.tsx
  - frontend/src/api/logs.ts
  - frontend/src/api/ops.ts
created_by: AI
last_updated: 2026-07-09
---
## Solution（解决步骤）

1. **配置管理后端修复**：
   - 在 `backend/settings/views.py` 添加 `_load_agent_module(module_path, attr_name)` helper，使用 `importlib.util.spec_from_file_location` 从 `agent/src/<path>` 直接加载模块，并指定唯一模块名（如 `_agent_loaded_config_generator`），避免与 `backend/core` 的 `core` 包冲突。
   - 将 `config_generator_view` 和 `config_migration_view` 中的 `sys.path.insert(0, _agent_path) + from core.<module> import ...` 改为调用 `_load_agent_module(...)`。

2. **崩溃报告前端修复**：
   - 在 `frontend/src/pages/Ops/CrashReports.tsx` 中，把 `resolveCrashReport` 的导入从 `@/api/logs` 改为 `@/api/ops`。

3. **数据分析前端修复**：
   - 在 `frontend/src/pages/Ops/AnalyticsDashboard.tsx` 中，更新 import 和调用：
     - `fetchAnalyticsStepHeatmap` → `fetchStepHeatmap`
     - `fetchAnalyticsWeeklyReport` → `fetchWeeklyReport`
     - `fetchAnalyticsAgentPerformance` → `fetchAgentPerformance`

4. 本地验证：pytest settings tests、tsc --noEmit、Playwright 登录后访问三个页面。
