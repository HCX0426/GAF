---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-09/fix-config-crash-analytics-pages/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [frontend, backend, config-management, crash-reports, analytics, white-screen, 500, ModuleNotFoundError, import-error]
solution: Fix backend/core vs agent/src/core package name clash via importlib; correct stale frontend imports for crash reports and analytics APIs.
related_files:
  - backend/settings/views.py
  - frontend/src/pages/Ops/CrashReports.tsx
  - frontend/src/pages/Ops/AnalyticsDashboard.tsx
  - frontend/src/api/logs.ts
  - frontend/src/api/ops.ts
  - backend/config/urls.py
  - backend/executions/analytics_urls.py
created_by: AI
last_updated: 2026-07-09
---
## Problem（症状 / 触发条件）

用户报告三个界面异常：

1. **配置管理 `/system/config`**：加载配置模板失败，提示“服务器内部错误：未知服务器错误”。后端 `/api/v2/settings/config-generator/?action=schema&task_type=pipeline` 返回 500，错误 `ModuleNotFoundError: No module named 'core.config_generator'`。
2. **崩溃报告 `/ops/crash-reports`**：页面白屏，控制台 `SyntaxError: The requested module '/src/api/logs.ts' does not provide an export named 'resolveCrashReport'`。
3. **数据分析 `/ops/analytics`**：页面白屏，控制台 `SyntaxError: The requested module '/src/api/ops.ts' does not provide an export named 'fetchAnalyticsAgentPerformance'`。

**根因**:
- 配置管理：Django `backend/core` app 与 `agent/src/core` Python 包同名。`settings/views.py` 把 `agent/src` 插入 `sys.path` 后用 `from core.config_generator import ...` 导入，但 Python 优先解析已加载的 `backend/core`，导致 `ModuleNotFoundError`。
- 崩溃报告/数据分析：API 函数/导出位置发生变更（`resolveCrashReport` 移到 `@/api/ops`，analytics 函数重命名），但消费页面未同步更新 import。
