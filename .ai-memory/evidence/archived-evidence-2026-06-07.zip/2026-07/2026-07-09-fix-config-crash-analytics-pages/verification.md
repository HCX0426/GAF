---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-09/fix-config-crash-analytics-pages/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [frontend, backend, config-management, crash-reports, analytics, white-screen, 500, ModuleNotFoundError, import-error]
solution: All three pages verified via pytest + tsc + Playwright.
related_files:
  - backend/settings/views.py
  - frontend/src/pages/Ops/CrashReports.tsx
  - frontend/src/pages/Ops/AnalyticsDashboard.tsx
created_by: AI
last_updated: 2026-07-09
---
## Verification（验证）

```powershell
cd d:\code\GAF\backend
conda run -n gaf pytest settings/tests/ -v
```

实际输出：6 passed

```powershell
cd d:\code\GAF\frontend
npx tsc --noEmit
```

实际输出：无错误

```powershell
cd d:\code\GAF
conda run -n gaf python .trash/check_crash_analytics.py
conda run -n gaf python .trash/check_config_management.py
```

实际结果：
- `/ops/crash-reports` 可正常访问，URL 正确，控制台 0 错误
- `/ops/analytics` 可正常访问，URL 正确，控制台 0 错误
- `/system/config` 可正常访问，URL 正确，控制台 0 错误

后端 API 直接调用验证：
- `GET /api/v2/settings/config-generator/?action=schema&task_type=pipeline` → 200
- `GET /api/v2/settings/config-migration/` → 200
- `GET /api/v2/debug/crash-reports/` → 200
- `GET /api/v2/analytics/trend/`、`/step-heatmap/`、`/agent-performance/`、`/weekly-report/` → 200
