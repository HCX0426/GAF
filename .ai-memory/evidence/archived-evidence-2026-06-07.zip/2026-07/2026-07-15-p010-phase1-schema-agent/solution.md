# P-010 Phase 1 — Solution

## Approach (N151 architecture decision: Plan A)

Reuse existing `task.progress` schema (already reserved `step_index`/`status` fields) rather than introducing a new `STEP_FAILED` message type (Plan B — over-engineering, 17 enum changes) or switching to legacy consumer (Plan C — violates architecture-overview §14 dual-track design decision).

## Changes

### 1. `backend/protocol/schemas.py` — Extend `TASK_PROGRESS_SCHEMA`

Added 3 optional fields:
- `step_name` (string) — pipeline node ID or task step name
- `error_msg` (string) — failure reason (populated when status=failed, used for `ExecutionStep.error_message`)
- `elapsed_time` (number) — step duration in seconds (used for `ExecutionStep.duration`)

Existing `additionalProperties=False` retained — schema stays strict, only documented fields allowed.

### 2. `agent/src/core/orchestrator.py` — Wire `on_step_progress` callback

- `execute_pipeline` signature gained `on_step_progress: Optional[Callable[[str, AutoResult, int], None]]` parameter.
- Replaced empty lambda `_on_step_complete` with a real closure that:
  - Forwards `(node_id, result, step_index)` to `on_step_progress` (if provided)
  - Wraps the call in try/except so a callback exception never crashes the pipeline
  - Increments `step_counter[0]` (mutable closure counter) after each step
- `_on_error` closure similarly forwards `fail_result(error_msg=str(exc))` to `on_step_progress` before invoking the existing `_on_task_failed` callback.

### 3. `agent/src/client/handler.py` — Send `task.progress` frames with step fields

`handle_pipeline_execute` now defines an `on_step_progress(node_id, step_result, step_index)` closure that calls `self._send_to_server("task.progress", {...})` with:
- `execution_id`, `task_id` (from handler state)
- `step_index`, `step_name` (from callback args)
- `status` ("success" or "failed" based on `step_result.success`)
- `error_msg` (only when failed)
- `elapsed_time` (from `step_result.elapsed_time`)
- `message` (human-readable Chinese status)

The closure is passed to `self._orchestrator.execute_pipeline(... on_step_progress=on_step_progress)`.

### 4. `agent/conftest.py` — TD-116 workaround (unblock agent tests)

Root cause: `pyproject.toml` has `pythonpath = ["backend"]` + `DJANGO_SETTINGS_MODULE = "config.settings.dev"`. pytest-django runs `django.setup()` before `agent/conftest.py` loads, importing `core` as `backend.core` (Django app). Agent tests' `from core.X import Y` then resolve to `backend/core/` (missing agent's `delay`/`config`/`exceptions.DeviceError` submodules).

Workaround: `agent/conftest.py` now clears `core` and `core.*` from `sys.modules` before inserting `agent/src` to `sys.path`. Forces re-resolution to `agent/src/core/`.

Long-term fix (TD-116): rename one of the `core` packages.

## Tests added

`agent/tests/test_pipeline_step_progress.py` (7 tests):

`TestExecutePipelineStepProgressCallback` (5 tests):
- `test_on_step_complete_invokes_callback_with_success` — happy path
- `test_on_error_invokes_callback_with_failure` — error path
- `test_step_index_increments_across_nodes` — counter monotonicity
- `test_callback_exception_does_not_crash_pipeline` — robustness
- `test_no_callback_does_not_break` — backward compat

`TestHandlerStepProgressFrame` (2 tests):
- `test_handler_sends_step_progress_frame_on_success` — frame payload for successful node
- `test_handler_sends_step_progress_frame_on_failure` — frame payload for failed node (with error_msg)

## Tech debts registered

- **TD-116** (P2): `backend/core/` vs `agent/src/core/` package name collision. Workaround applied in `agent/conftest.py`. Long-term fix: rename one of the packages.
- **TD-117** (P3): 3 stale agent test files (`test_input_5button_wheel.py`, `test_llm_auto_heal.py`, `test_window_pos_mouse_hook.py`) referencing deleted classes/modules.
- **TD-115** (P3, pre-existing): `agent/src/core/orchestrator.py` has 40 pre-existing ruff errors (UP006/UP045/F401/F841/SIM105/I001). Not blocking Phase 1 (manual stage).
