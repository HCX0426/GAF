# P-010 Phase 1 — Problem

## Symptom

P-009 Phase 3 only wired **task-level** recovery (TaskExecution post_save signal → `recovery_engine.handle_task_failure`).
The step-level recovery path (`recovery_engine.handle_step_failure`) has zero callers in production code.

Root cause:
1. `agent/src/core/orchestrator.py` `execute_pipeline` had `on_step_complete` wired to an empty lambda — PipelineEngine's callback mechanism existed but was never connected to a real reporter.
2. `backend/protocol/schemas.py` `TASK_PROGRESS_SCHEMA` had `additionalProperties=False` and lacked `step_name`/`error_msg`/`elapsed_time` fields, so even if the agent sent step-level status, the schema would reject the extra fields.
3. `agent/src/client/handler.py` `handle_pipeline_execute` did not pass any `on_step_progress` callback to `execute_pipeline`.

## Impact

Step-level failures (a single pipeline node failing) are invisible to the backend — the backend only sees the final task.result (success/fail) after the whole pipeline finishes. `handle_step_failure` (already implemented in P-020-B ActionChain refactor) is dead code with zero production callers.

## Discovery context

- Found during P-010 spec N151 architecture review — `scheduler/recovery_engine.py:400` `handle_step_failure` has 0 callers in production code.
- Blocked Phase 1 verification initially: `pytest agent/tests/` returned 46 collection errors (TD-116 — `backend/core/` and `agent/src/core/` package name collision).
