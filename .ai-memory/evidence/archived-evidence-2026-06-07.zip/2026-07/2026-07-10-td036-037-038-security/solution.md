# TD-036 / TD-037 / TD-038 — Security Hardening Solution

## TD-036 — Remove dead `_derive_key_from_machine`

**File**: `agent/src/auth/token_store.py`

Removed the `_derive_key_from_machine` function entirely. The module
now relies solely on `Fernet.generate_key()` for key creation, which
is the cryptographically secure path that was already in use.

Added an explicit unit test `test_no_machine_name_derivation` that
greps the module source to ensure no `COMPUTERNAME`-based derivation
re-appears in the future.

## TD-037 — Localhost bypass opt-in via environment variable

**File**: `backend/protocol/middleware.py`

Added a module-level helper:

```python
def _is_localhost_bypass_enabled() -> bool:
    val = os.environ.get('GAF_ALLOW_LOCALHOST_BYPASS', '').strip().lower()
    return val in ('1', 'true', 'yes', 'on')
```

The middleware's `__call__` now branches:
- If `is_localhost and _is_localhost_bypass_enabled()` → look up the
  local Agent; if found, attach to scope and pass through; otherwise
  reject with `4003`.
- If `is_localhost and not _is_localhost_bypass_enabled()` → reject
  with `4003` and a `TD-037`-tagged warning log.

**Default**: bypass is **disabled**. Local development must set
`GAF_ALLOW_LOCALHOST_BYPASS=1` explicitly.

## TD-038 — ACL restriction + key rotation API

**File**: `agent/src/auth/token_store.py`

### ACL restriction

Added `_restrict_file_permissions(path)`:

- **Windows**: `icacls <path> /inheritance:r /grant:r <user>:F` —
  removes inherited ACEs and grants full control only to the current
  user (resolved from `USERNAME` / `USER` env var).
- **POSIX**: `os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)` — `0600`.

Called from `_get_or_create_key` immediately after writing a new key
file. Failures are logged as warnings (defensive: never crash the
Agent because ACL restriction failed).

### Key rotation API

Added `TokenStore.rotate_key()`:
1. Load all currently-stored (encrypted) Tokens.
2. Generate a new Fernet key and write it to `.key` (overwriting).
3. Re-apply ACL restrictions to the new `.key` file.
4. Replace `self._cipher` with the new Fernet instance.
5. Re-encrypt and persist all Tokens with the new key.

This allows operators to rotate the symmetric key without losing
stored Tokens.

### Refactor: injectable key directory

`_get_or_create_key` now accepts an optional `key_dir` parameter so
that `TokenStore` instances using a custom `storage_dir` (e.g. in
tests using `tmp_path`) write the `.key` file to the right location
instead of the module-level `DEFAULT_KEY_DIR`.

## Test coverage

### Agent tests — `agent/tests/test_token_store.py` (15 tests)

- `TestTokenStoreRoundTrip` (6): save/load/remove/overwrite/multiple
- `TestKeyRotation` (4): preserves tokens, changes key file, handles
  empty store, idempotent across multiple rotations
- `TestKeyManagement` (3): existing key returned, new key valid
  Fernet, no `COMPUTERNAME` derivation (regression guard for TD-036)
- `TestFilePermissions` (2): does not crash on happy path, logs
  warning on non-existent file

### Backend tests — `backend/protocol/tests/test_auth_middleware.py`

Added `TestLocalhostBypassFlag` class (7 tests):
- `test_bypass_disabled_by_default`
- `test_bypass_enabled_with_1`
- `test_bypass_enabled_with_true` (case-insensitive)
- `test_bypass_disabled_with_empty`
- `test_bypass_disabled_with_0`
- `test_localhost_rejected_when_bypass_disabled` (integration)
- `test_localhost_accepted_when_bypass_enabled_with_local_agent`
  (integration)

Integration tests use `AsyncMock()` for the inner app because
`BaseMiddleware.__call__` awaits `self.inner(scope, receive, send)`.
