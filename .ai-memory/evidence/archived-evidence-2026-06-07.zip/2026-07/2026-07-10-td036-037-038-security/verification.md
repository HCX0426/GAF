# TD-036 / TD-037 / TD-038 — Verification

## Test runs

### Agent — `agent/tests/test_token_store.py`

```
============================= test session starts =============================
platform win32 -- Python 3.11.15, pytest-8.4.2, pluggy-1.6.0
plugins: anyio-4.14.0, Faker-40.23.0, asyncio-0.26.0

tests\test_token_store.py::TestTokenStoreRoundTrip::test_save_and_load_token PASSED [  6%]
tests\test_token_store.py::TestTokenStoreRoundTrip::test_load_nonexistent_token PASSED [ 13%]
tests\test_token_store.py::TestTokenStoreRoundTrip::test_remove_token PASSED [ 20%]
tests\test_token_store.py::TestTokenStoreRoundTrip::test_remove_nonexistent_token_no_error PASSED [ 26%]
tests\test_token_store.py::TestTokenStoreRoundTrip::test_save_multiple_tokens PASSED [ 33%]
tests\test_token_store.py::TestTokenStoreRoundTrip::test_overwrite_existing_token PASSED [ 40%]
tests\test_token_store.py::TestKeyRotation::test_rotate_key_preserves_tokens PASSED [ 46%]
tests\test_token_store.py::TestKeyRotation::test_rotate_key_changes_key_file PASSED [ 53%]
tests\test_token_store.py::TestKeyRotation::test_rotate_key_with_no_tokens PASSED [ 60%]
tests\test_token_store.py::TestKeyRotation::test_rotate_key_multiple_times PASSED [ 66%]
tests\test_token_store.py::TestKeyManagement::test_get_or_create_key_returns_existing PASSED [ 73%]
tests\test_token_store.py::TestKeyManagement::test_get_or_create_key_generates_valid_fernet_key PASSED [ 80%]
tests\test_token_store.py::TestKeyManagement::test_no_machine_name_derivation PASSED [ 86%]
tests\test_token_store.py::TestFilePermissions::test_restrict_permissions_does_not_crash PASSED [ 93%]
tests\test_token_store.py::TestFilePermissions::test_restrict_permissions_on_nonexistent_file_logs_warning PASSED [100%]

======================== 15 passed, 1 warning in 1.02s ========================
```

Command: `cd agent; conda run -n gaf python -m pytest tests/test_token_store.py -v -p no:django`

### Backend — `backend/protocol/tests/test_auth_middleware.py`

```
test_bypass_disabled_by_default ... ok
test_bypass_disabled_with_0 ... ok
test_bypass_disabled_with_empty ... ok
test_bypass_enabled_with_1 ... ok
test_bypass_enabled_with_true ... ok
test_localhost_accepted_when_bypass_enabled_with_local_agent ... ok
test_localhost_rejected_when_bypass_disabled ... ok
test_extract_token_from_authorization_header ... ok
test_extract_token_from_query_string ... ok
test_extract_token_from_query_string_multiple_params ... ok
test_extract_token_from_x_agent_token_header ... ok
test_extract_token_no_token ... ok
test_get_agent_by_token_empty ... ok
test_get_agent_by_token_invalid ... ok
test_get_agent_by_token_valid ... ok

Ran 15 tests in 0.023s
OK
```

Command: `cd backend; conda run -n gaf python manage.py test protocol.tests.test_auth_middleware -v 2`

## N128 three-step verification

1. **Glob** — confirmed files exist:
   - `agent/src/auth/token_store.py`
   - `agent/tests/test_token_store.py`
   - `backend/protocol/middleware.py`
   - `backend/protocol/tests/test_auth_middleware.py`

2. **Grep** — confirmed key implementation details:
   - `_is_localhost_bypass_enabled` defined in `middleware.py`
   - `GAF_ALLOW_LOCALHOST_BYPASS` referenced in middleware + tests
   - `_restrict_file_permissions` defined in `token_store.py`
   - `rotate_key` method present in `TokenStore` class
   - `_derive_key_from_machine` **NOT** present (removed)

3. **pytest** — 15/15 agent + 15/15 backend tests pass (see above).

## Regression guard

`test_no_machine_name_derivation` reads the `token_store.py` source
and asserts that `COMPUTERNAME` does not appear, preventing TD-036
regression.
