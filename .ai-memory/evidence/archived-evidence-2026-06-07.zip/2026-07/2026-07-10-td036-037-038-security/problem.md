# TD-036 / TD-037 / TD-038 — Security Hardening Problem Statement

## TD-036 — Misleading dead code in token_store.py

`agent/src/auth/token_store.py` contained a function
`_derive_key_from_machine` that computed `seed` / `key_material` from
the Windows `COMPUTERNAME` environment variable. **The computed values
were never used** — the actual encryption key was always
`Fernet.generate_key()` (cryptographically secure random key).

**Why this is a problem**:
- The dead code gave a false impression of weak, machine-name-derived
  entropy, misleading future maintainers and security reviewers.
- Static analysis tools and auditors would flag the function as a
  weak-key derivation path even though it was never invoked.
- It implied a security property (machine-bound key) that the system
  did not actually provide.

## TD-037 — Localhost bypass was always-on

`backend/protocol/middleware.py` allowed any WebSocket connection from
`127.0.0.1` / `::1` / `localhost` to bypass Token authentication,
provided an `Agent` with `is_local=True` existed in the database.

**Why this is a problem**:
- If an Agent ever becomes a relay proxy (or is compromised into
  forwarding traffic), any local process on the backend host could
  connect to the WebSocket without a Token.
- Default-on bypass violates the principle of least privilege.
- The bypass is convenient for local development but should be
  opt-in, not opt-out.

## TD-038 — No ACL on the Fernet `.key` file

The `.key` file written by `token_store.py` had default filesystem
permissions, meaning any user on the host could read the symmetric
encryption key used to protect stored Agent Tokens at rest.

**Why this is a problem**:
- Any local user with read access to the Agent's storage directory
  could exfiltrate the Fernet key and decrypt every stored Token.
- There was no API to rotate the key without losing all stored Tokens.
- Windows defaults are particularly permissive (inherited from parent
  directory, often readable by `Users` group).

## Combined impact

Together these three issues formed a layered security weakness:
1. The key file was world-readable (TD-038).
2. The localhost bypass allowed unauthenticated access to the backend
   WebSocket from the same host (TD-037).
3. The dead code masked the true key-derivation story, preventing
   accurate risk assessment (TD-036).
