# TD-015 Phase 4 — Problem

TD-015 introduced a device control-mode abstraction (`foreground` / `background` / `pseudo_background`) and a pseudo-background input implementation for Windows. After completing Phases 1–3 (backend model/serializer/API, agent input handler, frontend UI), Phase 4 was missing:

1. Agent unit tests for `_click_pseudo_background` / `_key_press_pseudo_background` save/restore behavior.
2. Frontend end-to-end coverage proving the `/devices/windows` control-mode selector renders and toggles without console errors.
3. Tech-debt register update marking TD-015 as fixed.
4. Three-step evidence documenting the implementation.

Without these, the feature could regress silently (e.g. restore logic broken, frontend import errors, or dropdown rendering issues).
