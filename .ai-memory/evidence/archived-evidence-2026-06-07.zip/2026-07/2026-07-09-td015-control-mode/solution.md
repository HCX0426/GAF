# TD-015 Phase 4 — Solution

1. **Agent unit tests**
   - Added `agent/tests/test_windows_input_pseudo_background.py` with 11 pytest cases.
   - Mocked `user32` / `ctypes` to verify:
     - Method setter accepts/rejects values correctly.
     - `_click_pseudo_background` and `_key_press_pseudo_background` save the previous foreground window and cursor position, foreground the target, call the inner SendInput path, and restore foreground/cursor.
     - Restore happens even when the inner operation raises an exception.
     - `click()` / `key_press()` dispatch the `method="PseudoBackground"` override correctly.

2. **Frontend Playwright smoke test**
   - Added `scripts/e2e/scenarios/devices_control_mode.py`.
   - Logs in via `/login`, navigates to `/devices/windows`, waits for the control-mode selector (or empty state), toggles the mode between "前台" and "伪后台", and asserts zero console/page JS errors.
   - Registered the scenario in `scripts/e2e/run_all.py`, `scripts/e2e/scenarios/__init__.py`, and `scripts/e2e/conftest.py`.
   - Added `data-testid="control-mode-select"` to the Select in `WindowManagementPage.tsx` for stable test targeting.

3. **Tech-debt register**
   - Updated `docs/general/tech-debt-register.md` TD-015 entry from `🔧 待修` to `✅ FIXED` with the Phase 4 commit hash and evidence reference.
