# TD-015 Phase 4 — Verification

## Agent tests

```powershell
conda run -n gaf python -m pytest agent/tests/test_windows_input_pseudo_background.py -v -p no:django
```

Result: **11 passed** in ~0.25s.

## Playwright smoke test

```powershell
conda run -n gaf python scripts/e2e/run_all.py devices_control_mode --strict
```

Result:

```text
[e2e] running 1 scenario(s) against D:\code\GAF
  - devices_control_mode OK    devices/windows OK → control mode selector rendered and toggled (no JS errors)
[e2e] 1/1 passed in 6.776s
```

## Type check

```powershell
cd frontend
npx tsc --noEmit -p tsconfig.json
```

Result: **0 errors**.

## Backend tests (regression)

```powershell
cd backend
conda run -n gaf python -m pytest agents/tests/test_device_api.py -v
```

Result: existing backend tests for `control_mode` round-trip and defaults pass.
