# spec34 Phase 3 — Problem

## 背景
Phase 2 接入了 3 个最敏感 app (accounts/settings/tasks), Phase 3 接入剩余 11 个 app。

## Phase 3 范围
11 个 app, ~25 ViewSet, 3 subagent 并行:
- Subagent D: agents (19 View)
- Subagent E: pipeline + resources + plugins (19 View)
- Subagent F: scheduler + notifications + monitors + protocol + qa + debug + gamestate + executions (32 View)

## 验收门槛
- 11 app 全量 pytest 全过 (无 regression)
- 敏感字段 (token/secret/url/question/code) 自动 redact
- @action 写操作接入 @audit_action
- 只读 ViewSet 跳过
