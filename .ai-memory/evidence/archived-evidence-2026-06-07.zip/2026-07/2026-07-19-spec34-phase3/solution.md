# spec34 Phase 3 — Solution

## 执行方式
3 subagent 并行 (N172 模式):
- Subagent D: agents (1 文件, 19 View, 接入 7 跳过 12)
- Subagent E: pipeline + resources + plugins (3 文件, 19 View, 接入 13 跳过 6)
- Subagent F: scheduler + notifications + monitors + protocol + qa + debug + gamestate + executions (8 文件, 32 View, 接入 14 跳过 18)

## 接入汇总 (11 app)

### agents (Subagent D) — `backend/agents/views.py`

**A. AuditMixin (3 ViewSet)**:
- AgentViewSet (AGENT) + _build_audit_details (redact agent_token_hash/agent_token_preview)
- DeviceViewSet (DEVICE) + _build_audit_details (redact agent_token/secret/fcm_token)
- DeviceGroupViewSet (DEVICE_GROUP) + 重写 perform_create (注入 user)

**B. 显式 log_audit (4 APIView)**:
- DeviceRegisterView (CREATE/UPDATE 动态判别, DEVICE)
- DeviceLockView (UPDATE, DEVICE, {lock_action: "locked"})
- DeviceUnlockView (UPDATE, DEVICE, {lock_action: "unlocked"})
- EmulatorLifecycleView (EXECUTE, DEVICE, {action: "start"/"stop"/"restart"})

**C. @audit_action (3 个)**:
- AgentViewSet.generate_token (UPDATE, AGENT)
- DeviceViewSet.bind_game_account (UPDATE, DEVICE)
- DeviceViewSet.bind_game_profile (UPDATE, DEVICE)

**跳过 (12 个)**: DeviceScanView / DeviceScreenshotView / DeviceTestScreenshotView /
DeviceStatsView / DeviceCompatibilityCheckView / PlatformCapabilitiesView /
DeviceClickView / DeviceInputView / DeviceTemplateMatchView / DeviceColorDetectView /
DeviceAppView / DeviceInfoView (全 GET 或不持久化)

### pipeline (Subagent E) — `backend/pipeline/views.py`

**A. AuditMixin (3 ModelViewSet)**:
- PipelineViewSet (PIPELINE) + _build_audit_details (snapshot: name/version/is_template/user_id)
- TaskChainViewSet (TASK_CHAIN) + _build_audit_details (snapshot: name/is_default/game_profile_id)
- RecordingViewSet (RECORDING) + _build_audit_details (snapshot: name/user_id)

**B. 显式 log_audit (1 APIView)**:
- TaskChainNodeView (CREATE/UPDATE/DELETE, TASK_CHAIN)

**C. @audit_action (6 个)**:
- PipelineViewSet.restore (UPDATE) / execute (EXECUTE)
- TaskChainViewSet.execute (EXECUTE) / set_default (UPDATE) / import_routine (IMPORT, detail=False)
- RecordingViewSet.convert_to_pipeline (IMPORT)

**跳过 (4 个)**: PipelineValidateView / PipelineEstimateTimeView (POST 但只校验/估算) /
TaskChainExecutionViewSet / TemplateEffectivenessViewSet (只读)

### resources (Subagent E) — `backend/resources/views.py`

**A. AuditMixin (4 ModelViewSet)**:
- ResourcePackViewSet (RESOURCE_PACK) + _build_audit_details (snapshot: name/version/is_active/target_app)
- TemplateVersionViewSet (TEMPLATE_VERSION) + _build_audit_details (snapshot: version_number/comment)
- TagViewSet (TAG) + _build_audit_details
- TemplateAnnotationViewSet (TEMPLATE_ANNOTATION) + _build_audit_details

**B. 显式 log_audit (2 处)**:
- ResourcePackViewSet.rois (PUT 分支) / roi_task (PUT/POST 分支) — 混合 GET/写 不能用 @audit_action

**C. @audit_action (5 个)**:
- ResourcePackViewSet.activate (UPDATE) / deactivate (UPDATE) / scan_packs (IMPORT, detail=False) / roi_delete (DELETE)
- TemplateAnnotationViewSet.batch_delete (DELETE, detail=False)
- TemplateVersionViewSet.restore (UPDATE)
- ResourcePackViewSet.create_pack (手动 _log_audit 捕获新 pack ID)

**跳过**: TemplateEffectivenessViewSet (只读) + 多个 GET @action + 函数式视图

### plugins (Subagent E) — `backend/plugins/views.py`

**B. 显式 log_audit (6 APIView, 全 PLUGIN)**:
- PluginUploadView (CREATE/UPDATE 动态判别, details: op/name/version/checksum)
- PluginInstallView (CREATE)
- PluginToggleView (UPDATE, before_is_active + after_is_active)
- PluginUninstallView (DELETE, 删除前 snapshot)
- PluginReloadView (UPDATE)
- PluginSandboxExecView (EXECUTE, **不明文** stdout/stderr — 插件可能打印 secrets)

**跳过**: PluginListView (GET)

### scheduler (Subagent F) — `backend/scheduler/views.py`

**A. AuditMixin (1)**: TimeWindowViewSet (TIME_WINDOW) + _build_audit_details (时间字段 isoformat 转换)

**跳过**: RecoveryLogViewSet (只读) + 多个函数式视图

### notifications (Subagent F) — `backend/notifications/views.py`

**A. AuditMixin (3)**:
- NotificationViewSet (NOTIFICATION)
- WebhookConfigViewSet (WEBHOOK_CONFIG) + sensitive_extra {url, secret, token, headers}
- AlertRuleViewSet (ALERT_RULE) + snapshot (name/rule_type/enabled/threshold)

**C. @audit_action (3 个)**:
- NotificationViewSet.mark_read (UPDATE) / mark_all_read (UPDATE, detail=False)
- WebhookConfigViewSet.test_webhook (EXECUTE)

### monitors (Subagent F) — `backend/monitors/views.py`

**A. AuditMixin (1)**: MonitorRuleViewSet (MONITOR_RULE) + sensitive_extra {rule_definition, config}

**C. @audit_action (1)**: MonitorRuleViewSet.push_to_agent (EXECUTE, detail=False)

**跳过**: MonitorEventViewSet (只读)

### protocol (Subagent F) — `backend/protocol/views.py`

**A. AuditMixin (1)**: AgentSessionViewSet (AGENT_SESSION) + audit_resource_id_attr="agent_id" (UUID) + sensitive_extra {capabilities, token_hash, resource_quota}

**C. @audit_action (2)**:
- AgentSessionViewSet.generate_token (EXECUTE) — token 明文不进 details, 仅 token_preview
- AgentSessionViewSet.heartbeat (UPDATE)

**跳过**: MessageFrameLogViewSet (只读)

### qa (Subagent F) — `backend/qa/views.py`

**A. AuditMixin (2)**:
- QASessionViewSet (QA_SESSION) + sensitive_extra {question, answer, context_snapshot}
- QAMessageViewSet (QA_MESSAGE) + snapshot (role + content_length, **不明文** content)

**B. 显式 log_audit (1 APIView)**:
- AskView (EXECUTE, QA_SESSION, details: question_length + session_id + model_name, **不明文** question)

**C. @audit_action (1)**: QASessionViewSet.mark_knowledge (UPDATE)

**跳过**: LLMUsageLogViewSet (只读)

### debug (Subagent F) — `backend/debug/views.py`

**A. AuditMixin (2)**:
- CrashReportViewSet (CRASH_REPORT) + sensitive_extra {stack_trace, system_info}
- DebugLogArchiveViewSet (DEBUG_LOG_ARCHIVE) + sensitive_extra {zip_file_path, file_path}

**C. @audit_action (1)**: DebugLogArchiveViewSet.analyze (EXECUTE)

**跳过**: LLMAnalysisResultViewSet (只读)

### gamestate (Subagent F) — `backend/gamestate/views.py`

**A. AuditMixin (2)**:
- GameProfileViewSet (GAME_PROFILE) + sensitive_extra {known_popups, screenshot_methods, routine_path}
- GameStateRuleViewSet (GAME_STATE_RULE) + sensitive_extra {ocr_region, ocr_regex, trigger_action}

**C. @audit_action (8 个)**:
- GameProfileViewSet.bind_task / unbind_task / bind_task_chain / unbind_task_chain / bind_account / unbind_account (UPDATE)
- GameProfileViewSet.default_routine (UPDATE)
- GameProfileViewSet.dispatch_routine (EXECUTE)

**跳过**: GameStateSnapshotViewSet (只读)

### executions (Subagent F) — `backend/executions/views.py`

**B. 显式 log_audit (1)**:
- execution_intervene_view (EXECUTE, TASK_EXECUTION, details: execution_id/action/action_label/reason_length/operator, **不明文** reason)

**跳过 (9 个 GET)**: execution_steps_view / daily_report_view / unattended_logs_view /
trend_view / step_heatmap_view / agent_performance_view / weekly_report_view /
task_stats_view / execution_analysis_view

## 接入统计 (11 app 总计)

| App | AuditMixin | 显式 log_audit | @audit_action | 跳过 |
|-----|-----------|---------------|--------------|------|
| agents | 3 | 4 | 3 | 12 |
| pipeline | 3 | 1 | 6 | 4 |
| resources | 4 | 2 | 5+1手动 | 多个 GET |
| plugins | 0 | 6 | 0 | 1 |
| scheduler | 1 | 0 | 0 | 多个 |
| notifications | 3 | 0 | 3 | 0 |
| monitors | 1 | 0 | 1 | 1 |
| protocol | 1 | 0 | 2 | 1 |
| qa | 2 | 1 | 1 | 1 |
| debug | 2 | 0 | 1 | 1 |
| gamestate | 2 | 0 | 8 | 1 |
| executions | 0 | 1 | 0 | 9 |
| **总计** | **22** | **15** | **31** | **~32** |

## 关键设计决策

### 1. perform_create/perform_update kwargs 注入冲突
PipelineViewSet/TaskChainViewSet/RecordingViewSet/ResourcePackViewSet/TemplateVersionViewSet/
DeviceGroupViewSet/TimeWindowViewSet 等都需注入 user/version/created_by 等 kwargs。
解决方法: 子类重写 perform_create, 内部 serializer.save(kwargs) + 手动 _log_audit。

### 2. 混合 GET/写 @action 不能用 @audit_action
ResourcePackViewSet.rois (GET/PUT) / roi_task (GET/PUT/POST) — @audit_action 会包装整个方法,
导致 GET 也写审计。解决: 在写分支内手动调 log_audit。

### 3. detail=False @action 无法捕获新资源 ID
ResourcePackViewSet.create_pack (detail=False) URL 无 pk, 但新建 pack.id 在 response 中。
解决: 在方法体内 ResourcePack.objects.create() 后手动 _log_audit 捕获真实 ID。

### 4. datetime.time JSON 序列化失败
TimeWindow.start_time/end_time 是 datetime.time, AuditLog.details JSONField 序列化失败。
解决: 在 _build_audit_details 的 _snapshot helper 内对所有有 .isoformat() 方法的对象
调用该方法转 ISO 字符串 (ViewSet 层修复, 不改 gaf_core)。

### 5. 敏感字段防御
- WebhookConfig.url 整体 redact (URL 可能含 token)
- AgentSession token 明文不进 details, 仅 token_preview (不可逆)
- QASession.question / QAMessage.content 不明文 (用户明文 + AI 生成可能含代码片段)
- PluginSandboxExecView 不记录 stdout/stderr (插件可能打印 secrets)
- execution_intervene_view reason 仅记录长度 (可能含敏感上下文)
- DebugLogArchive.zip_file_path / GameProfile.routine_path redact (绝对路径暴露主机名)

### 6. lazy import 防循环
所有 `from accounts.audit import log_audit` 在函数体内 import。
