---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, problem-step, evidence-problem]
solution: Problem 模板 — 描述症状/触发条件/影响范围;gaf-3step-evidence hook 校验占位符必须替换
related_files:
  - .ai-memory/evidence/templates/solution.md
  - .ai-memory/evidence/templates/verification.md
  - scripts/check_3step_evidence.py
created_by: AI
last_updated: 2026-07-20
---
## Problem（症状 / 触发条件）

### 现象
spec-44 完成 G 类 8 项月度检查瘦身后, 月度检查仍有 76 项手动跑, 其中 C1/H1/I1/N1 4 项可完全脚本化但未自动化:
- C1 (活跃 TD 数量): 手动读 active.md 统计 🔧/🚧 条目数, 阈值判断 >5/>10
- H1 (Git 工作树状态): 手动 `git status` + 检查 *.env/*.key/*.pem
- I1 (巨型文件检测): 手动 `rg --files | xargs wc -l` 抽查
- N1 (空目录扫描): 手动 `Get-ChildItem -Recurse` 或 `scripts/scan_empty.py`

### 触发条件
月度检查执行时, AI/开发者需手动跑这 4 项, 耗时 ~13 min/月, 且容易遗漏或判断不一致 (人工阈值判断)。

### 影响范围
- 月度耗时: 76 项手动跑, ~80-95 min/月
- 4 项可自动化部分: 13 min/月, 占月度总耗时 15%
- 人工判断不一致: 例如 I1 阈值 (500? 1000? 2000?) 在不同月度检查时可能不一致

### 关键文件路径
- `docs/general/monthly-health-check.md` (月度检查权威定义)
- `scripts/governance/doc_health_check.py` (spec-41 7 维度静态检查, 已覆盖 G 类)
- `scripts/governance/thresholds.yaml` (阈值集中配置)
- `scripts/governance/report_schema.py` (Issue / ReportSummary schema)

### 运行命令证据
- `pytest scripts/tests/test_monthly_health_check.py` (spec-45 新测试, 18 cases)
- `python scripts/governance/monthly_health_check.py` (spec-45 主脚本)
- `python scripts/governance/doc_health_check.py --no-fail` (spec-41 不退化验证)
