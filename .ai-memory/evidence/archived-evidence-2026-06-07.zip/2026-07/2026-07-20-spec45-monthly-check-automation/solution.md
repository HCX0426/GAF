---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, solution-step, evidence-solution]
solution: Solution 模板 — 描述修复方案/实施步骤/关键决策;gaf-3step-evidence hook 校验占位符必须替换
related_files:
  - .ai-memory/evidence/templates/problem.md
  - .ai-memory/evidence/templates/verification.md
  - scripts/check_3step_evidence.py
created_by: AI
last_updated: 2026-07-20
---
## Solution（修复方案 / 实施步骤）

### 方案决策 (N167 七维度评分)

3 个候选方案评分:

| 方案 | ① 架构 | ② 归一化 | ⑦ 维护 | 总分 | 自决? |
|------|------|--------|------|------|------|
| A: 新脚本 monthly_health_check.py + 复用 Issue schema | 5 | 5 | 5 | 15 | ✅ 自决 |
| B: 塞进 spec-41 7 维度 (变 11 维度) | 2 | 2 | 3 | 7 | ❌ |
| C: 不实现自动化 (维持手动) | 1 | 1 | 1 | 3 | ❌ |

**自决决策**: 方案 A (15/15, 领先 B 8 分)
- ① 架构长远性 5/5: 与 doc_health_check.py 平级, 职责边界清晰, 不污染 spec-41
- ② 全局归一化 5/5: 复用 Issue/ReportSummary schema, 报告格式一致
- ⑦ 长期维护成本 5/5: thresholds.yaml 集中配置 + 18 单元测试 + 标准化注释

### Phase 1: monthly_health_check.py + 4 项检查 + 单元测试

#### 1.1 新脚本 `scripts/governance/monthly_health_check.py` (351 行)

4 项检查实现:

```python
# C1: active TD count (active.md)
def check_c1_active_td(repo_root, thresholds):
    # 统计 active.md 中 🔧/🚧 表行数
    # >5 P2 warning, >10 P1 critical

# H1: git status hygiene
def check_h1_git_status(repo_root, thresholds):
    # subprocess git status --porcelain
    # 敏感文件 (.env/*.key/*.pem/*credentials*/*.pfx) → P0
    # >20 uncommitted → P2

# I1: large files (> threshold lines)
def check_i1_large_files(repo_root, thresholds):
    # scan backend/frontend/src/agent/src/scripts
    # per_dir 阈值: backend=2000, frontend/src=1500, agent/src=1500, scripts=1000
    # 跳过 .generated./__pycache__/node_modules/.venv/debug
    # 用 str.count("\n") 替代 sum(1 for _ in fh) — 5-10x 加速

# N1: empty dirs/files (N2 合并)
def check_n1_empty_dirs(repo_root, thresholds):
    # 空目录 + 空文件
    # 跳过 .git/.cache/node_modules/__pycache__/.venv/.trash/MagicMock/debug
    # 跳过 .gitkeep/.keep/__init__.py/*.lock
```

#### 1.2 测试 `scripts/tests/test_monthly_health_check.py` (18 cases)

- C1: 4 tests (no_active_md / below_threshold / warning_threshold / critical_threshold)
- H1: 3 tests (clean_repo / sensitive_file / many_uncommitted) — 用 real `git init` subprocess
- I1: 3 tests (no_large / large_python / large_frontend — per_dir threshold)
- N1: 6 tests (no_empty / empty_dir / empty_file / skips_lock / skips_gitkeep / skips_init_py)
- 编排: 2 tests (passes_subconfig / crash_isolation)

#### 1.3 thresholds.yaml 扩展 (+21 行 monthly_checks 段)

集中管理 4 项检查的阈值, 与 spec-41 7 维度配置平级。

#### 1.4 性能优化 (4.85s → 1.88s, -61%)

主要优化:
1. `text.count("\n")` 替代 `sum(1 for _ in fh)` — C-level 字符扫描, 5-10x 加速
2. 跳过 `.generated.` 文件 (api.generated.ts 26109 行自动生成, 不算巨型)
3. 跳过 MagicMock/ 副作用目录 (测试 mock 产物, 不是真实代码)
4. 跳过 agent/debug/ 目录 (运行时 debug 输出, 不是源码)
5. 跳过 .trash/ 目录 (已垃圾回收暂存区)
6. 跳过 *.lock 文件 (intentional empty lock files)

### Phase 2: monthly-health-check.md 4 项标记 + 全量回归

#### 2.1 文档改动 (单文件)

- frontmatter summary: 改 "G 类已迁自动 spec-41, 月度跑 76 项" → "G 类已迁自动 spec-41, C1/H1/I1/N1 已迁自动 spec-45, 月度跑 72 项"
- 顶部追加 spec-45 迁移说明段 (4 项迁移映射)
- 执行流程步骤 2: 追加 "C1/H1/I1/N1 跑 monthly_health_check.py 后跳过"
- 检查项总览表 C/H/I/N 行: 各加 ✅ 标记 + (月度跑 N-1)
- 合计行: 84 (月度跑 76) → 84 (月度跑 72)
- C1/H1/I1/N1 标题: 各加 ✅ 已迁自动 (spec-45) + 迁移映射 blockquote

#### 2.2 全量回归

- 313 passed / 10 failed in 47.10s
- 10 失败全为预存 (与 spec-45 无关): 5 e2e + 1 bootstrap_gaf + 4 extract_lessons + 1 layer_benchmark
- spec-41 不退化: doc_health_check.py 0.67s (与 spec-43 时 0.722s 一致)

### 关键决策

1. **新脚本 vs 塞进 spec-41**: 选新脚本 (职责边界清晰, spec-41 = doc/AI 记忆层, spec-45 = 项目卫生层)
2. **不集成到 gaf_init.sh**: 月度检查 ≠ 每次对话跑, 避免污染 session 启动
3. **复用 Issue schema**: 保持报告格式一致, AI 可用同一解析器读两种报告
4. **N2 合并到 N1**: 空目录和空文件本质同类问题 (post-refactor leftover), 用一次扫描覆盖
5. **str.count 替代 sum**: 性能优化关键, C-level 字符扫描比 Python 逐行迭代快 5-10x
6. **跳过 .generated./MagicMock/debug/.trash/.lock**: 减少误报 (这些都是 intentional 或自动产物)
