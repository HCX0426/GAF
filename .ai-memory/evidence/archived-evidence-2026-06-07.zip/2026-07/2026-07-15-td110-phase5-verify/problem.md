---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-15-td110-phase5-verify/problem.md
load_when: [evidence, 3-step-evidence, td110, phase5]
priority: high
symptom: [td110-phase5-verify, full-regression, ruff-migrations-exclude]
solution: Phase 5 verify — 全量回归 + ruff + tsc + 文档同步收尾 TD-110
related_files:
  - docs/general/specs/2026-07-14-td110-routine-taskchain-converter.md
  - docs/general/tech-debt/active.md
  - docs/general/completed-features.md
  - docs/general/design/architecture-overview.md
  - pyproject.toml
  - backend/pipeline/tests/test_chain_executor.py
created_by: AI
last_updated: 2026-07-15
---
## Problem（症状 / 触发条件）

TD-110 Phase 1-4 已完成 (commits `d3605beb`/`623e2ef7`/`7a300156`/`58ad279d`)，但 Phase 5 收尾验证尚未执行：

1. **现象**: `ruff check backend/pipeline/` 报 6 errors — 5 个在 `test_chain_executor.py` (Phase 2 重命名 `first_task_name` → `first_ref_name` 时漏改的 unused imports + 未排序的 import 块)，1 个在 `pipeline/migrations/0001_initial.py` (Django auto-generated, I001 false positive)
2. **触发条件**: 跑 `conda run -n gaf ruff check backend/pipeline/` 即可复现
3. **影响范围**: Phase 5 验收标准要求 ruff 0 errors；同时全量回归 (`pytest backend/`) + 前端类型检查 (`npx tsc --noEmit`) + 文档同步 (active.md / completed-features.md / architecture-overview.md / spec 状态表) 均未执行，TD-110 无法标记 ✅ FIXED
