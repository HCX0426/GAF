---
evidence_for: spec-47
task_type: bug_fix
related_files:
  - .ai-memory/lessons/ai-autonomy_2026-06-16-n109-decision-relaxation.md
  - .ai-memory/lessons/ai-autonomy_2026-06-16-n111-command-timeout.md
  - .ai-memory/summaries/architecture-mistakes.md
  - scripts/governance/doc_health_check.py
  - scripts/governance/check_dimensions/d4_path_drift.py
created_at: 2026-07-20
---

# Spec-47 Problem: TD-279 path drift 173 P0 阻塞飞轮读侧

## 1. 症状

`doc_health_check.py` 报 d4_path_drift P0 = 173 (spec-46 后残留),全为 `.ai-memory/lessons/` + `.ai-memory/summaries/` + `.ai-memory/platforms/` 的 frontmatter `related_files` 或 body path 引用了已删除/迁移/重命名的文件。

## 2. P0 分布

| 目录 | P0 数 | 占比 |
|------|------|------|
| `.ai-memory/lessons/` | 94 | 54% |
| `.ai-memory/summaries/` (含 architecture-mistakes.md 58) | 60 | 35% |
| `.ai-memory/platforms/` | 11 | 6% |
| 其他 (knowledge/meta/games/.trae) | 8 | 5% |

## 3. P0 模式归类 (7 大模式)

| 模式 | P0 数 | 修复策略 |
|------|------|---------|
| 1. `GAF/` 前缀残留 | 37 | strip 前缀 |
| 2. skill 相对路径 (`gaf-*/SKILL.md`) | 20 | 加 `.trae/skills/` 前缀 |
| 3. lessons/ 相对路径 | 13 | 加 `.ai-memory/` 前缀 |
| 4. `.trash/` 临时文件引用 | 12 | 改描述性文字 |
| 5. `docs/general/ai-lessons/` | 7 | 替换为 `.ai-memory/summaries/` |
| 6. 历史路径漂移 (~30 类) | ~70 | 逐类映射 |
| 7. 已删除文件引用 | ~14 | 改描述性文字 |

## 4. 根因

- **代码重构/迁移**: `backend/agent/handlers/verify.py` → `backend/device_bridge/handlers/verify.py` 等
- **lessons 重命名 (spec-39)**: `<date>-<n##>-<name>.md` → `<topic>_<date>-<n##>-<name>.md` 格式
- **路径归一化未同步**: spec-39 后 lessons 引用未批量更新
- **临时脚本引用**: lessons 中引用了 `.trash/test_*.py` 等临时文件,这些文件后续被清理
- **历史漂移积累**: 多次 spec 修改路径但未同步引用

## 5. 影响

- **飞轮读侧阻塞**: AI 读 lessons 找不到代码会迷失 (spec-46 飞轮读侧阻塞阈值 P0 > 100)
- **173 P0 远超阈值**: 即使 spec-46 已降到 173,仍超阈值 1.7 倍
- **AI 自我进化受阻**: AI 学习历史教训时无法定位相关代码
