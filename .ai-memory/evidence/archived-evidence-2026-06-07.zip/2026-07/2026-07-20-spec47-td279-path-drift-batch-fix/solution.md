---
evidence_for: spec-47
task_type: bug_fix
solution_summary: 4-Phase batch fix (3 fix scripts + 1 verify) — P0 173 → 0
related_files:
  - .trash/fix_path_drift_batch.py
  - .trash/fix_path_drift_phase25.py
  - .trash/fix_path_drift_phase3.py
  - .trae/specs/2026-07-20-spec47-td279-lesson-summary-path-drift-batch-fix.md
created_at: 2026-07-20
---

# Spec-47 Solution: 4-Phase batch fix

## 1. N167 七维度评分 (方案 A)

| 方案 | ① 架构 | ② 归一化 | ③ 兼容 | ④ 完善 | ⑤ 性能 | ⑥ 安全 | ⑦ 维护 | 总分 | 自决? |
|------|------|---------|------|------|------|------|------|------|------|
| A: 单 spec 4 Phase 批量修复 | 3 | 3 | 3 | 3 | 2 | 2 | 3 | 19 | ✅ |
| B: 拆 2 spec | 2 | 3 | 3 | 2 | 2 | 2 | 2 | 16 | ❌ |
| C: 仅修前缀 | 1 | 2 | 3 | 1 | 2 | 2 | 2 | 13 | ❌ |

**自决决策**: A (总分 19 ≥ 19, 领先 B 3 分)

## 2. 实施路径

### Phase 1+2+3 第一轮 (fix_path_drift_batch.py)

合并 3 Phase 为单脚本:
- **Phase 1 (5 类前缀)**: `GAF/` strip + `gaf-*/SKILL.md` 加前缀 + `_shared/X` 加前缀 + `docs/general/ai-lessons/X` 替换 + `meta/X` 加前缀
- **Phase 2 (30+ 历史映射)**: 字符串替换表 (verify.py 迁移 + lessons 重命名 + device_bridge 平台迁移等)
- **Phase 3 (描述性文字)**: `.trash/` 临时文件 + 已删除文件 + 通配符路径

**结果**: 38 文件,260 处替换 (138 前缀 + 87 映射 + 31 描述 + 4 frontmatter 移除)
**P0 降级**: 173 → 60

### Phase 2.5 第二轮 (fix_path_drift_phase25.py)

修复 Phase 2 字符串替换引入的双重前缀 bug + 补充映射:
- **双重前缀修复**: `backend/backend/X` → `backend/X` 等 (16 处)
- **新映射**: `.ai-memory/lessons/architecture-mistakes.md` → `.ai-memory/summaries/X` 等 (45 处)
- **新描述性文字**: 已删除路径补充 (8 处)
- **body 相对路径**: `lessons/X.md` → `.ai-memory/lessons/X.md` regex (10 处)

**结果**: 23 文件,79 处替换
**P0 降级**: 60 → 32

### Phase 3 第三轮 (fix_path_drift_phase3.py)

修复 Phase 2.5 引入的双重前缀 bug + 补充映射:
- **双重前缀修复 (regex)**: `.ai-memory/.ai-memory/X` → `.ai-memory/X` 等 (23 处)
- **新映射**: SkillMarket/TemplateAnnotationPage/utils/errorHandler 真实路径 (7 处)
- **新描述性文字**: 已删除 lessons + 已归档 spec + 通配符 (8 处)
- **frontmatter 中文后缀 strip**: `agent/src/devices/adb/device.py (参考 ADB 模式)` → `agent/src/devices/adb/device.py` (1 处)

**结果**: 15 文件,39 处替换
**P0 降级**: 32 → 0 ✅

## 3. 关键决策

### 3.1 字符串替换的子串匹配陷阱

Phase 2 的 string replace `agents/urls.py` → `backend/agents/urls.py` 会匹配 `backend/agents/urls.py` 中的子串,导致 `backend/backend/agents/urls.py` 双重前缀。

**修复策略**: 用 regex 反向匹配 (`backend/backend/X` → `backend/X`),而不是预防子串匹配。

### 3.2 描述性文字策略

- **已删除文件**: 改为描述性文字 (e.g., "backend input module (已重构到 agent/src/input/)")
- **frontmatter related_files**: 直接移除 entry (已删除文件不应再列入契约)
- **body path**: 改为描述性文字 (无 backticks,plain text)

### 3.3 不追溯 evidence/ 历史快照

spec-46 已把 `.ai-memory/evidence/` 降级到 P2 (历史快照,不追溯)。spec-47 只修 P0 (lessons/summaries/platforms)。

## 4. 路径引用规范 (本 spec 确立)

1. **repo 根相对路径** (e.g., `.ai-memory/lessons/foo.md`, `backend/skills/views.py`)
2. **不带 `GAF/` 前缀** (GAF 是 repo 名,非路径前缀)
3. **绝对路径优先于相对路径** (避免 `../SKILL.md` 类相对引用)
4. **已删除/已归档/临时文件用描述性文字** (不引用 `.trash/` 或 `archived-early/`)
5. **frontmatter related_files 只列存在的文件** (已删除文件应移除 entry)

## 5. 改动范围

- 53 个 markdown 文件修改 (lessons 38 + summaries 1 + platforms 3 + meta 3 + .trae 2 + 其他 6)
- 3 个临时修复脚本 (.trash/, 跑完即删)
- 0 个代码文件修改 (纯文档修复)
- 0 个测试文件修改
