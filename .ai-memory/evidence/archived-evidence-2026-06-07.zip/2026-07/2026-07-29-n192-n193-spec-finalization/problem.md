---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, problem-step, evidence-problem]
solution: N192/N193 spec 收尾 — 双调试视角 + schema 归一化 + 阶段 12 预先存在问题清零;N194 pytest-django 拖慢沉淀
related_files:
  - .ai-memory/evidence/templates/solution.md
  - .ai-memory/evidence/templates/verification.md
  - scripts/check_3step_evidence.py
  - docs/specs/done/2026-07-27-dual-debug-perspective-fixes.md
  - docs/plans/2026-07-28-dual-debug-and-schema-followup.md
created_by: AI
last_updated: 2026-07-29
---
## Problem（症状 / 触发条件）

N192/N193 spec (2026-07-27-dual-debug-perspective-fixes) 收尾时发现 4 个预先存在的问题阻塞归档:

1. agent `test_screenshot_cache_ttl` 失败 — `screenshot_cache.py:186` `int(effective_ttl)` 把 float 0.1 截为 0,Redis `setex` 拒绝 ttl=0;`get()` 仍查 Redis 返回 None 不 fallthrough 到 memory
2. backend 16 个测试 Redis 连接失败 — `tasks/signals.py` `broadcast_execution_status` 触发 `channel_layer.group_send` 打真实 Redis,测试环境无 Redis
3. backend 响应 schema 断言错误 — 测试断言旧 schema (`error`/`valid_actions` 顶层键),实际响应已归一为 `{code, message, data}` 结构
4. frontend 271 个 TypeScript 编译错误 — ajv 类型错误 + 未使用导入 + 隐式 any + 类型不匹配

影响范围: agent + backend + frontend 三层,spec 验收清单 4 项无法打 ✅,阻塞归档。

附加问题: 跑 agent 全量测试预计 2 小时,用户反馈"测试为啥这么久"。
