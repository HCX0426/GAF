---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, solution-step, evidence-solution]
solution: Solution 模板 — 列步骤 + 涉及文件 + 命令;gaf-3step-evidence hook 校验占位符必须替换
related_files:
  - .ai-memory/evidence/templates/problem.md
  - .ai-memory/evidence/templates/verification.md
  - scripts/check_3step_evidence.py
created_by: AI
last_updated: 2026-07-29
---
## Solution（解决步骤）

1. 修复 `agent/src/devices/screenshot_cache.py` — `set()` 方法 Redis TTL 改为 `max(1, int(round(effective_ttl)))`;`get()` 方法 Redis 返回 None 时 fallthrough 到 memory 查询
2. 修复 `backend/conftest.py` — 新增 `_mock_channel_layer` autouse fixture,用 monkeypatch 替换 `channels.layers.get_channel_layer` 返回 Mock 对象
3. 修复 `backend/executions/tests/test_execution_api.py` + `backend/pipeline/tests/test_views.py` — 断言改为 `message` 和 `data.valid_actions` 字段;新增 `_unwrap` / `_get_results` helper 适配 unified_response 信封
4. 修复 `frontend/package.json` — 安装 `ajv@^8.17.1` 解决 `schemaValidator.ts` 类型错误
5. 分两批修复 frontend TypeScript 错误 — 第一批删除未使用导入 + 补全缺失导入;第二批修复类型注解 + 类型转换 + 接口定义 (271 → 0)
6. 排查 agent 测试慢根因 — 用 `--durations=20` + `python _time_retry.py` 直跑对比,定位到 `pyproject.toml` 配置 `DJANGO_SETTINGS_MODULE` 导致 pytest-django 插件强制 `django.setup()`,单测 12s 起步;禁用插件 `-p no:django -o addopts=""` 后 2.5min 跑完全量
7. 沉淀 N194 到 L0 `.trae/rules/env-hardrules.md` 测试运行硬约束段 + L1 `failure-modes.md` N194 索引 + L3 `lessons/N194-pytest-django-slowdown-agent-tests.md`
