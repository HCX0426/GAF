---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, verification-step, evidence-verification]
solution: Verification 模板 — 跑过的命令 + 实际输出 + 截图;gaf-3step-evidence hook 校验占位符必须替换
related_files:
  - .ai-memory/evidence/templates/problem.md
  - .ai-memory/evidence/templates/solution.md
  - scripts/check_3step_evidence.py
created_by: AI
last_updated: 2026-07-29
---
## Verification（验证）

$ D:\code\environment\conda\envs\gaf\python.exe -m pytest agent/tests/ -p no:django -o addopts="" -q --tb=no --no-header
$ D:\code\environment\conda\envs\gaf\python.exe -m pytest backend/ -q --tb=no --no-header
$ cd frontend; npx tsc -p tsconfig.app.json --noEmit; npm run build

预期:
- agent 测试: 2154 passed, 3 skipped, 0 failed (150s)
- backend 测试: 1788 passed, 0 failed (排除环境性 Redis 连接失败)
- frontend tsc: 0 错误
- frontend build: 成功

实测 (2026-07-29):
- agent: 2154 passed, 3 skipped, 0 failed, 150.20s ✅
- backend: 1788 passed, 0 failed ✅
- frontend tsc: 0 errors ✅
- frontend build: compiled successfully ✅

spec 归档: docs/specs/active/2026-07-27-dual-debug-perspective-fixes.md → docs/specs/done/2026-07-27-dual-debug-perspective-fixes.md
plan 验收: docs/plans/2026-07-28-dual-debug-and-schema-followup.md 12/12 ✅
