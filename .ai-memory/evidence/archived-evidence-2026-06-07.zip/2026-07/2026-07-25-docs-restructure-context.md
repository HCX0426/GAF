# Spec Context: docs/ 与 .ai-memory/ 重构

> **本文件不是 spec，是对话上下文承载体**。
> 用途：当当前会话上下文被压缩或丢失时，下一个 AI 会话可以直接读本文件恢复全部决策上下文，继续推进规格设计与实施。
> 生命周期：规格实施完成后（P0/P1/P2 全部 commit）→ 移到 `evidence/archived/YYYY-MM/`。

---

## 元信息

- **创建时间**: 2026-07-25
- **状态**: 设计完成（§1-§9 已确认，待创建正式 spec + plan）
- **关联 spec**: `docs/specs/active/2026-07-25-docs-ai-memory-restructure.md`（待创建）
- **关联 plan**: `docs/plans/2026-07-25-docs-ai-memory-restructure.md`（待创建）
- **当前进度**: 规格设计阶段完成，待创建正式 spec + plan 文档
- **下一节**: 创建正式 spec + plan 文档，然后实施 P0

---

## 背景与起因

### 起因
用户问"现在ai的记忆文档，和我的docs文档的结构是咋样的"，AI 回答后用户指出"有问题，这两个文件夹里的内容都是ai维护的没人工这一步骤"，确认两个目录都是 AI 维护。

### 核心问题（AI 自评）
1. spec 目录有 4 个，职责重叠（`docs/general/specs/` / `docs/superpowers/specs/` / `docs/specs/` / `.trae/specs/`）
2. `.ai-memory/` 根目录 8 个文件职责混乱
3. `evidence/` 与 `lessons/` 重复且无合并机制
4. `evidence/` 无清理机制（50+ 目录堆积）
5. lessons 文件名超长（60+ 字符，N编号+日期+主题+slug 全塞文件名）
6. `docs/` 描述与现状脱节（还写"人工维护"）
7. `docs/general/` 扁平但分层模糊

### 根本矛盾
`docs/` 既不是纯人类视角，也不是纯 AI 视角。人类看 docs/ 的真实路径是业务/架构双线索（对应 `project_rules.md §0` 三份核心文档），但目录结构按"文档类型"分（analysis/design/standards/...），对不上。

### AI 思维链入口
AI 不从 `docs/` 找入口，而是从 `.trae/skills/gaf-orchestrator/SKILL.md` 决策树 → L1 failure-modes → L2 handbook → L3 docs-index 按需加载。`docs/` 是 L3 按需数据源。

---

## 用户决策清单（按对话顺序，原文）

| # | 决策点 | 用户原文/选择 |
|---|--------|--------------|
| 1 | 两个目录都改还是只改一个 | "两个都改" |
| 2 | 分阶段还是一次性 | "分 3 阶段" |
| 3 | `.trae/` 目录动不动 | ".trae 不动" |
| 4 | lessons 文件名格式 | "N编号-slug" |
| 5 | evidence 清理策略 | "active + 30天" |
| 6 | docs/business/ 是否建 9 模块子目录 | "9 模块子目录" |
| 7 | docs/architecture/ 是否按五层架构 | "五层架构" |
| 8 | 引用更新策略 | "全量 grep + hook" |
| 9 | `.ai-memory/` 根目录收敛 | "ref 收敛" |
| 10 | governance/ 怎么处理 | "governance 入 ops" |
| 11 | 先重构还是先加新内容 | "先重构" |
| 12 | frontmatter 加什么字段 | "加 module 字段" |
| 13 | 三个备选方案选哪个 | "A"（双线索主导） |
| 14 | 自动清理用不用系统注册表 | "不用注册表，gaf启动再开启检测即可，完成后就停掉" |
| 15 | 旧路径要不要保留兼容 | "不需要恢复旧目录结构了，都用新的" |
| 16 | AI 自我进化要不要设计 | "这个设计还得考量ai沉淀的自我进化" |
| 17 | 是否需要上下文承载体文档 | "是不是设计一个文档用来承载上下文好点？这不是spec，记录原文给下个对话" |
| 18 | 文档与代码同步更新 | "希望更新对应业务或者架构时，ai能同步更新文档，别之后访问文档又是过时的" |
| 19 | 定时任务可行性 | "定时执行不太可能，顶多是对话访问文档时检查下实际代码行为是否一致吧，因为是在ide开发得，并不是我有设置llm让他定时查看，ide开发时，软件也只在调试时启动" |
| 20 | 检查时机 | "对话访问文档时检查下实际代码行为是否一致"（确认 §9.4 删定时，改对话内即时检查） |

---

## 已确认章节原文

### §1 — 设计目标与原则

**目标**：让 `docs/` 和 `.ai-memory/` 两个目录从"演进残留"变为"双线索主导的清晰结构"。

**核心原则**：

1. **双线索导航**（docs/）
   - 业务线索：按前端侧边栏 9 模块（workspace/game-profile/tasks/devices/resources/accounts/ops/ai/system）
   - 架构线索：按 GAF 五层（frontend/backend/agent/desktop/cross-cutting）
   - 文档归属强制二选一，跨业务+架构的文档放 `architecture/cross-cutting/`

2. **过程 vs 稳定分离**（两个目录分工）
   - `.ai-memory/` = AI 思维链**过程产物**（lessons/evidence/decision matrices/session）
   - `docs/` = **稳定知识库**（业务/架构/规范/技术债），AI L3 按需查询

3. **目录路径 = frontmatter module 值**
   - `docs/business/tasks/pipeline-design.md` → `module: business.tasks`
   - `docs/architecture/backend/celery-design.md` → `module: architecture.backend`
   - `sync_docs_index.py` 自动从目录路径生成 module 字段

4. **分阶段迁移，每阶段独立可验证**
   - P0：双线索建立 + spec 目录合并（最大收益）
   - P1：lessons 改名 + evidence 加清理（防堆积）
   - P2：根目录收敛 + 引用同步 hook（防回退）

5. **不动的部分**
   - `.trae/specs/`（TRAE 工具自动生成，保留原位）
   - `.trae/skills/`、`.trae/rules/`、`.trae/plans/`（不在本次范围）
   - `.ai-memory/{meta,knowledge,games,platforms,summaries,checklists,ops,session}/`（结构合理，保留）

**成功标准**：
- 人类按业务或架构找文档，最多 2 次点击定位
- AI 通过 `docs-index.md` 的 `module` 字段过滤，0 跳转直达目标
- 100+ 文件路径引用全部更新，pre-commit hook 防止旧路径回退
- 无任何文件内容丢失（git mv 保留历史）

**用户确认**：§1 没问题（已确认）

---

### §2 — docs/ 目标结构

```
docs/
├── README.md                          # 双线索导航入口（新建）
│
├── business/                          # 业务视角（9 模块，对应前端侧边栏）
│   ├── README.md                      # 9 模块索引（新建）
│   ├── workspace/                     # 工作台
│   ├── game-profile/                  # 游戏档案
│   ├── tasks/                         # 任务
│   │   ├── pipeline-design.md         # ← 移自 general/design/custom-task-design.md + pipeline-authoring-guide.md
│   │   ├── timeline-design.md         # ← 移自 general/design/debug-timeline-design.md
│   │   ├── debug-mode-design.md       # ← 移自 general/design/
│   │   ├── recovery-design.md         # ← 移自 general/design/interface-recovery-design.md
│   │   ├── cancel-design.md           # ← 移自 general/design/task-cancel-design.md
│   │   ├── execution-reality.md       # ← 移自 general/design/task-execution-reality.md
│   │   └── troubleshooting.md         # ← 移自 general/troubleshooting/task-execution-troubleshooting.md
│   ├── devices/                       # 设备
│   │   ├── dpi-coordinate.md          # ← 移自 general/design/dpi-coordinate-system.md
│   │   └── screenshot-optimization.md # ← 移自 general/design/
│   ├── resources/                     # 资源
│   │   └── resource-pack-design.md    # ← 移自 general/design/
│   ├── accounts/                      # 账户（暂空，待新文档填入）
│   ├── ops/                           # 运维
│   │   ├── monitor-design.md          # ← 移自 general/design/monitor-design.md
│   │   ├── governance-dashboard.md    # ← 移自 governance/dashboard.md
│   │   └── health-checks/             # ← 移自 general/health-checks/
│   ├── ai/                            # AI
│   │   ├── llm-integration.md         # ← 移自 general/design/llm-integration-design.md
│   │   └── input-mode-window-wait.md  # ← 移自 general/design/
│   └── system/                        # 系统（暂空，待新文档填入）
│
├── architecture/                      # 架构视角（五层 + 横切）
│   ├── README.md                      # 五层架构索引（新建）
│   ├── overview.md                    # ← 移自 general/design/architecture-overview.md
│   ├── optimal-solution.md            # ← 移自 general/analysis/GAF-optimal-solution.md
│   ├── features-overview.md           # ← 移自 general/design/gaf-features-overview.md（业务×架构映射）
│   ├── frontend/                      # 前端层（暂空，待新文档填入）
│   ├── backend/                       # 后端层（暂空，待新文档填入）
│   ├── agent/                         # Agent 层（暂空，待新文档填入）
│   ├── desktop/                       # Desktop 层
│   │   └── deployment-design.md       # ← 移自 general/design/deployment-design.md
│   └── cross-cutting/                 # 横切关注点
│       ├── concurrency-design.md      # ← 移自 general/design/concurrency-design.md
│       ├── data-flow.md               # ← 移自 general/design/（如有）
│       └── pre-commit-stages.md       # ← 移自 general/design/pre-commit-stages.md
│
├── analysis/                          # 对比分析（保留顶层，因为是外部对比非 GAF 内部架构）
│   ├── GAF-vs-Alas-analysis.md
│   ├── GAF-vs-BD2-analysis.md
│   ├── GAF-vs-MaaFramework-analysis.md
│   ├── GAF-vs-ok-script-analysis.md
│   └── evaluation-zxcvbn-replacement.md
│
├── standards/                         # 编码规范（保持）
│   ├── api-contract.md
│   ├── backend-conventions.md
│   ├── frontend-conventions.md
│   └── testing-conventions.md
│
├── tech-debt/                         # 技术债（移到顶层，原 general/tech-debt/）
│   ├── README.md
│   ├── active.md
│   ├── fixed.md
│   └── wontfix.md
│
├── specs/                             # 合并 4 个 spec 目录为 1 个
│   ├── README.md                      # spec 编写规范（新建）
│   ├── dependency-graph.md            # ← 移自 general/specs/ + docs/specs/ 合并
│   ├── active/                        # 进行中
│   │   └── 2026-07-25-logging-pipeline-hardening.md  # ← 移自 superpowers/specs/
│   └── archived/                      # 已完成按月归档
│       └── 2026-07/
│
├── plans/                             # 实施计划（合并 superpowers/plans/）
│   └── 2026-07-25-logging-and-pipeline-hardening.md
│
├── health/                            # 健康检查（移自 general/health-checks/）
│   ├── README.md
│   └── 2026-07.md
│
├── completed-features.md              # ← 移自 general/
├── monthly-health-check.md            # ← 移自 general/
└── pending-roadmap.md                 # ← 移自 general/
```

**关键设计决策**：

1. **`business/` 9 模块对应前端侧边栏** — 人类按"我在用哪个功能"找文档
2. **`architecture/` 五层 + 横切** — 人类按"我在改哪一层"找文档
3. **`features-overview.md` 放 `architecture/` 根** — 它是业务×架构映射表，属架构视角
4. **`analysis/` 保留顶层** — 4 份外部对比文档不属 GAF 内部架构，独立放
5. **`health/` 顶层 vs `business/ops/health-checks/`** — 月度健康报告是过程产物放 `health/`，运维治理放 `business/ops/`
6. **`specs/active/` + `specs/archived/YYYY-MM/`** — 进行中可快速找，已完成按月归档
7. **`plans/` 提到顶层** — 实施计划是独立产物，不该埋在 `superpowers/` 下
8. **空目录占位**（`workspace/`、`accounts/`、`system/`、`frontend/`、`backend/`、`agent/`）— 9 模块和 5 层都建出来，未来文档有归宿

**`general/` 目录消失** — 所有内容按双线索重新分配。

**用户确认**：§2 没问题（已确认）

---

### §3 — `.ai-memory/` 目标结构

```
.ai-memory/
├── README.md                          # 入口（保持，更新维护说明）
│
├── meta/                              # 元数据（保持，L1/L2 hard load）
│   ├── ai-operating-handbook.md       # L2 必读
│   ├── failure-modes.md               # L1 硬加载 N## 索引表
│   ├── docs-index.md                  # docs/ 索引（自动生成，加 module 字段）
│   ├── yn-matrices.md                 # Y/N 矩阵汇总
│   ├── yn-matrices/                   # 7 个分类决策矩阵
│   │   ├── _ai-autonomy.md
│   │   ├── _cross-layer-sync.md
│   │   ├── _honest-status.md
│   │   ├── _misc.md
│   │   ├── _refactor-dimensions.md
│   │   ├── _testing.md
│   │   └── _workflow.md
│   ├── auto-kb/                       # 4 个自动 KB（保持）
│   │   ├── agent-protocol.md
│   │   ├── api-endpoints.md
│   │   ├── error-codes.md
│   │   └── pipeline-nodes.md
│   ├── spec-evolution.md              # spec 演进史
│   └── archived-lessons.md            # 已闭环 N##
│
├── ref/                               # ★ 新建：根目录收敛 6 个文件
│   ├── tech-stack.md                  # ← 移自根目录
│   ├── version-compat.md              # ← 移自根目录
│   ├── data-flow.md                   # ← 移自根目录
│   ├── cli-cheatsheet.md              # ← 移自根目录
│   ├── session-context.md             # ← 移自根目录（auto-generated）
│   └── spec-index.md                  # ← 移自根目录
│
├── lessons/                           # 教训（文件名简化）
│   ├── README.md                      # 入口（更新命名规则说明）
│   ├── archived-early/                # 早期归档（保持）
│   ├── N188-conda-env-not-enforced.md          # ← 原 platform-env_2026-07-25-n188-conda-env-not-enforced.md
│   ├── N151-architecture-first.md              # ← 原 architecture_2026-07-08-n151-architecture-first-for-major-changes.md
│   ├── N184-node-observability-hard-constraint.md
│   ├── N182-bug-investigation-three-dimensional-root-cause.md
│   ├── N183-bug-fix-three-dimensional-root-cause.md
│   └── ... (60+ 个 N 编号 lesson 全部改名为 N<编号>-<slug>.md)
│
├── evidence/                          # 证据（加 active/archived + cleanup）
│   ├── README.md                      # ★ 新建：说明沉淀规则
│   ├── active/                        # ★ 新建：< 30 天，待沉淀
│   │   └── 2026-07-25-logging-pipeline-hardening/  # ← 移自 evidence/
│   │       ├── problem.md
│   │       ├── solution.md
│   │       └── verification.md
│   ├── archived/                      # ★ 新建：> 30 天，已沉淀或过期
│   │   └── 2026-06/
│   │       └── ... (50+ 个旧 evidence 目录按月归档)
│   └── templates/                     # 模板（保持）
│       ├── problem.md
│       ├── solution.md
│       └── verification.md
│
├── knowledge/                         # 领域知识（保持）
├── games/                             # 游戏特定（保持）
├── platforms/                         # 平台特定（保持）
├── summaries/                         # 主题汇总（保持）
├── checklists/                        # 检查清单（保持）
├── ops/                               # 运维旁路（保持）
├── session/                           # 会话临时（保持）
└── doc-health-report-schema.md        # 文档健康报告 schema（移到 ref/ 下）
```

**关键设计决策**：

1. **`ref/` 收敛根目录 6 个文件** — 根目录只留 README.md
2. **lessons 文件名 = `N<编号>-<slug>.md`** — N 编号是唯一 ID，去掉日期和主题前缀。主题分类靠 frontmatter `topic` 字段
3. **evidence 加 active/archived 二级目录 + cleanup_old_evidence 定时任务** — 30 天未沉淀的归档
4. **evidence 与 lessons 明确分工** — evidence 是过程（active），lessons 是结论（沉淀后）

**新增 Celery 任务**（与 §8 归档机制呼应）：

```python
# backend/gaf_core/tasks.py
@shared_task(acks_late=True, max_retries=3, retry_backoff=60)
def cleanup_old_evidence():
    """将 > 30 天的 evidence/active/ 移到 evidence/archived/YYYY-MM/ (spec §4)."""
```

**frontmatter 字段示例**（lessons 新增 `topic` 字段替代文件名前缀）：

```yaml
---
maintainer: manual
source: .ai-memory/lessons/N188-conda-env-not-enforced.md
load_when: [conda, env, Python, 规则违反]
priority: high
symptom: [conda 环境未生效, 系统 Python 误用]
solution: L0 硬约束 env-hardrules.md, conda run -n gaf
related_files:
  - .trae/rules/env-hardrules.md
created_by: AI
topic: platform-env        # ★ 新增: 替代原文件名前缀
n_id: N188                 # ★ 新增: 显式 N 编号
generated: 2026-07-25
---
```

**用户确认**：§3 没问题（已确认）

---

### §4 — AI 自我进化沉淀闭环

**问题**：当前设计只有 cleanup（被动清理过期），缺 promote（主动沉淀模式）。

#### 沉淀闭环设计

```
┌─────────────────────────────────────────────────────────────────┐
│  ① 任务执行                                                      │
│    evidence/active/<date>-<topic>/                               │
│    ↓                                                             │
│  ② 模式识别 (AI 任务收尾时扫)                                    │
│    - 同 topic / 同 symptom 在 active/ 出现 ≥ 2 次                │
│    - 或同 root_cause 在 failure-modes.md 出现 ≥ 2 次             │
│    ↓                                                             │
│  ③ 主动沉淀 (AI 自动触发, 无需用户介入)                          │
│    a. 分配 N 编号 (lessons/README.md 维护计数器)                 │
│    b. 写 lessons/N<编号>-<slug>.md (含 topic/n_id frontmatter)   │
│    c. failure-modes.md 加 N## 索引行 (1 行 + 链接)               │
│    d. 原证据移到 evidence/archived/YYYY-MM/                      │
│    e. 涉及规则 → 同步沉淀到 .trae/rules/ (D3 强制同步)          │
│    ↓                                                             │
│  ④ 自我进化 (定期反思)                                           │
│    - daily_self_evolution_task 扫 lessons/ 提取跨 lesson 模式    │
│    - 写 summaries/architecture-mistakes.md 等 (按主题汇总)       │
│    - 高频模式 → 升级为 Y/N 矩阵 (yn-matrices/_*.md)              │
│    ↓                                                             │
│  ⑤ 遗忘机制 (避免无限膨胀)                                       │
│    - lessons/ N## 索引行: 6 个月未触发 → 标记 cold               │
│    - cold N## 移到 archived-lessons.md (不再 L1 硬加载)          │
│    - evidence/archived/ > 90 天 → 删除 (cleanup_old_evidence)    │
└─────────────────────────────────────────────────────────────────┘
```

#### 触发机制（§8.1 问题 9-11 修正 + 用户决策 19/20 修正）

**重要修正**：原设计的 Celery beat 定时任务（daily_self_evolution_task / monthly_forgetting_task）在 IDE 开发模式下不可行 — GAF 不持续运行，凌晨定时任务不会触发。改为"启动时跑一次 + AI 会话内触发"。

**触发点 1：AI 会话启动时（SKILL.md 规则触发，非定时）**
- AI 启动时扫 `evidence/active/` 同 topic 出现次数
- ≥ 2 次 → 标记 `pending_promotion`
- AI 在当前会话内处理 pending_promotion（写 lesson + 更新 failure-modes + 移 evidence 到 archived）
- 由 `gaf-orchestrator` SKILL.md 强制执行

**触发点 2：GAF 启动时跑一次（startup_checks，非定时）**
- `cleanup_old_evidence_once()`：active > 30 天 → 移 archived/
- `forgetting_check_once()`：last_triggered < 6 月前 → 标 cold，移 archived-lessons.md
- `cleanup_old_archives_once()`：删 30 天前 tar.gz（已有，改启动时跑）
- 由 Django AppConfig.ready() 钩子触发，异步跑（threading.Thread 不阻塞启动）

**关键变化**：
- 异步任务不调 LLM（成本高且不可控）— 只做模式识别 + 标记 pending_promotion
- 实际 lesson 写作由下次 AI 会话触发（AI 启动时扫 pending_promotion 队列）
- 升级为规则走 AskUserQuestion 确认（异步任务无用户交互，必须由 AI 会话处理）

#### N 编号分配机制

```python
# .ai-memory/lessons/README.md 维护计数器
# next_n_id: N189  (当前最大 N188 + 1)

def allocate_n_id(topic: str, slug: str) -> str:
    """分配新 N 编号, 原子递增 next_n_id."""
    # 1. 读 lessons/README.md 的 next_n_id
    # 2. 写 lessons/N<next>-<slug>.md
    # 3. next_n_id += 1, 更新 README.md
    # 4. 返回 N<next>
```

**防并发**：用文件锁 `%.cache/lessons_n_id.lock`（与 agent PID 锁同模式）。

#### failure-modes.md 索引行增强

```markdown
| N## | topic | 硬约束 1 行 | lesson 链接 | trigger_count | last_triggered | status |
|-----|-------|------------|-------------|---------------|----------------|--------|
| N188 | platform-env | conda run -n gaf 硬约束 | [N188](lessons/N188-conda-env-not-enforced.md) | 5 | 2026-07-25 | hot |
| N151 | architecture | 大修改必跑 5 步 | [N151](lessons/N151-architecture-first.md) | 12 | 2026-07-20 | hot |
| N095 | workflow | 跨会话分布差距 | [N095](archived-lessons.md#N095) | 0 | 2026-01-15 | cold |
```

#### 升级路径（lesson → Y/N 矩阵 → 规则）

```
evidence (单次) → lesson (N##, 模式) → Y/N 矩阵 (主题级) → 规则 (硬约束)
                                                    ↓
                                            .trae/rules/*.md (L0/L1)
```

**升级条件**：
- lesson 单独存在 → L3 按需加载
- 同 topic 的 lessons ≥ 3 个 → 升级为 `yn-matrices/_<topic>.md` Y/N 矩阵
- Y/N 矩阵被频繁违反（≥ 5 次）→ 升级为 `.trae/rules/` 硬约束（如 N188 → env-hardrules.md）

#### 新增 startup_checks 函数（替代 Celery 定时任务）

**重要修正**：原设计的 Celery 定时任务全部改为 GAF 启动时跑一次的函数。

```python
# backend/gaf_core/startup_checks.py (新建)
"""GAF 启动时跑一次的检查任务 (spec §4/§5 修正).

IDE 开发模式下 GAF 不持续运行, Celery beat 定时任务不会触发.
改为 GAF 启动时 (Django AppConfig.ready 钩子) 跑一次 cleanup + forgetting.
"""

def cleanup_old_evidence_once():
    """active > 30 天 → 移 archived/YYYY-MM/ (spec §4.3 修正)."""

def forgetting_check_once():
    """last_triggered < 6 月前 → 标 cold, 移 archived-lessons.md (spec §4.5 修正)."""

def cleanup_old_archives_once():
    """删 30 天前 tar.gz (已有 cleanup_old_archives, 改为启动时跑一次)."""

def run_startup_checks():
    """Django AppConfig.ready() 调用, GAF 启动时异步跑一次."""
    import threading
    threading.Thread(
        target=lambda: [
            cleanup_old_archives_once(),
            cleanup_old_evidence_once(),
            forgetting_check_once(),
        ],
        daemon=True,
    ).start()
```

**触发位置**：

```python
# backend/gaf_core/apps.py
class GafCoreConfig(AppConfig):
    name = 'gaf_core'
    
    def ready(self):
        """GAF 启动时跑一次检查 (spec §5 修正)."""
        from gaf_core.startup_checks import run_startup_checks
        run_startup_checks()
```

**手动触发**：

```bash
# 手动跑一次（不等 GAF 启动）
conda run -n gaf python manage.py run_startup_checks --all --dry-run
```

#### 风险与缓解

| 风险 | 缓解 |
|------|------|
| AI 误沉淀（噪声模式） | trigger_count ≥ 2 才触发；Y/N 矩阵升级需 ≥ 3 lessons |
| N 编号并发冲突 | 文件锁 + 原子递增 |
| lesson 膨胀 | 月度遗忘机制 + cold 移 archived-lessons.md |
| 沉淀后原 evidence 丢失 | 不删除，移 archived/，保留 90 天 |
| 升级为规则过激 | Y/N 矩阵被违反 ≥ 5 次才升级；规则升级走 AskUserQuestion 确认 |

**用户确认**：§4 没问题（已确认）

---

### §5 — 启动钩子 + AI 会话内触发（修正后）

**用户决策修正（决策 19）**：原设计的 Celery beat 定时任务在 IDE 开发模式下不可行 — GAF 不持续运行，凌晨定时任务不会触发。改为"启动时跑一次 + AI 会话内触发"。

**核心变化**：
- ~~Celery worker + beat 子进程管理~~ → 删除
- ~~celery beat schedule 注册~~ → 删除
- ~~atexit + signal 优雅停止~~ → 删除
- ~~backend PID 文件锁~~ → 删除
- 新增 `startup_checks.py` + Django AppConfig.ready() 钩子
- AI 会话成为主要触发点（SKILL.md 规则强制）

#### 修正后的运行模型

```
┌─────────────────────────────────────────────────────────────┐
│  GAF 启动 (Django runserver / daphne)                       │
│  ↓                                                          │
│  ① AppConfig.ready() 触发 startup_checks (异步跑一次)       │
│     - cleanup_old_archives_once (删 30 天前 tar.gz)         │
│     - cleanup_old_evidence_once (移 30 天前 active→archived)│
│     - forgetting_check_once (标 6 月未触发 N## 为 cold)     │
│  ↓                                                          │
│  ② GAF 正常运行 (无后台定时任务, 无 Celery worker/beat)     │
│  ↓                                                          │
│  ③ AI 会话启动 (用户在 TRAE IDE 开新对话)                   │
│     - SKILL.md 规则: 扫 evidence/active/ pending_promotion  │
│     - SKILL.md 规则: 访问 docs/ 时实时查 git log 检查 stale │
│  ↓                                                          │
│  GAF 停止                                                   │
│  ↓                                                          │
│  ④ 无残留进程, 无 Celery worker, 无 beat, 无系统级任务      │
└─────────────────────────────────────────────────────────────┘
```

#### 实现要点

**1. startup_checks.py**（见 §4 已展示代码）
- 异步跑（threading.Thread daemon=True），不阻塞 Django ready
- 幂等设计（重跑无副作用）

**2. AI 会话内触发（SKILL.md 规则）**
- AI 启动时扫 `evidence/active/` 同 topic ≥ 2 → 标记 pending_promotion
- AI 访问 docs/ 时实时查 git log 检查 stale（§9 机制）
- 升级为规则走 AskUserQuestion 确认

**3. 手动触发**

```bash
# 手动跑一次 startup_checks（不等 GAF 启动）
conda run -n gaf python manage.py run_startup_checks --all --dry-run
conda run -n gaf python manage.py run_startup_checks --all
```

#### 关键约束

- **无 Celery worker/beat** — 不需要子进程管理
- **无定时任务** — 全部改为启动时 + 对话内触发
- **无系统级调度** — 不用注册表/cron/任务计划程序
- **AI 会话是主要触发点** — SKILL.md 规则强制执行

**用户确认**：§5 没问题（已确认，含修正）

---

### §6 — 迁移阶段划分

分 P0/P1/P2 三阶段。每阶段独立可验证、可回退。

#### P0：双线索建立 + spec 目录合并（最大收益）

**目标**：人类按业务/架构找文档，spec 目录单一化。

**改动范围**：
1. 新建 `docs/business/` 9 模块子目录 + `docs/architecture/` 五层子目录
2. `git mv` 迁移 `docs/general/design/` 18 个文档到双线索结构
3. `git mv` 迁移 `docs/general/analysis/` 5 个对比文档到 `docs/analysis/`
4. `git mv` 迁移 `docs/general/troubleshooting/` 到 `docs/business/tasks/`
5. `git mv` 迁移 `docs/general/tech-debt/` 到 `docs/tech-debt/`
6. `git mv` 迁移 `docs/general/health-checks/` 到 `docs/health/`
7. `git mv` 迁移 `docs/general/specs/` + `docs/specs/` + `docs/superpowers/specs/` 合并到 `docs/specs/{active,archived}/`
8. `git mv` 迁移 `docs/superpowers/plans/` 到 `docs/plans/`
9. `git mv` 迁移 `docs/governance/dashboard.md` 到 `docs/business/ops/governance-dashboard.md`
10. `git mv` 迁移 `docs/general/` 顶层 3 文件到 `docs/` 顶层
11. 删除空目录
12. 新建 `docs/README.md` + `docs/business/README.md` + `docs/architecture/README.md` + `docs/specs/README.md`
13. 更新 `sync_docs_index.py` 适配新结构 + 加 `module` 字段生成
14. 重跑 `sync_docs_index.py` 生成新 `docs-index.md`

**迁移映射表**（关键文档）：

| 原路径 | 新路径 | module 字段 |
|--------|--------|-------------|
| `docs/general/design/architecture-overview.md` | `docs/architecture/overview.md` | `architecture` |
| `docs/general/analysis/GAF-optimal-solution.md` | `docs/architecture/optimal-solution.md` | `architecture` |
| `docs/general/design/gaf-features-overview.md` | `docs/architecture/features-overview.md` | `architecture` |
| `docs/general/design/custom-task-design.md` | `docs/business/tasks/pipeline-design.md` | `business.tasks` |
| `docs/general/design/debug-timeline-design.md` | `docs/business/tasks/timeline-design.md` | `business.tasks` |
| `docs/general/design/interface-recovery-design.md` | `docs/business/tasks/recovery-design.md` | `business.tasks` |
| `docs/general/design/task-cancel-design.md` | `docs/business/tasks/cancel-design.md` | `business.tasks` |
| `docs/general/design/task-execution-reality.md` | `docs/business/tasks/execution-reality.md` | `business.tasks` |
| `docs/general/design/monitor-design.md` | `docs/business/ops/monitor-design.md` | `business.ops` |
| `docs/general/design/llm-integration-design.md` | `docs/business/ai/llm-integration.md` | `business.ai` |
| `docs/general/design/deployment-design.md` | `docs/architecture/desktop/deployment-design.md` | `architecture.desktop` |
| `docs/general/design/concurrency-design.md` | `docs/architecture/cross-cutting/concurrency-design.md` | `architecture.cross-cutting` |
| `docs/general/design/pre-commit-stages.md` | `docs/architecture/cross-cutting/pre-commit-stages.md` | `architecture.cross-cutting` |
| `docs/general/design/dpi-coordinate-system.md` | `docs/business/devices/dpi-coordinate.md` | `business.devices` |
| `docs/general/design/screenshot-optimization.md` | `docs/business/devices/screenshot-optimization.md` | `business.devices` |
| `docs/general/design/resource-pack-design.md` | `docs/business/resources/resource-pack-design.md` | `business.resources` |
| `docs/general/design/input-mode-and-window-wait-design.md` | `docs/business/ai/input-mode-window-wait.md` | `business.ai` |
| `docs/general/design/debug-mode-design.md` | `docs/business/tasks/debug-mode-design.md` | `business.tasks` |
| `docs/general/troubleshooting/task-execution-troubleshooting.md` | `docs/business/tasks/troubleshooting.md` | `business.tasks` |
| `docs/superpowers/specs/2026-07-25-logging-pipeline-hardening-design.md` | `docs/specs/active/2026-07-25-logging-pipeline-hardening.md` | `specs.active` |
| `docs/superpowers/plans/2026-07-25-logging-and-pipeline-hardening.md` | `docs/plans/2026-07-25-logging-and-pipeline-hardening.md` | `plans` |

**Commit 信息**：
```
refactor(docs): P0 双线索结构 + spec 目录合并 (spec §6.1)

- 新建 docs/business/ (9 模块) + docs/architecture/ (五层 + 横切)
- 迁移 18 份 design + 5 份 analysis + 1 份 troubleshooting 到双线索
- 合并 4 个 spec 目录为 docs/specs/{active,archived}/
- docs/superpowers/plans/ 提升到 docs/plans/
- 删除 docs/general/ / docs/superpowers/ / docs/governance/
- 新建 docs/README.md (双线索导航入口)
- sync_docs_index.py 适配 + 加 module 字段生成
- 重跑生成新 docs-index.md
```

#### P1：lessons 改名 + evidence active/archived + 自我进化闭环

**目标**：lessons 文件名简化 + evidence 防堆积 + AI 自我进化沉淀闭环。

**改动范围**：
1. `.ai-memory/lessons/` 60+ 文件改名 `N<编号>-<slug>.md`
2. 更新 lessons frontmatter 加 `topic` + `n_id` 字段
3. 更新 `failure-modes.md` 索引行加 `trigger_count` / `last_triggered` / `status` 字段
4. 新建 `.ai-memory/evidence/active/` + `.ai-memory/evidence/archived/`
5. `git mv` 现有 50+ evidence 目录到 `archived/YYYY-MM/`
6. 新建 `.ai-memory/evidence/README.md`（沉淀规则说明）
7. 新建 `.ai-memory/lessons/README.md` 维护 `next_n_id: N189` 计数器
8. 实现 `cleanup_old_evidence` Celery 任务
9. 实现 `daily_self_evolution_task` Celery 任务
10. 实现 `monthly_forgetting_task` Celery 任务
11. 注册 3 个新任务到 `config/celery.py` beat schedule
12. 新建 `run_self_evolution` Django 管理命令
13. 单元测试 4 项

**迁移映射表**（lessons 改名示例）：

| 原文件名 | 新文件名 | topic | n_id |
|---------|---------|-------|------|
| `platform-env_2026-07-25-n188-conda-env-not-enforced.md` | `N188-conda-env-not-enforced.md` | `platform-env` | `N188` |
| `architecture_2026-07-08-n151-architecture-first-for-major-changes.md` | `N151-architecture-first.md` | `architecture` | `N151` |
| `workflow_2026-07-22-n184-node-observability-hard-constraint.md` | `N184-node-observability-hard-constraint.md` | `workflow` | `N184` |
| `agent-impl_2026-07-12-n158-langgraph-agent-implementation.md` | `N158-langgraph-agent-implementation.md` | `agent-impl` | `N158` |
| `testing_2026-06-17-n118-m2a-43-tests.md` | `N118-m2a-43-tests.md` | `testing` | `N118` |

#### P2：根目录收敛 + 引用同步 hook + Celery 子进程管理

**目标**：`.ai-memory/` 根目录清爽 + 100+ 路径引用同步 + 防回退 hook + Celery 随启停。

**改动范围**：
1. `.ai-memory/` 根目录 6 文件 `git mv` 到 `.ai-memory/ref/`
2. `git mv` `.ai-memory/doc-health-report-schema.md` 到 `.ai-memory/ref/`
3. 更新所有引用 `.ai-memory/tech-stack.md` 等的文件指向 `ref/`
4. 实现 GAF 启动时自动拉起 Celery worker + beat
5. 实现 atexit + signal 优雅停止
6. 实现 backend PID 文件锁
7. 新增 pre-commit hook `check_doc_path_drift.py`
8. 更新 `sync_ai_memory.py` 适配 `ref/` 新路径
9. 全量 grep + 更新 100+ 文件路径引用

**用户确认**：§6 没问题（已确认）

---

### §7 — 旧路径零兼容（彻底迁移）

**用户决策**：旧路径不保留、不软链、不重定向。迁移完成后旧路径全部消失，引用旧路径的代码/文档**必须**更新为新路径，否则 commit 被 hook 拒绝。

#### 不做的事

| 反模式 | 不做的理由 |
|--------|-----------|
| ~~旧路径留 README.md 重定向~~ | 双重存在期 + AI 不知该读哪个 |
| ~~旧路径软链到新路径~~ | 软链在 Windows 上需管理员权限 + 跨平台不一致 |
| ~~保留旧路径 N 天再删~~ | 永远有人不更新引用，N 天后还是有引用 |
| ~~回退到旧结构~~ | 用户已确认"都用新的"，回退路径不需要 |

#### check_doc_path_drift.py 永久约束（§8.1 问题 13-15 修正）

```python
# .pre-commit-hooks/check_doc_path_drift.py
"""永久约束 (spec §7): 禁止以下旧路径出现在任何 .md / .py / .yaml 文件中.

§8.1 修正:
- 问题 13: evidence 正则用负向先行断言排除 active/archived/templates/README.md
- 问题 14: 豁免清单加 .ai-memory/spec-context/
- 问题 15: lessons 正则用负向先行断言排除 archived-early/
"""

FORBIDDEN_PATTERNS = [
    # P0 旧路径
    r'docs/general/',
    r'docs/superpowers/',
    r'docs/governance/',
    r'docs/specs/dependency-graph\.md',
    # P1 旧路径 (§8.1 问题 13/15 修正: 负向先行断言)
    r'\.ai-memory/evidence/(?!active/|archived/|templates/|README\.md)[^/]+/',
    r'\.ai-memory/lessons/(?!archived-early/)[^/]+\d{4}-\d{2}-\d{2}-n\d+',
    # P2 旧路径
    r'\.ai-memory/tech-stack\.md',
    r'\.ai-memory/version-compat\.md',
    r'\.ai-memory/data-flow\.md',
    r'\.ai-memory/cli-cheatsheet\.md',
    r'\.ai-memory/session-context\.md',
    r'\.ai-memory/spec-index\.md',
    r'\.ai-memory/doc-health-report-schema\.md',
]
```

**特殊豁免**（白名单，§8.1 问题 14 修正）：
- `.git/` — 历史记录不可改
- `.ai-memory/spec-context/` — 上下文承载体目录（本次新建）
- `.ai-memory/lessons/archived-early/` — 6 个早期归档文件保留原名
- `.ai-memory/evidence/archived/` — 归档 evidence 保留原名
- `.ai-memory/evidence/active/` — 活跃 evidence
- `.ai-memory/evidence/templates/` — evidence 模板

#### 引用更新清单（P0/P1/P2 全量）

**P0 阶段需更新的引用**（约 50+ 处）：

| 引用文件 | 旧引用 | 新引用 |
|---------|--------|--------|
| `.trae/rules/project_rules.md` §0 | `docs/general/analysis/GAF-optimal-solution.md` | `docs/architecture/optimal-solution.md` |
| `.trae/rules/project_rules.md` §0 | `docs/general/design/gaf-features-overview.md` | `docs/architecture/features-overview.md` |
| `.trae/rules/project_rules.md` §0 | `docs/general/design/architecture-overview.md` | `docs/architecture/overview.md` |
| `.trae/skills/gaf-orchestrator/SKILL.md` | `docs/general/specs/dependency-graph.md` | `docs/specs/dependency-graph.md` |
| `.ai-memory/meta/docs-index.md` | 全部 36 条 `docs/general/...` | 全部更新为新路径 |
| `.ai-memory/meta/ai-operating-handbook.md` | `docs/general/standards/` | `docs/standards/`（保持顶层） |
| `.ai-memory/evidence/2026-07-25-logging-pipeline-hardening-spec/solution.md` | `docs/superpowers/specs/...` | `docs/specs/active/...` |

**P1 阶段需更新的引用**（约 30+ 处）：

| 引用文件 | 旧引用 | 新引用 |
|---------|--------|--------|
| `.ai-memory/meta/failure-modes.md` | `lessons/platform-env_2026-07-25-n188-...md` | `lessons/N188-conda-env-not-enforced.md` |
| `.ai-memory/meta/archived-lessons.md` | 旧文件名 | 新文件名 |
| `.ai-memory/lessons/README.md` | 旧文件名 | 新文件名 + next_n_id 计数器 |
| `.ai-memory/meta/yn-matrices/_*.md` | 旧 lesson 引用 | 新 lesson 引用 |

**P2 阶段需更新的引用**（约 20+ 处）：

| 引用文件 | 旧引用 | 新引用 |
|---------|--------|--------|
| `.trae/rules/project_rules.md` §1.1 | `.ai-memory/tech-stack.md` | `.ai-memory/ref/tech-stack.md` |
| `.trae/skills/gaf-orchestrator/SKILL.md` | `.ai-memory/cli-cheatsheet.md` | `.ai-memory/ref/cli-cheatsheet.md` |
| `.ai-memory/meta/ai-operating-handbook.md` Part 1 | `.ai-memory/data-flow.md` | `.ai-memory/ref/data-flow.md` |
| `.ai-memory/README.md` §0.1 | 根目录 6 文件 | `ref/` 下 6 文件 |

#### 脚本辅助更新

```bash
conda run -n gaf python scripts/migrate_docs_paths.py --stage p0 --dry-run
conda run -n gaf python scripts/migrate_docs_paths.py --stage p0 --apply
```

**用户确认**：§7 没问题（已确认，含 §8.1 问题 13-15 修正）

---

### §8 — 规格自检 + 风险评估

#### 8.1 自检发现的 15 个问题（已回写到对应章节）

| # | 章节 | 问题 | 修正 |
|---|------|------|------|
| 1 | §2 | `data-flow.md` 标注"如有"，实际可能不存在 | P0 启动时先 `ls docs/general/design/` 实测，不存在就不迁移 |
| 2 | §2 | `pipeline-authoring-guide.md` 和 `custom-task-design.md` 都映射到 `pipeline-design.md` | P0 实测两份文档内容，重叠则合并，否则分别命名 |
| 3 | §2 | `business/ops/health-checks/` 和 `docs/health/` 内容来源重复 | `general/health-checks/` 全部移到 `docs/health/`，`business/ops/` 下不建 health-checks 子目录 |
| 4 | §2 | 空目录占位 git 不追踪 | 每个空目录加 `.gitkeep` 文件 |
| 5 | §2 | `general/specs/README.md` 归属未明确 | 内容合并到新 `docs/specs/README.md`（spec 编写规范） |
| 6 | §3 | `doc-health-report-schema.md` 结构图与决策矛盾 | 移到 `.ai-memory/ref/doc-health-report-schema.md` |
| 7 | §3 | evidence/active/ 目录命名规则未明确 | 统一为 `<YYYY-MM-DD>-<topic>/` |
| 8 | §3 | N 编号分配机制在 P1 实施中如何分配新编号 | P1 第一步创建 `lessons/README.md` 含 `next_n_id`，初始值 = 现有最大 N 编号 + 1（实测） |
| 9 | §4 | `daily_self_evolution_task` 异步任务调 LLM 不可控 | 改为 AI 会话内触发（SKILL.md 规则），异步任务只标记 pending_promotion |
| 10 | §4 | "升级为规则走 AskUserQuestion" 异步任务无用户交互 | 异步任务标记 `pending_rule_promotion`，下次 AI 会话由 AI 检查并询问用户 |
| 11 | §4 | "AI 任务收尾时扫" 缺明确触发点 | `gaf-orchestrator` SKILL.md 任务收尾检查清单加一项 |
| 12 | §5 | `scripts/start_backend.py` 是否存在未确认 | P2 启动前先 `ls scripts/` 实测，不存在则改 `backend/manage.py` 加启动钩子 |
| 13 | §7 | `evidence/[^/]+/` 正则误匹配 active/archived | 改为负向先行断言 `evidence/(?!active/|archived/|templates/|README\.md)[^/]+/` |
| 14 | §7 | 豁免清单缺 `.ai-memory/spec-context/` | 豁免清单加 `.ai-memory/spec-context/` |
| 15 | §7 | `lessons/archived-early/` 被正则命中 | 正则改为 `lessons/(?!archived-early/)[^/]+\d{4}-\d{2}-\d{2}-n\d+` |

#### 8.2 风险评估（含 §5 修正后的新风险）

| 等级 | 风险 | 缓解措施 |
|------|------|---------|
| **高** | 批量 git mv 引用断裂（50+ 文档移动，100+ 引用更新） | P0/P1/P2 每阶段跑 `migrate_docs_paths.py --dry-run` 先看影响面；pre-commit hook 兜底 |
| **高** | lessons 改名导致 failure-modes.md 索引失效（60+ 链接） | P1 改名脚本和 failure-modes.md 更新脚本同 commit；改名后立即 grep 验证 0 失效链接 |
| **中** | GAF 启动时跑 cleanup 可能让启动变慢（§5 修正后新风险） | startup_checks 异步跑（threading.Thread daemon=True），不阻塞 Django ready |
| **中** | AI 会话启动扫 pending_promotion 可能让首次响应变慢（§5 修正后新风险） | 限制扫描范围（只扫 evidence/active/ 目录名），< 1 秒完成 |
| **中** | frontmatter 不一致（60+ lessons 逐个加 topic/n_id） | 写脚本 `migrate_lessons_frontmatter.py` 批量加，从原文件名解析 topic 和 n_id |
| **中** | sync_docs_index.py 重构 bug 影响所有 AI 加载 | P0 改完后立即跑 `sync_docs_index.py` + 人工抽查 5 份 docs-index.md 条目 |
| **中** | pre-commit hook 误报（正则命中合法引用） | §8.1 问题 13-15 修正正则；hook 加白名单文件 `.doc-path-whitelist.txt` |
| **低** | 空目录 .gitkeep 容易忘 | §8.1 问题 4 已修正，P0 改动列表加一项"每个空目录加 .gitkeep" |
| **低** | P0 commit 粒度大触发 B2 证据检查 | P0 实施时按 N151 流程生成 B2 证据，`scripts/check_big_change.py --staged --acknowledge` |

#### 8.3 验证策略

**P0 验证**：
```bash
# 1. 文件数对比（迁移前后总数一致）
conda run -n gaf python -c "import os; print(sum(1 for _ in os.walk('docs') for f in _[2] if f.endswith('.md')))"

# 2. git mv 历史保留
git log --follow docs/architecture/overview.md

# 3. sync_docs_index 无报错
conda run -n gaf python scripts/bootstrap/sync_docs_index.py

# 4. 旧路径零残留
grep -rn "docs/general/\|docs/superpowers/\|docs/governance/" . --include="*.md" --include="*.py" --include="*.yaml" | grep -v "^\.git/" | grep -v "spec-context/"

# 5. 抽查 5 份 docs-index.md 条目 module 字段
grep "module:" .ai-memory/meta/docs-index.md | head -5
```

**P1 验证**：
```bash
# 1. lessons 改名完成
ls .ai-memory/lessons/N*.md | wc -l  # 应 ≥ 60

# 2. evidence active/archived 结构
ls .ai-memory/evidence/active/
ls .ai-memory/evidence/archived/

# 3. failure-modes.md 链接无失效
grep -oP '\[N\d+\]\(lessons/[^)]+\)' .ai-memory/meta/failure-modes.md | while read link; do
  path=$(echo "$link" | grep -oP 'lessons/[^)]+')
  [ -f ".ai-memory/meta/$path" ] || echo "BROKEN: $link"
done

# 4. 单元测试
conda run -n gaf python -m pytest backend/gaf_core/tests/test_self_evolution.py -v

# 5. dry-run
conda run -n gaf python manage.py run_startup_checks --all --dry-run
```

**P2 验证**：
```bash
# 1. 根目录收敛
find .ai-memory -maxdepth 1 -name "*.md"  # 应只 README.md

# 2. pre-commit hook
pre-commit run check-doc-path-drift --all-files
pre-commit run check-doc-sync --all-files

# 3. 旧路径零残留（含 .ai-memory 根目录文件）
grep -rn "\.ai-memory/tech-stack\.md\|\.ai-memory/data-flow\.md\|\.ai-memory/cli-cheatsheet\.md" . --include="*.md" --include="*.py" | grep -v "^\.git/" | grep -v "spec-context/"

# 4. 全量回归
conda run -n gaf python -m pytest backend/ -x
conda run -n gaf python -m pytest agent/tests/ -x
```

#### 8.4 实施前必做的实测确认

P0 启动前先跑实测脚本，确认假设成立：

```bash
# 1. 确认 docs/general/design/ 实际文件清单
ls docs/general/design/

# 2. 确认 data-flow.md 是否存在
test -f docs/general/design/data-flow.md && echo "EXISTS" || echo "NOT EXISTS"

# 3. 确认 scripts/start_backend.py 是否存在
ls scripts/ | grep -i start

# 4. 确认现有 lessons 最大 N 编号
ls .ai-memory/lessons/ | grep -oP 'n\d+' | sort -V | tail -1

# 5. 确认 evidence 目录数量
find .ai-memory/evidence -maxdepth 1 -type d | wc -l

# 6. 确认 sync_docs_index.py 现状
test -f scripts/bootstrap/sync_docs_index.py && echo "EXISTS" || echo "NOT EXISTS"
```

#### 8.5 规格完整性自检

| 检查项 | 状态 |
|--------|------|
| 目标明确（§1） | ✅ |
| 目标结构完整（§2 §3） | ✅（§8.1 问题 1-8 修正后） |
| 自我进化闭环设计（§4） | ✅（§8.1 问题 9-11 + §5 修正后） |
| 运行机制明确（§5） | ✅（§8.1 问题 12 + 用户决策 19 修正后） |
| 迁移阶段划分（§6） | ✅ |
| 旧路径处理（§7） | ✅（§8.1 问题 13-15 修正后） |
| 文档同步机制（§9） | ✅（用户决策 18 修正后） |
| 风险识别 + 缓解（§8.2） | ✅ |
| 验证策略（§8.3） | ✅ |
| 实施前实测确认（§8.4） | ✅ |
| 上下文承载体（spec-context） | ✅ |

**用户确认**：§8 没问题（已确认）

---

### §9 — 文档与代码同步更新机制

**用户决策 18**："希望更新对应业务或者架构时，ai能同步更新文档，别之后访问文档又是过时的"

**用户决策 19/20**：定时执行不可行（IDE 开发模式），改为对话访问文档时即时检查。

#### 9.1 文档与代码的映射

docs/ 下每份文档 frontmatter 新增字段：

```yaml
---
maintainer: ai
applies_to_code_paths:              # ★ 该文档适用的代码路径 glob
  - backend/tasks/**
  - agent/src/nodes/tasks/**
  - frontend/src/views/tasks/**
doc_last_updated: 2026-07-25        # ★ 文档最近更新日期 (AI 改文档时手动更新, hook 强制)
---
```

**module → 代码路径映射表**（`docs-index.md` 维护，sync 脚本自动生成）：

| module | applies_to_code_paths |
|--------|----------------------|
| `business.tasks` | `backend/tasks/**` + `agent/src/nodes/tasks/**` + `frontend/src/views/tasks/**` |
| `business.devices` | `backend/agents/**` + `agent/src/platforms/**` |
| `business.resources` | `backend/resources/**` |
| `business.accounts` | `backend/accounts/**` |
| `business.ops` | `backend/monitors/**` + `backend/notifications/**` |
| `business.ai` | `backend/gaf_ai/**` + `backend/skills/**` |
| `architecture.backend` | `backend/config/**` + `backend/gaf_core/**` |
| `architecture.agent` | `agent/src/**` |
| `architecture.frontend` | `frontend/src/**` |
| `architecture.cross-cutting` | `backend/protocol/**` + `backend/tracing/**` |

#### 9.2 任务收尾时同步检查

在 `gaf-orchestrator` SKILL.md 的"任务收尾检查清单"加一项：

```
□ 扫描本次 git diff --name-only 涉及的代码路径
□ 反查 docs-index.md 找到对应文档（通过 applies_to_code_paths 匹配）
□ 检查文档内容是否需要更新:
   - 新增/删除字段 → 更新数据模型章节
   - 改接口签名 → 更新 API 章节
   - 改流程 → 更新流程图/时序图
□ 通过 AskUserQuestion 询问用户是否需要更新文档
□ 用户确认后 → AI 更新文档 + 更新 doc_last_updated 字段
□ 用户拒绝 → 标记 sync_status: drifted（下次加载时提醒）
```

**关键约束**：AI 不能自作主张改文档，必须经用户确认（避免乱改）。

#### 9.3 pre-commit hook 强制

新增 `check_doc_sync.py`（与 `check_doc_path_drift.py` 互补）：

```python
# .pre-commit-hooks/check_doc_sync.py
"""spec §9.3 — 检查代码改动是否伴随文档更新.

行为:
- 代码改动但文档没动 → 警告不阻塞 (避免误报)
- 代码和文档都改了但 doc_last_updated 没更新 → 阻塞 (强制更新 frontmatter)
"""
```

**Hook 行为分级**：
- **警告不阻塞**：代码改动但文档没动 → 打印警告 + 记录到 `.doc-sync-warnings.log`
- **强制阻塞**：代码和文档都改了，但文档的 `doc_last_updated` 字段没更新 → 阻塞 commit

#### 9.4 AI 访问文档时即时检查（用户决策 19/20 修正后）

**删除**：原设计的 `check_doc_staleness` Celery 定时任务（IDE 开发模式不可行）

**改为**：AI 会话内实时计算，不依赖后台进程

```
当 AI 通过 docs-index.md 查询文档时:
1. 读文档 frontmatter 的 applies_to_code_paths
2. 调用 git log -1 --format="%ci" -- <code_paths> 查代码最近改动日期
3. 比对 code_last_changed vs doc_last_updated
4. code_last_changed > doc_last_updated → 标记 stale, 加载时附提醒
5. 检查结果在会话内缓存（不持久化到 docs-index.md）
```

**实现位置**：`gaf-orchestrator` SKILL.md 加规则，AI 用 RunCommand 跑 git log（每次访问文档时一次，成本可接受）。

#### 9.5 AI 加载 stale 文档时的提醒

`gaf-orchestrator` SKILL.md 加规则：

```
当 AI 通过 docs-index.md 查询文档时:
- sync_status: fresh → 正常加载
- sync_status: stale → 加载时附提醒 "此文档可能过时, 代码最近改动于 <date>, 请交叉验证"
- sync_status: drifted → 加载时附提醒 "此文档与代码不同步, 用户曾拒绝更新, 内容可能不准"
```

#### 9.6 frontmatter 字段维护责任（修正后）

| 字段 | 维护方 | 何时更新 |
|------|--------|---------|
| `applies_to_code_paths` | `sync_docs_index.py` 自动生成 | P0 重构时初始化 + 新增文档时 |
| `doc_last_updated` | AI 改文档时手动更新（hook 强制） | 每次文档内容变更 |
| `code_last_changed` | **不存储**，AI 访问时实时查 git log | — |
| `sync_status` | **不存储**，AI 访问时实时计算 | — |

**简化**：docs-index.md 只存 `applies_to_code_paths` + `doc_last_updated`，`code_last_changed` 和 `sync_status` 运行时计算，避免缓存失效问题。

#### 9.7 与 §4 自我进化的关系

| 维度 | §4 自我进化 | §9 文档同步 |
|------|------------|-------------|
| 处理对象 | `.ai-memory/` 过程产物 | `docs/` 稳定知识库 |
| 触发时机 | AI 会话启动 + GAF 启动 | 代码改动 + 用户确认 + AI 访问文档时实时检查 |
| 自动化程度 | AI 会话内触发沉淀 | 用户确认后 AI 改文档；AI 访问时实时检查 stale |
| 失败兜底 | 月度遗忘清理（GAF 启动时跑） | stale 标记 + 加载提醒 |

#### 9.8 风险与缓解

| 风险 | 缓解 |
|------|------|
| 误报（改了代码但文档不需要更新） | Hook 只警告不阻塞；AI 收尾走 AskUserQuestion |
| `applies_to_code_paths` 配置不全 | P0 初始覆盖主要 app；漏的靠 stale 检测兜底；新增 Django app 时强制配 |
| 文档频繁改动影响 git history | 只更新 `doc_last_updated` 字段即可，不必大改文档 |
| AI 自作主张乱改文档 | 必须经 AskUserQuestion 用户确认 |
| stale 检测漏报（代码路径未配） | docs-index.md 加 `applies_to_code_paths: []` 标记未配文档，定期人工补 |

#### 9.9 落地阶段

§9 不单独成阶段，融入 P0/P2：

| 阶段 | §9 落地点 |
|------|----------|
| P0 | `sync_docs_index.py` 加 `applies_to_code_paths` 字段生成；docs-index.md 加 `doc_last_updated` 字段 |
| P1 | 无需改动（§9 不涉及 lessons/evidence） |
| P2 | 新增 `check_doc_sync.py` pre-commit hook；更新 `gaf-orchestrator` SKILL.md 加任务收尾检查项 + stale 加载提醒规则 |

**用户确认**：§9 没问题（已确认，含用户决策 19/20 修正）

---

### §10 — 与现有 AI 工作流/规则文档/思维链对齐检查

#### 10.1 对齐问题清单（16 个，已修正）

| # | 对齐对象 | 问题 | 修正 |
|---|---------|------|------|
| 1 | orchestrator SKILL.md L2 hard-load | tech-stack.md 移到 ref/ 但 SKILL.md 引用根目录 | P2 同步更新 SKILL.md L2 hard-load hooks 段 |
| 2 | orchestrator SKILL.md L3 按需加载 | version-compat.md 移到 ref/ 但 SKILL.md 引用根目录 | P2 同步更新 SKILL.md L3 按需加载段 |
| 3 | README.md §0.1 加载顺序表 | data-flow.md 移到 ref/ 但 README 引用根目录 | P2 同步更新 README.md §0.1 |
| 4 | evidence/_templates/ 命名 | spec §3 写 templates/，实际是 _templates/ | spec 全部改为 _templates/ |
| 5 | lessons/README.md frontmatter schema | spec 加 maintainer/source/load_when 字段未对齐 | P1 更新 lessons/README.md schema 表格 |
| 6 | lessons/README.md frontmatter schema | spec 加 topic 字段未在 schema 表格 | P1 更新 lessons/README.md 加 topic 字段 |
| 7 | failure-modes.md §Active/§Dormant 段 | spec 加 status 字段与现有段位置语义重叠 | 不新增 status，复用 §Active/§Dormant 段位置 |
| 8 | gaf_init.sh 步骤 4.5 grep | trigger_count/last_triggered 是否影响 grep | 加在表格右侧，第一列 N## 不变，grep 不受影响 |
| 9 | orchestrator §0.5 spec-42 patch | §4 和 §0.5 都在对话开头触发，关系未明 | §0.5 先 patch 文档健康，§4 后扫 pending_promotion |
| 10 | docs-index.md applies_to 字段 | spec 用 applies_to_code_paths 与现有 applies_to 重名 | 两个字段不同都保留：applies_to=任务类型, applies_to_code_paths=代码路径 |
| 11 | orchestrator step_6_verify | §9.2 加任务收尾检查清单与 step_6 关系未明 | 扩展现有 step_6，不新增 step |
| 12 | Django AppConfig.ready() 限制 | ready() 不允许跑重活 | 改为 management command + 启动脚本显式调用（推荐） |
| 13 | evidence/_templates/ 命名 | spec §7 正则豁免写 templates/ | 改为 _templates/ |
| 14 | general/specs/README.md "人工维护" | P0 未提修正过时描述 | 合并到新 docs/specs/README.md 时自动修正 |
| 15 | README.md §3 目录结构缺 session/ | 已有不一致 | 不在本次范围，记录为已知问题 |
| 16 | README.md §5 gaf-commit.sh wrapper | 与 orchestrator 闭环步骤 6 不一致 | 已有不一致，不在本次范围 |

#### 10.2 修正后的关键设计决策

1. **`ref/` 移动需同步更新 5 处引用**：orchestrator SKILL.md 3 段 + README.md §0.1 + handbook Part 1
2. **`evidence/templates/` 全部改为 `evidence/_templates/`**（保持现有命名）
3. **failure-modes.md 不新增 `status` 字段**，复用现有 §Active/§Dormant 段位置
4. **`trigger_count` + `last_triggered` 加在 §Active 段表格右侧**，gaf_init.sh grep 不受影响
5. **§4 与 §0.5 互补**：§0.5 先 patch 文档健康，§4 后扫 pending_promotion
6. **`applies_to_code_paths` 是新字段**，与现有 `applies_to` 不同，两个字段都保留
7. **§9.2 扩展现有 step_6_verify_before_commit**，不新增 step
8. **§5 startup_checks 推荐用 management command + 启动脚本显式调用**，不在 ready() 里自动跑
9. **P1 更新 lessons/README.md frontmatter schema 表格**，加 `topic` 字段

#### 10.3 spec §5 修正 — startup_checks 触发方式

**原设计**：AppConfig.ready() 触发 daemon thread

**修正后**（推荐）：Django management command + 启动脚本显式调用

```python
# backend/gaf_core/management/commands/run_startup_checks.py
class Command(BaseCommand):
    def add_arguments(self, parser):
        parser.add_argument('--dry-run', action='store_true')
        parser.add_argument('--all', action='store_true')
    
    def handle(self, *args, **options):
        from gaf_core.startup_checks import run_startup_checks
        run_startup_checks(dry_run=options['dry_run'])
```

**触发方式**（二选一，由用户决定）：

**方案 A**（推荐）：启动脚本显式调用
```bash
# scripts/start_gaf.sh (或等价物)
conda run -n gaf python manage.py run_startup_checks --all  # 启动时跑一次
conda run -n gaf python manage.py runserver                  # 然后启动 Django
```

**方案 B**：AppConfig.ready() 触发 daemon thread（轻量场景）
```python
# backend/gaf_core/apps.py
class GafCoreConfig(AppConfig):
    name = 'gaf_core'
    
    def ready(self):
        """GAF 启动时异步跑一次检查 (spec §5, 轻量场景)."""
        import threading
        from gaf_core.startup_checks import run_startup_checks_safe
        threading.Thread(target=run_startup_checks_safe, daemon=True).start()
```

`run_startup_checks_safe` 加 try/except 兜底，失败只 log 不阻塞启动。

**用户确认**：§10 没问题（已确认，要求第二轮对齐检查）

---

### §11 — 第二轮深度对齐检查（流程一致性）

#### 11.1-11.7 流程对比发现 10 个问题

| # | 流程阶段 | 问题 | 修正 |
|---|---------|------|------|
| 1 | AI 会话启动 | §4 和 §0.5 顺序未明 | §4 写入 SKILL.md §0.5 之后 |
| 2 | AI 会话启动 | §9.4 触发点散落 | §9.4 明确是任务执行中触发，不是开头 |
| 3 | 任务执行 | §9.4 step_2 接入点未明 | §9.4 接入 step_2_read_context |
| 4 | 任务执行 | §4 与 step_5 关系未明 | §4 扩展 step_5_evolve |
| 5 | 任务收尾 | §9.2 step_6 接入点未明 | §9.2 接入 step_6_verify_before_commit |
| 6 | GAF 启动 | §5 startup_checks 触发方式两可 | §5 选定方案 A（启动脚本显式调用） |
| 7 | 文档加载 | README.md §0.1 加载顺序未更新 | P2 更新加载顺序表 ref/ 路径 |
| 8 | 文档加载 | evidence 加载路径未更新 | §4 明确扫 active/ 还是 archived/ |
| 9 | 沉淀闭环 | N 编号分配机制冲突 | §4 明确迁移路径：手动 → next_n_id 字段 |
| 10 | 遗忘机制 | §Retired/§Dormant 关系未明 | §4 cold = 移到 §Dormant 段 |

#### 11.9 修正后的统一流程

```
═══ GAF 启动阶段 ═══
1. Django ready()
2. 启动脚本显式调用 run_startup_checks --all (方案 A)
   - cleanup_old_archives_once (删 30 天前 tar.gz)
   - cleanup_old_evidence_once (移 30 天前 active → archived)
   - forgetting_check_once (§Active last_triggered < 6 月 → §Dormant)
3. Django runserver 启动

═══ AI 会话启动阶段 ═══
1. L1 hard-load: failure-modes.md N## 索引 (§Active 段)
2. L2 hard-load: ai-operating-handbook.md + docs-index.md
3. §0.5 spec-42 patch (P0/P1 文档健康)
4. §4 扫 evidence/active/ pending_promotion (新增, §0.5 之后)
   - 同 topic ≥ 2 → 标记 pending_promotion
   - AI 在当前会话内处理 (写 lesson + 更新 failure-modes + 移 evidence)

═══ 任务执行阶段 ═══
1. step_1 task_type 判定
2. step_2 read_context (L3 按需加载 docs/)
   - §9.4 实时查 git log 检查 stale (新增)
   - sync_status: stale → 加载时附提醒
3. step_3 execute
4. step_4 reflect
5. step_5 evolve (沉淀 lesson)
   - §4 触发点 1: 扫 evidence/active/ 同 topic ≥ 2 (新增, 扩展 step_5)
   - 写 lessons/N<编号>-<slug>.md (N 编号从 lessons/README.md next_n_id 取)
   - 更新 failure-modes.md §Active 段 (加 trigger_count + last_triggered)
   - 移 evidence 到 archived/

═══ 任务收尾阶段 ═══
1. step_6 verify_before_commit
   - 测试通过
   - §9.2 文档同步检查 (新增, 扩展 step_6)
     - 扫 git diff --name-only 涉及的代码路径
     - 反查 docs-index.md 找对应文档
     - 通过 AskUserQuestion 询问用户是否更新文档
   - commit
```

**用户确认**：§11 没问题（已确认，要求继续循环对齐检查）

---

### §12 — 第三轮深度对齐检查（内部一致性 + 实施细节 + 边界场景）

#### 12.1 实地验证发现（5 个新问题，已修正）

| # | 检查项 | 实际情况 | 承载体原文 | 修正 |
|---|--------|---------|-----------|------|
| 1 | evidence 模板目录命名 | `templates/`（无下划线） | §3 写 `templates/` ✓；但 §10.1 #4/#13、§10.2 #2 写"改为 `_templates/`" ✗ | 删除 §10.1 #4/#13、§10.2 #2 中"改为 `_templates/`"的修正，保持 §3 的 `templates/`（无下划线）。spec 正式版统一用 `templates/` |
| 2 | failure-modes.md §Active 表格格式 | 4 列：`N## / 主题 / 硬约束 / Lesson 链接` | §4 设计 7 列（含 status） | spec 正式版明确：表格 = 6 列 `N## / 主题 / 硬约束 / Lesson 链接 / trigger_count / last_triggered`，不加 status 列（复用 §Active/§Dormant 段位置表达 hot/cold） |
| 3 | orchestrator SKILL.md 闭环步骤命名 | 1.开工 / 2.判定 / 3.加载 / 4.搜索(L3硬约束) / 5.执行 / 6.提交 | §11.9 用 `step_2_read_context` / `step_5_evolve` / `step_6_verify_before_commit` ✗ | spec 正式版 §11.9 改用实际步骤命名（开工/判定/加载/搜索/执行/提交） |
| 4 | lessons/README.md frontmatter schema 与 .ai-memory/README.md §1.1 不一致 | lessons/README.md 没有 maintainer/source/load_when 字段；多了 date/n_id/level/cross_refs/merged_n_ids/l2_candidate | §3 frontmatter 示例同时包含两套字段 | spec 正式版明确：P1 改名时以 lessons/README.md 现有 schema 为基础，只加 `topic` 字段；不强制加 maintainer/source/load_when（lessons/README.md 没有这些字段） |
| 5 | lessons/ 中无 N 编号文件（如 `circular_mode_no_continue_prompt.md`） | 实际存在，不在 archived-early/ | §7 豁免清单只提 archived-early/ | spec 正式版明确：P1 改名时此类无 N 编号文件一并迁移到 `archived-early/`（保留历史，不参与 sync 索引） |

#### 12.2 §4 遗忘机制段修正（与 §11.1 #10 一致）

**原 §4 §遗忘机制段**：
> - cold N## 移到 archived-lessons.md (不再 L1 硬加载)

**修正后**：
> - cold N## 移到 `failure-modes.md §Dormant` 段（不再 L1 硬加载 grep Active 段，但保留在 §Dormant 段供按需查询）
> - 仅当 dormant 超过 6 个月 + 无新复发 + 无 Y/N 矩阵引用 → 才移到 `archived-lessons.md`（deprecated 档，与 failure-modes.md §归档流程一致）

#### 12.3 spec 文档自身位置的阶段冲突

**冲突**：承载体待办要创建 `docs/specs/active/2026-07-25-docs-ai-memory-restructure.md`，但 `docs/specs/active/` 是 P0 阶段才新建的目录。

**修正**：spec 文档创建在 P0 实施之前（即"准备阶段"），但放置路径选择：

- **方案 A**（推荐）：先手动建 `docs/specs/active/` 目录（mkdir + .gitkeep），spec 文档直接放新路径。P0 阶段此目录已存在，迁移其他 spec 时直接合并即可。
- 方案 B：spec 文档先放 `docs/general/specs/`（旧路径），P0 阶段迁移到 `docs/specs/active/`。但这会让 spec 文档短暂存在于即将被删除的目录。

**采用方案 A**：spec 文档直接放 `docs/specs/active/2026-07-25-docs-ai-memory-restructure.md`，P0 第 0 步先建 `docs/specs/active/` 目录。

#### 12.4 spec 正式版章节最终结构

基于 §1-§11 + §12 修正，spec 正式版章节结构：

1. **§1 设计目标与原则**（来自 §1）
2. **§2 docs/ 目标结构**（来自 §2）
3. **§3 .ai-memory/ 目标结构**（来自 §3 + §12.1 #4 修正：lessons frontmatter 用 lessons/README.md 现有 schema + 加 topic 字段）
4. **§4 AI 自我进化沉淀闭环**（来自 §4 + §12.2 修正：cold → §Dormant 段）
5. **§5 启动钩子 + AI 会话内触发**（来自 §5 + §10.3 方案 A）
6. **§6 迁移阶段划分**（来自 §6 + §12.3 修正：P0 第 0 步先建 docs/specs/active/）
7. **§7 旧路径零兼容**（来自 §7 + §12.1 #1 修正：templates/ 无下划线 + §12.1 #5 修正：archived-early/ 含无 N 编号文件）
8. **§8 风险评估 + 验证策略**（来自 §8）
9. **§9 文档与代码同步更新机制**（来自 §9）
10. **§10 与现有 AI 工作流对齐**（来自 §10.2 关键设计决策汇总 + §11.9 统一流程图，用实际步骤命名）

#### 12.5 第三轮检查结论

经第三轮深度检查，承载体文档已具备创建正式 spec 的全部条件：

- ✅ 用户决策 20 条全部记录
- ✅ §1-§9 设计章节全部用户确认
- ✅ §10 第一轮对齐 16 个问题已修正
- ✅ §11 第二轮对齐 10 个问题已修正
- ✅ §12 第三轮深度检查 5 个新问题已修正
- ✅ 实地验证 5 处（evidence/templates/、failure-modes.md §Active、orchestrator 闭环步骤、lessons/README.md schema、无 N 编号文件）
- ✅ 统一流程图（用实际步骤命名）

**无第四轮检查必要** — 第三轮发现的问题已全部内联修正，可直接创建正式 spec。

**用户确认**：§12 没问题（待用户确认后创建正式 spec）

---

### §13 — 第四轮实地验证 + spec 自检

**触发**：用户要求"继续对比，循环，直到没问题，文档写好才能开始计划"

#### 13.1 实地验证发现的 4 个新问题（已修正 spec）

| # | 检查项 | 实际情况 | spec 原文 | 修正 |
|---|--------|---------|-----------|------|
| 1 | hooks 目录位置 | `scripts/hooks/` | spec §7.3 写 `.pre-commit-hooks/` | spec 改为 `scripts/hooks/check_doc_path_drift.py` + 说明加入 `gaf_governance_batch.py` CHECKS 列表第 13 项 |
| 2 | 现有 `check_doc_code_sync.py` | 已实现 spec §9.3 设计的功能 (TD-325/spec-87, 7 条规则 + hard/warn/info 三级 + `[skip-doc-sync]` 跳过 + double-verification) | spec §9.3 写"新增 `check_doc_sync.py`" | spec 改为"扩展现有 `check_doc_code_sync.py` + `doc_sync_rules.py`"：加 R8 规则 (doc_last_updated 强制) + P0 后更新 R3/R7 路径 + 主逻辑加 doc_last_updated 字段检查 |
| 3 | 现有 `check_path_consistency.py` (N107) | 检查 inline path 构造 (`Path("foo") / "bar.json"`) | spec §7 未说明与现有 hook 关系 | spec §7.3 加说明：两者职责区分不合并，都加入 governance batch |
| 4 | lessons 无 N 编号文件 | 实际有 `circular_mode_no_continue_prompt.md` + `workflow_spec_concentration_2026-07-20.md` 两个 | spec §6.2 只提 `circular_mode_no_continue_prompt.md` | spec §6.2 加规则"所有无 N 编号文件一并迁移到 archived-early/"，列出全部已知文件 |

#### 13.2 gaf_init.sh grep 模式实测

```bash
# scripts/gaf_init.sh L160:
N_COUNT=$(grep -cE "^\| N[0-9]+" .ai-memory/meta/failure-modes.md 2>/dev/null || echo 0)
```

**确认**：grep 模式 `^\| N[0-9]+` 匹配行首 `| N` 后跟数字。spec §3.4 加 `trigger_count` + `last_triggered` 在表格右侧（第 5/6 列），第一列 N## 不变，grep 不受影响。✓

#### 13.3 现有 governance batch 架构实测

`scripts/hooks/gaf_governance_batch.py` 已合并 12 个检查为 1 个 hook (N171 优化后 ~1.5s)：
1. check_session_active.py
2. sync_ai_memory.py
3. check_3step_evidence.py
4. check_lessons_updated.py
5. check_spec_consistency.py
6. sync_skills.py --check
7. promote_lessons.py --dry-run
8. sync_docs_index.py --check
9. check_path_consistency.py
10. check_yn_matrices_index.py
11. sync_spec_index.py --check
12. check_doc_code_sync.py

**spec 影响**：
- `check_doc_path_drift.py` 加入第 13 项
- `check_doc_code_sync.py` (第 12 项) 扩展，不新增 hook
- `.pre-commit-config.yaml` 无需改动（已合并到 `gaf-governance-batch`）

#### 13.4 spec §10.1 关键设计决策更新

第四轮新增 4 条决策（12-15）：
- 12: hooks 目录在 `scripts/hooks/`，加入 governance batch
- 13: 不新建 `check_doc_sync.py`，扩展 `check_doc_code_sync.py`
- 14: `check_path_consistency.py` 与 `check_doc_path_drift.py` 职责区分不合并
- 15: `scripts/` 下无 `start_backend.py`，P2 新建 `scripts/start_gaf.sh`

#### 13.5 第四轮检查结论

经第四轮实地验证 + spec 自检，spec 文档已具备创建 plan 的全部条件：

- ✅ §1-§9 设计章节全部用户确认
- ✅ §10/§11/§12 三轮对齐检查 31 个问题已修正
- ✅ §13 第四轮实地验证 4 个新问题已修正
- ✅ gaf_init.sh grep 模式实测确认不受影响
- ✅ governance batch 架构实测确认扩展方案可行
- ✅ spec frontmatter `applies_to_code_paths` 字段已列出全部受影响代码路径（含 `scripts/hooks/`）
- ✅ spec §10.3 表格已加入 `doc_sync_rules.py` / `check_doc_code_sync.py` / `gaf_governance_batch.py` / `check_doc_path_drift.py` / `start_gaf.sh` 5 个新条目

**下一步**：进入第五轮深度对齐检查。

---

### §14 — 第五轮深度对齐检查（spec 内部一致性 + 实施细节）

**触发**：用户要求"继续对比，循环，直到没问题，文档写好才能开始计划"

#### 14.1 第五轮发现的 7 个新问题（已修正 spec）

| # | 检查项 | 实际情况 | spec 原文 | 修正 |
|---|--------|---------|-----------|------|
| 1 | spec §3.3 标题混淆 | 标题"lessons frontmatter schema"容易与 `lessons/README.md` 文件本身的 frontmatter 混淆 | spec §3.3 标题 | 改为"lesson 文件 frontmatter schema" + 加注意说明（lesson 文件 vs lessons/README.md 文件本身的 frontmatter） |
| 2 | spec §3.4 示例表格"主题"列 | 实际 failure-modes.md §Active 表格"主题"列写详细描述（如"conda gaf 环境规则多次未生效"） | spec §3.4 示例用 topic 字段值（如 `platform-env`） | 改为用实际表格内容（详细描述），加说明"与实际 failure-modes.md 表格风格一致" |
| 3 | spec §3.4 grep 模式 | 实际 gaf_init.sh 用 `^\| N[0-9]+`（转义 \| 和 + 量词） | spec §3.4 写 `^| N[0-9]`（未转义） | 改为 `^\| N[0-9]+` + 加说明"含转义的 \\| 和 + 量词" |
| 4 | spec §10.2 步骤 5 引用错误 | spec §4.2 触发点 1 是"AI 会话启动时"，不是任务执行时 | spec §10.2 步骤 5 写"§4 触发点 1: 扫 evidence/active/ 同 topic ≥ 2" | 改为"§4.1 沉淀闭环步骤 ② 模式识别" + 在 §4.2 新增触发点 3（任务执行时沉淀触发） |
| 5 | spec §9.3 R8 规则缺 status_filter | R8 规则没有 status_filter，会对 A/D/R 也触发（新建/删除/重命名不需要更新 doc_last_updated） | spec §9.3 扩展点 1 R8 规则无 status_filter | 加 `status_filter="M"` + 加说明"只对 modified 触发" |
| 6 | spec §9.1 映射表不完整 | module → 代码路径映射表缺 workspace / game-profile / system / desktop 4 个模块 | spec §9.1 映射表只列 10 个模块 | 补全 14 个模块 + 加"空数组 [] 标记暂无对应代码路径"说明 |
| 7 | spec §9.1 frontmatter 有 maintainer 字段但 §6.1/§9.6 未提及 | §9.1 frontmatter 有 `maintainer: ai`，但 §6.1 第 13/14 项和 §9.6 维护责任表未提及 | spec §6.1 第 13 项只提 module/applies_to_code_paths；§9.6 表格无 maintainer 行 | §6.1 第 13 项加"加 maintainer: ai 字段初始化"；§9.6 表格加 maintainer 行 |

#### 14.2 spec §4.2 触发机制扩展

第五轮在 §4.2 新增触发点 3（任务执行时沉淀触发），与 §10.2 步骤 5 对齐：

- **触发点 1**（AI 会话启动时）：处理历史遗留 pending_promotion
- **触发点 2**（GAF 启动时）：cleanup + forgetting
- **触发点 3**（任务执行时，新增）：处理本次任务产生的新 evidence，与触发点 1 互补

#### 14.3 spec §10.1 关键设计决策更新

第五轮新增 5 条决策（16-20）：
- 16: §3.3 标题改为"lesson 文件 frontmatter schema"
- 17: §3.4 示例表格"主题"列用实际表格内容
- 18: §4.2 新增触发点 3（任务执行时沉淀触发）
- 19: §9.3 R8 规则加 status_filter="M"
- 20: §9.1 映射表补全 4 个缺失模块

#### 14.4 第五轮检查结论

经第五轮深度对齐检查，spec 文档已修正 7 个新问题：

- ✅ §3.3 标题混淆已修正（加注意说明区分 lesson 文件 vs lessons/README.md）
- ✅ §3.4 示例表格"主题"列已改用实际表格内容
- ✅ §3.4 grep 模式已改为 `^\| N[0-9]+`（含转义）
- ✅ §4.2 新增触发点 3，与 §10.2 步骤 5 对齐
- ✅ §9.3 R8 规则加 status_filter="M"
- ✅ §9.1 映射表补全 14 个模块（含空数组标记）
- ✅ §9.6 维护责任表加 maintainer 行
- ✅ §6.1 第 13 项加 maintainer 字段初始化
- ✅ §10.1 决策更新为 20 条
- ✅ §10.3 表格 SKILL.md 行描述更新
- ✅ §5.1 运行模型 §4 引用更新
- ✅ §6.2 P1 阶段第 11/12 项引用更新

**下一步**：通知用户审查 spec 文档，批准后创建 plan。

---

### §15 — 第六轮深度对齐检查（failure-modes.md 实地验证 + spec 内部一致性）

**触发**：用户要求"继续对比，循环，直到没问题，文档写好才能开始计划"

#### 15.1 实地验证发现的 11 个新问题（已修正 spec）

| # | 检查项 | 实际情况 | spec 原文 | 修正 |
|---|--------|---------|-----------|------|
| 1 | failure-modes.md §Dormant 段语义 | §Dormant 是"家族合并子条目"专用（如 N107/N110/N114 合并到 N105） | spec §4.1 步骤 ⑤ 写"§Active N## last_triggered > 6 月 → 移到 §Dormant" | spec §4.1 步骤 ⑤ 改为"§Active N## last_triggered > 6 月 + 无 Y/N 矩阵引用 → 移到 archived-lessons.md (deprecated 档)" + 加注释说明 §Dormant 是家族合并子条目专用 |
| 2 | N## 四档分布 | Active / Dormant (家族合并子条目) / Archived (deprecated, archived-lessons.md) / Retired (M0.M 闭环, §Retired 段) | spec §4.1 步骤 ⑤ 没明确四档 | spec §4.1 步骤 ⑤ 加注释说明 N## 四档分布 |
| 3 | spec §4.5 风险与缓解表 "lesson 膨胀"行 | cold 移 archived-lessons.md，不是 §Dormant | spec §4.5 写"遗忘机制 + cold 移 §Dormant 段" | 改为"遗忘机制 + cold 移 archived-lessons.md (deprecated 档); §Active N## > 70 触发 N181 紧急评估 (spec-62)" |
| 4 | spec §5.2 forgetting_check_once 描述 | 应实现 "Active → Archived" 而非 "Active → Dormant" | spec §5.2 写"§Active last_triggered > 6 月 → 移 §Dormant" | 改为"§Active last_triggered > 6 月 + 无 Y/N 矩阵引用 → 移 archived-lessons.md (deprecated 档)" + 加注释说明 §Dormant 段语义 |
| 5 | spec §5.1 运行模型 forgetting_check 描述 | 同上 | spec §5.1 写"§Active last_triggered > 6 月 → §Dormant" | 改为"§Active last_triggered > 6 月 + 无 Y/N 矩阵引用 → archived-lessons.md deprecated" |
| 6 | spec §10.2 GAF 启动阶段 forgetting_check 描述 | 同上 | spec §10.2 写"forgetting_check_once (§Active last_triggered > 6 月 → §Dormant)" | 改为"forgetting_check_once (§Active last_triggered > 6 月 + 无 Y/N 矩阵引用 → archived-lessons.md deprecated)" |
| 7 | spec §4.4 升级路径缺 Retired 路径 | failure-modes.md 现有归档流程含 "Active → 退役(retired)" (M0.M 闭环) | spec §4.4 升级路径只到"规则 (硬约束)"，没提 Retired | spec §4.4 标题改为"升级路径（lesson → Y/N 矩阵 → 规则 → 退役）" + 加一条"硬约束已沉淀到 rules/skills (M0.M 闭环) → 移到 §Retired 段（编号永不复用，详见 N181 退役机制）" |
| 8 | spec §6.2 第 4 项缺 P5 治本约束说明 | failure-modes.md frontmatter 有 p5_max_lines: 170 行限制 | spec §6.2 第 4 项没提及 p5_max_lines | 加注"P5 治本约束：加列不加行，p5_max_lines (当前 170) 不受影响；每行长度增加 ~30 字符" + 加"现有 N## 四档分布实测"说明 |
| 9 | spec §6.2 第 8 项缺现有计数字段说明 | lessons/README.md frontmatter 现有 5 个计数字段 (lessons_count / active_n_count / retired_n_count / archived_n_count / dormant_n_count) | spec §6.2 第 8 项只说"加 next_n_id 计数器字段" | 加注"与现有 5 个计数字段并存，不替换" |
| 10 | spec §6.2 第 2 项缺 archived-early/ 现状 | archived-early/ 下已有 6 个早期归档文件，本次再迁入 2 个无 N 编号文件 | spec §6.2 第 2 项只提"如 circular_mode_no_continue_prompt.md" | 改为明确列出 2 个无 N 编号文件 + 加注"archived-early/ 下已有 6 个早期归档文件，本次再迁入 2 个" |
| 11 | N## 最大编号实测 | lessons/ 实际文件 platform-env_2026-07-25-n188-conda-env-not-enforced.md，最大 N188 | spec §4.3 / §6.2 写 next_n_id 初始值 N189 (基于 N188 + 1) | 实测确认 spec 描述正确 ✓ (N188 是最大值，N189 是 next_n_id 初始值) |

#### 15.2 §Dormant 段语义误解详细说明（最严重错误）

**错误根因**：spec 设计时假设 §Dormant 是"Active 超时未触发"的归宿，但实际 failure-modes.md §Dormant 段是"家族合并子条目"专用。

**实际 failure-modes.md §Dormant 段内容**（10 行覆盖 15 个 N## 编号）：
- N107/N110/N114 → 合并到 N105 (commit 透传 bug 早期变体)
- N113/N115/N127 → 合并到 N109 (AI 决策自决早期变体)
- N119 → 合并到 N111 (命令挂起)
- N128/N130 → 合并到 N126 (文档诚实标记早期变体)
- N147 → 合并到 N156 (测试先于理解早期变体)
- N153 → 合并到 N150 (pre-commit stash 早期变体)
- N155 → 合并到 N154 (黑屏 agent storm 早期变体)
- N162 → 合并到 N160 (上下文预算早期变体)
- N163 → 合并到 N161 (自决不推卸早期变体)
- N169 → 合并到 N166 (TD 延后语义早期变体)

**正确归档流程**（来自 failure-modes.md §归档流程）：
1. **dormant → 归档(deprecated)**: dormant (家族合并子条目) 超过 6 个月 + 无新复发 + 无 Y/N 矩阵引用
2. **Active → 退役(retired)**: M0.M 闭环 (硬约束已沉淀到 rules/skills, 不再需要独立索引)
3. **Active → 归档(deprecated)**: 近 30 天无触发 + 无 Y/N 矩阵引用 (罕见场景)

**spec 修正影响范围**（5 处）：
- §4.1 步骤 ⑤ 遗忘机制段
- §4.5 风险与缓解表 "lesson 膨胀" 行
- §5.1 运行模型 forgetting_check 描述
- §5.2 实现要点 forgetting_check_once docstring
- §10.2 GAF 启动阶段 forgetting_check 描述

#### 15.3 spec §10.1 关键设计决策更新

第六轮新增 9 条决策（21-29）：
- 21: §Dormant 段语义误解（最严重错误，5 处修正）
- 22: N## 四档分布明确（Active / Dormant 家族合并子条目 / Archived deprecated / Retired M0.M 闭环）
- 23: §4.4 升级路径补充 Retired 路径
- 24: §6.2 第 4 项加 P5 治本约束说明
- 25: §6.2 第 8 项加现有计数字段说明
- 26: §6.2 第 2 项明确 archived-early/ 现状
- 27: N## 最大编号是 N188（实测确认）
- 28: failure-modes.md §Active 表格列标题是"硬约束 (1 行)"（实测确认）
- 29: gaf_init.sh grep 模式 `^\| N[0-9]+`（实测确认）

#### 15.4 第六轮检查结论

经第六轮深度对齐检查，spec 文档已修正 11 个新问题：

- ✅ §Dormant 段语义误解已修正（5 处：§4.1 / §4.5 / §5.1 / §5.2 / §10.2）
- ✅ N## 四档分布已明确（Active / Dormant 家族合并 / Archived deprecated / Retired M0.M 闭环）
- ✅ §4.4 升级路径已补充 Retired 路径
- ✅ §6.2 第 4 项已加 P5 治本约束说明 + N## 四档分布实测
- ✅ §6.2 第 8 项已加现有计数字段说明
- ✅ §6.2 第 2 项已明确 archived-early/ 现状
- ✅ N## 最大编号实测确认 N188（next_n_id 初始值 N189 正确）
- ✅ failure-modes.md §Active 表格列标题实测确认与 spec 一致
- ✅ gaf_init.sh grep 模式实测确认与 spec 一致
- ✅ §10.1 决策更新为 29 条
- ✅ 承载体文档待办已更新

**下一步**：通知用户审查 spec 文档，批准后创建 plan。

---

### §16 — 第七轮跨章节一致性验证（spec 内部一致性 + 实施细节 + 边界场景）

**触发**：用户要求"继续对比，循环，直到没问题，文档写好才能开始计划"

#### 16.1 第七轮发现的 6 个新问题（已修正 spec）

| # | 检查项 | 实际情况 | spec 原文 | 修正 |
|---|--------|---------|-----------|------|
| 1 | §4.2 触发点 2 forgetting_check_once 描述 | 第六轮修正漏掉 §4.2，仍写"移到 §Dormant 段" | spec §4.2 第 356 行 "→ 移到 §Dormant 段" | 改为 "→ archived-lessons.md (deprecated 档)" + 加注释说明 §Dormant 段语义 + M0.M 闭环走 §4.4 升级路径 |
| 2 | §4.1 步骤 ⑤ 遗漏机制路径覆盖 | 只描述"超时未触发"路径，未明确 M0.M 闭环 N## 走 §4.4 升级路径 | spec §4.1 步骤 ⑤ 无 M0.M 闭环说明 | 加注释 "本步骤只处理超时未触发的 Active N##; M0.M 闭环 N## 走 §4.4 升级路径 (→ §Retired 段), 不走遗忘机制" |
| 3 | §7.5 P2 阶段引用更新清单不完整 | 漏掉 5 处源代码硬编码引用（sync_session_context.py / sync_spec_index.py / check_spec_id_collision.py / spec_dependency_graph.py / scripts/README.md） | spec §7.5 P2 阶段只列 6 个根目录文件的文档引用 | 补 5 行源代码硬编码引用更新 + 加说明"dependency-graph.md 由 sync_spec_index.py 自动生成，重跑即可" |
| 4 | §4.1 步骤 ⑤ + §5.2 cleanup_old_evidence 函数名冲突 + 功能描述错位 | §4.1 写"evidence/archived/ > 90 天 → 删除 (cleanup_old_evidence)"，但 §5.2 的 cleanup_old_evidence_once 实现的是"active > 30 天 → 移 archived"，函数名冲突 + 功能描述错位 | spec §4.1 步骤 ⑤ + §5.2 不一致 | §4.1 步骤 ⑤ 拆分为两行（cleanup_old_evidence_once 处理 active→archived，delete_archived_evidence_once 处理 archived>90 天删除），§5.2 加新函数 delete_archived_evidence_once + run_startup_checks 调用顺序更新 + §4.2 触发点 2 + §5.1 运行模型 + §10.2 GAF 启动阶段 + §6.2 第 9 项同步更新 |
| 5 | §4.3 文件锁路径 typo | `%.cache/lessons_n_id.lock` 是 typo，应为 `.cache/lessons_n_id.lock` | spec §4.3 第 389 行 | 改为 `.cache/lessons_n_id.lock` + 加注"相对仓库根的 .cache/ 目录" |
| 6 | §5.2 cleanup_old_evidence_once docstring 引用错误 + §3.4 示例说明不准确 | docstring 引用 §4.5（风险表），实际定义在 §4.1 步骤 ⑤；§3.4 示例称"与实际保持一致"但实际是简化版 | spec §5.2 docstring + §3.4 示例说明 | docstring 改为 "(spec §4.1 步骤 ⑤)"；§3.4 示例说明改为"简化版，P1 实施时以实际 failure-modes.md 表格风格为准" |

#### 16.2 §10.1 决策清单更新

第七轮新增 6 条决策（30-35）：
- 30: §4.2 触发点 2 描述遗漏修正（第六轮修正盲点）
- 31: §4.1 步骤 ⑤ 加 M0.M 闭环路径说明（明确两条路径区分）
- 32: §7.5 P2 阶段引用更新清单补 5 处源代码硬编码引用
- 33: §4.1 步骤 ⑤ + §5.2 cleanup_old_evidence 函数名冲突 + 功能描述错位修正（4 个清理函数在 §4.1/§4.2/§5.1/§5.2/§10.2 五处一致）
- 34: §4.3 文件锁路径 typo 修正
- 35: §5.2 cleanup_old_evidence_once docstring 引用错误 + §3.4 示例说明不准确修正

#### 16.3 §10.3 文档关系表更新

第七轮新增 8 行：
- `backend/gaf_core/startup_checks.py` (P1 新建)
- `backend/gaf_core/management/commands/run_startup_checks.py` (P1 新建)
- `backend/gaf_core/tests/test_self_evolution.py` (P1 新建)
- `scripts/bootstrap/sync_session_context.py` (P2 改硬编码路径)
- `scripts/governance/sync_spec_index.py` (P2 改硬编码路径)
- `scripts/hooks/check_spec_id_collision.py` (P2 改错误消息)
- `scripts/governance/spec_dependency_graph.py` (P2 改生成内容)
- `scripts/README.md` (P2 改脚本说明)

#### 16.4 第七轮检查结论

经第七轮跨章节一致性验证，spec 文档已修正 6 个新问题：

- ✅ §4.2 触发点 2 描述已修正（与 §10.2 一致）
- ✅ §4.1 步骤 ⑤ 加 M0.M 闭环路径说明（与 §4.4 升级路径对齐）
- ✅ §7.5 P2 阶段引用更新清单补 5 处源代码硬编码引用
- ✅ §4.1 + §5.2 cleanup_old_evidence 函数名冲突已修正（4 个清理函数在 5 处一致）
- ✅ §4.3 文件锁路径 typo 已修正
- ✅ §5.2 docstring 引用错误 + §3.4 示例说明不准确已修正
- ✅ §10.1 决策更新为 35 条
- ✅ §10.3 文档关系表新增 8 行（P1 新建 3 + P2 改 5）
- ✅ §6.2 第 9 项更新为"4 个清理函数"（与 §5.2 一致）

**跨章节一致性验证通过**：
- §4.1 / §4.2 / §5.1 / §5.2 / §10.2 五处描述 4 个清理函数完全一致 ✓
- §4.4 升级路径与 §4.1 遗忘机制路径区分明确（升级 vs 遗忘）✓
- §9.1 映射表 14 个 module 与 §2.1 目录结构（9 业务 + 5 架构）一致 ✓
- §9.2 / §9.3 / §9.4 / §9.5 与 §10.2 执行流程对齐 ✓
- §7.5 引用更新清单与 §10.3 文档关系表 P 阶段一致 ✓
- 附录 B 与 §8.3 实测确认清单一致 ✓

**下一步**：第八轮最终验收检查（重点验证 §10.1 决策 28 与 §3.4 注释的关系）。

---

### §17 — 第八轮最终验收检查（spec 内部逻辑自洽性 + 全文跨章节补检）

**触发**：用户要求"继续对比，循环，直到没问题，文档写好才能开始计划"

#### 17.1 第八轮发现的 1 个新问题（已修正 spec）

| # | 检查项 | 实际情况 | spec 原文 | 修正 |
|---|--------|---------|-----------|------|
| 1 | §10.1 决策 28 与 §3.4 注释表面冲突 | 决策 28 称"spec §3.4 示例与实际一致 ✓"易让人误以为示例**内容**也一致；但 §3.4 注释已说明示例内容是简化版（只展示列结构） | spec §10.1 决策 28 "spec §3.4 示例与实际一致 ✓" | 决策 28 改为 "spec §3.4 示例**列标题**与实际一致 ✓（注意：仅列标题一致，示例表格的'主题'和'硬约束'**内容**是简化版，详见 §3.4 注释）" |

#### 17.2 第八轮跨章节一致性补检结果

第八轮针对第七轮修正后的 spec 进行最终验收，对以下 13 个关键检查项做全文 grep + 人工核对：

| # | 检查维度 | 验证方法 | 结果 |
|---|---------|---------|------|
| 1 | §Dormant 段语义一致性 | grep `§Dormant` 全文 9 处提及 | ✅ 全部一致：家族合并子条目专用，forgetting_check_once 不写入 §Dormant |
| 2 | 清理函数名一致性 | grep 4 个清理函数 + run_startup_checks 全文 46 处提及 | ✅ 全部一致：cleanup_old_evidence_once / delete_archived_evidence_once / forgetting_check_once / cleanup_old_archives_once / run_startup_checks |
| 3 | §4.1 步骤 ⑤ 描述 | 人工读取 §4.1 步骤 ⑤ 完整内容 | ✅ 4 行拆分清晰 + ★ 三段注释（§Dormant 段语义 + N## 四档 + M0.M 闭环路径区分）|
| 4 | §4.2 触发点 2 描述 | 人工读取 §4.2 触发点 2 完整内容 | ✅ 4 个清理函数 + §Dormant 段说明 + M0.M 闭环说明与 §4.1 一致 |
| 5 | §5.2 docstring 引用 | 人工读取 §5.2 4 个函数 docstring | ✅ cleanup_old_evidence_once docstring 引用 (spec §4.1 步骤 ⑤) 正确；delete_archived_evidence_once 与 forgetting_check_once 注释清晰 |
| 6 | §10.2 统一执行流程 | 人工读取 §10.2 GAF 启动阶段 4 个清理函数调用顺序 | ✅ 与 §5.2 run_startup_checks 调用顺序一致 |
| 7 | archived-lessons.md 全文一致性 | grep 全文 15 处提及 | ✅ 全部指向"deprecated 档"，与 §Dormant 段明确区分 |
| 8 | §3.4 注释 vs §10.1 决策 28 关系 | 人工对比两处描述 | ✅ 第八轮修正后决策 28 明确"列标题一致 ≠ 内容一致"，与 §3.4 注释逻辑自洽 |
| 9 | §6.2 计数字段 + P5 治本约束 | 人工读取 §6.2 第 4/8 项 | ✅ p5_max_lines: 170 + 5 个现有计数字段 + next_n_id 与现有字段并存 |
| 10 | §7.5 P2 引用清单完整性 | 人工读取 §7.5 P2 阶段表格 | ✅ 5 处文档引用 + 5 处源代码硬编码引用（10 行）完整 |
| 11 | §9 文档同步机制 | 人工读取 §9.1-§9.9 | ✅ maintainer/applies_to_code_paths/doc_last_updated 字段 + R8 规则 status_filter="M" + §9.4 实时 git log 检查 + §9.6 维护责任表完整 |
| 12 | §10.1 决策清单完整性 | 人工读取 §10.1 全部 35 条决策 | ✅ 35 条决策完整覆盖七轮修正 + 第八轮决策 28 描述修正 |
| 13 | §10.3 现有文档关系表 | 人工读取 §10.3 全部 19 行 | ✅ 覆盖所有受影响脚本（含 P0/P1/P2 阶段标记） |

#### 17.3 第八轮检查结论

经第八轮最终验收检查，spec 文档已修正 1 个新问题（决策 28 描述）+ 13 项跨章节一致性补检全部通过：

- ✅ §10.1 决策 28 描述已修正（明确"列标题一致 ≠ 内容一致"，与 §3.4 注释逻辑自洽）
- ✅ §Dormant 段语义在全文 9 处提及一致
- ✅ 4 个清理函数名在全文 46 处提及一致
- ✅ archived-lessons.md 在全文 15 处提及全部指向"deprecated 档"
- ✅ §4.1 / §4.2 / §5.1 / §5.2 / §10.2 五处描述 4 个清理函数完全一致
- ✅ §4.4 升级路径与 §4.1 遗忘机制路径区分明确
- ✅ §9.1 映射表 14 个 module 与 §2.1 目录结构（9 业务 + 5 架构）一致
- ✅ §9.2 / §9.3 / §9.4 / §9.5 与 §10.2 执行流程对齐
- ✅ §7.5 引用更新清单与 §10.3 文档关系表 P 阶段一致
- ✅ 附录 A/B/C 完整

**spec 文档已通过 8 轮对齐检查 + 跨章节一致性补检**：
- §10 第一轮对齐检查
- §11 第二轮深度对齐检查
- §12 第三轮深度对齐检查
- §13 第四轮实地验证 + spec 自检
- §14 第五轮深度对齐检查
- §15 第六轮 failure-modes.md 实地验证
- §16 第七轮跨章节一致性验证
- §17 第八轮最终验收检查（本次）

**累计修正点**：8 轮共修正 50 个问题（决策 1-35 + 第一至四轮实测验证）

**下一步**：通知用户审查 spec 文档，批准后创建 plan。

---

### §18 — 第九轮深度对比验证（spec 引用元素实地验证 + 跨章节深层补检）

**触发**：用户要求"继续对比，循环，直到没问题，文档写好才能开始计划"

#### 18.1 第九轮发现的 2 个新问题（已修正 spec）

| # | 检查项 | 实际情况 | spec 原文 | 修正 |
|---|--------|---------|-----------|------|
| 1 | forgetting_check_once 跨章节不一致（§Dormant 超时处理范围） | §4.1 步骤 ⑤ 列出 §Active + §Dormant 两类超时处理规则，但 §4.2 触发点 2 / §5.1 / §5.2 docstring / §10.2 GAF 启动阶段四处只描述 §Active 超时，与 §4.1 矛盾；§4.1 步骤 ⑤ 注释"本步骤只处理'超时未触发'的 Active N##"自身也矛盾 | spec §4.1/§4.2/§5.1/§5.2/§10.2 五处描述不统一 | 五处描述统一为"forgetting_check_once 处理两类超时（§Active + §Dormant）→ archived-lessons.md deprecated"；§4.1 注释改为"forgetting_check_once 处理两类超时"明确语义；§4.2 注释改为"forgetting_check_once 不会把 §Active 超时 N## 写入 §Dormant（直接进 archived-lessons.md）；但会处理 §Dormant 段已存在的子条目超时"消除歧义；新增 §10.1 决策 36/37 记录 |
| 2 | project_rules.md §1.1 → §6.1 引用错误 | spec 决策 1 / §6.3 改动范围 / §7.5 P2 引用清单 / §10.3 关系表四处都说"project_rules.md §1.1 引用 tech-stack.md"，实测 §1.1 是"服务启停"段未引用 tech-stack.md，实际引用在 §6.1 L659 | spec 四处 §1.1 描述错误 | 四处 §1.1 → §6.1 (L659)；新增 §10.1 决策 38 记录 |

#### 18.2 第九轮 spec 引用元素实地验证（17 项清单，subagent 验证）

| # | 验证项 | 结果 |
|---|--------|------|
| 1 | SKILL.md §0.5 spec-42 patch + 闭环步骤 1-6 + L2/L3 引用 | ✅ 全部一致（L45-83/L289-297/L326-336） |
| 2 | project_rules.md §0 三份核心文档 + §3.4 spec 粒度 commit | ✅ 一致；⚠ §1.1 tech-stack 引用错误（实际在 §6.1 L659）→ 已修正 |
| 3 | failure-modes.md §Active 表格 4 列 + §Dormant + §Retired + §归档流程 + p5_max_lines: 170 | ✅ 全部一致（L15/L25/L50/L125/L140） |
| 4 | lessons/README.md 5 个计数字段 + 11 字段 schema + 文件名格式 | ✅ 全部一致（L14-21/L222-236） |
| 5 | archived-lessons.md 存在 | ✅ 存在 |
| 6 | .ai-memory/README.md §0.1/§3/§5/§1.1 manual 8 必填字段 | ✅ 全部一致（L36-55/L65-69/L130-159/L195-221） |
| 7 | ai-operating-handbook.md Part 1 L2/L3 段 | ✅ 存在（L9/L33/L42） |
| 8 | check_doc_code_sync.py 引用 doc_sync_rules + [skip-doc-sync] | ✅ 全部一致（L70/L74/L209-212/L323-324/L404-405） |
| 9 | doc_sync_rules.py R3/R7 规则存在 | ✅ 全部一致（R3 L83-91/R7 L118-125） |
| 10 | gaf_governance_batch.py CHECKS 列表 12 项 | ✅ 一致（L83-96/L163） |
| 11 | sync_session_context.py L44 硬编码 | ✅ 一致（L44: `OUTPUT_FILE = AI_MEMORY / "session-context.md"`） |
| 12 | sync_spec_index.py L47/L215 硬编码 | ✅ 一致（L47 + L215） |
| 13 | check_spec_id_collision.py L167 引用 | ✅ 一致（L167） |
| 14 | spec_dependency_graph.py L396 引用 | ✅ 一致（L396） |
| 15 | scripts/README.md L64 引用 | ✅ 一致（L64） |
| 16 | scripts/start_backend.py / start_gaf.sh 不存在 | ✅ 确认不存在（P2 实施时新建 start_gaf.sh 前提成立）→ 新增决策 39 记录 |
| 17 | .ai-memory/spec-context/ 目录已存在 | ✅ 已存在（含 1 个文件） |

#### 18.3 第九轮检查结论

经第九轮深度对比验证，spec 文档已修正 2 个新问题 + 17 项引用元素实地验证全部通过：

- ✅ forgetting_check_once 跨章节不一致已修正（§4.1/§4.2/§5.1/§5.2/§10.2 五处描述统一）
- ✅ project_rules.md §1.1 → §6.1 引用错误已修正（四处同步更新）
- ✅ spec 引用的 17 项元素全部实地验证存在且一致
- ✅ §10.1 决策清单从 35 条扩展到 39 条（新增决策 36/37/38/39）

**累计修正点（第九轮末）**：9 轮共修正 52 个问题（决策 1-39 + 第一至四轮实测验证 + 第九轮 17 项引用元素验证）

**下一步**：第十轮补检（详见 §19）。

---

### §19 — 第十轮最终一致性补检（spec 内部一致性 + 引用元素行号实地复核）

**触发**：用户要求"继续对比，循环，直到没问题，文档写好才能开始计划"

#### 19.1 第十轮发现的 2 个新问题（已修正 spec）

| # | 检查项 | 实际情况 | spec 原文 | 修正 |
|---|--------|---------|-----------|------|
| 1 | check_spec_id_collision.py 行号错误（L167 → L166） | spec §7.5/§10.1 决策 1/§10.1 决策 32/§10.3 四处均称 `check_spec_id_collision.py L167` 引用 `.ai-memory/spec-index.md`，但实际引用在 L166（`print("   - 或用下一个空闲 spec-NN (查 .ai-memory/spec-index.md 找空闲号)", file=sys.stderr)`），L167 是另一条消息"历史 spec-36/38/... 同号多版本 wontfix (TD-322)"与 spec-index.md 引用无关 | spec 四处行号错误 | 四处 L167 → L166（§7.5 P2 引用清单表 L772 + §10.1 决策 1 第 5 处源代码引用 L1083 + §10.1 决策 32 L1114 + §10.3 关系表 L1192） |
| 2 | §10.1 轮次计数漏更新（八轮→九轮） | 第九轮修正了 forgetting_check_once 一致性 + project_rules.md §1.1→§6.1，但 §10.1 引言 L1079 + 决策 1 L1082 + 决策 36 L1118 + 决策 37 L1119 + 决策 38 L1120 + 决策 39 L1121 共 6 处仍标"第八轮"，未同步更新为"第九轮"；第八轮实际是"决策 28 描述修正 + 13 项跨章节一致性补检"（详见 §17） | spec 6 处轮次计数标签滞后 | L1079 引言改"经八轮...第八轮 forgetting_check_once 一致性 + project_rules.md §6.1 实测修正"为"经九轮...第八轮 13 项跨章节一致性补检 + 第九轮 forgetting_check_once 一致性 + project_rules.md §6.1 实测修正"；决策 1/36/37/38/39 五处"第八轮"→"第九轮" |

#### 19.2 第十轮跨章节一致性补检结果（7 项全部通过）

第十轮针对第九轮修正后的 spec 做最终一致性补检，对以下 7 个关键检查项做 grep + 人工核对：

| # | 检查维度 | 验证方法 | 结果 |
|---|---------|---------|------|
| 1 | forgetting_check_once 五处描述一致性 | grep + 人工比对 §4.1 步骤 ⑤ + §4.2 触发点 2 + §5.1 运行模型图 + §5.2 docstring + §10.2 GAF 启动阶段 | ✅ 全部统一为"处理两类超时（§Active + §Dormant）→ archived-lessons.md deprecated"；§4.2 L373 澄清注释已更新为"forgetting_check_once 不会把 §Active 超时 N## 写入 §Dormant（直接进 archived-lessons.md）；但 forgetting_check_once **会**处理 §Dormant 段已存在的子条目超时"消除歧义 |
| 2 | project_rules.md §6.1 (L659) 四处引用一致性 | grep `§1.1` 全文 + 人工比对 §6.3/§7.5/§10.1 决策 1/§10.3 | ✅ 四处全部统一为 §6.1 (L659)；§1.1 残留 4 处均为合法引用（`.ai-memory/README.md §1.1 manual 模式`不同文档 + 决策描述中作为"修正前→修正后"的历史记录） |
| 3 | §10.1 决策 36/37/38/39 正文落地情况 | 人工核对决策与正文对应章节 | ✅ 全部落地：决策 36 → §4.1/§4.2 两类超时描述；决策 37 → 决策 22 交叉引用注释；决策 38 → 四处 §6.1 修正；决策 39 → §5.2/§8.3/§10.3 一致描述 |
| 4 | §5.2 函数清单与 §4.1 步骤 ⑤ 对齐 + 调用顺序一致性 | 人工比对 §5.1/§5.2/§10.2 三处调用顺序 | ✅ 4 函数（cleanup_old_archives_once / cleanup_old_evidence_once / delete_archived_evidence_once / forgetting_check_once）调用顺序三处完全一致 |
| 5 | §3.4 failure-modes.md §Active 表格 6 列描述 | 人工比对 §3.4 + §6.2 第 4 项 | ✅ 两处描述完全一致：加 trigger_count + last_triggered 两列，不加 status 列，列数 4 → 6 |
| 6 | §4.4 升级路径完整性 | 人工读取 §4.4 升级路径图 | ✅ 四阶段完整（evidence → lesson → Y/N 矩阵 → 规则）+ Retired 路径明确画出 + "编号永不复用"在 4 处提及 |
| 7 | §7.4 白名单与 §3.1 目录树一致性 | 人工比对 §7.4 + §3.1 | ✅ 5 项白名单（evidence/active/+archived/+templates/ + lessons/archived-early/ + spec-context/）全部一致；evidence/templates/ 三处均明确"无下划线" |

#### 19.3 第十轮 spec 引用元素实地复核（10 项，9 项通过 + 1 项修正）

第十轮对 spec §7.5 P2 阶段引用更新清单中 5 处源代码硬编码引用 + 5 项关键结构做实地复核：

| # | 验证项 | 结果 |
|---|--------|------|
| 1 | sync_session_context.py L44 硬编码 `AI_MEMORY / "session-context.md"` | ✅ 一致（L44 完全匹配） |
| 2 | sync_spec_index.py L47 + L215 硬编码 `repo_root / ".ai-memory" / "spec-index.md"` | ✅ 一致（L47 实际变量名是 `REPO_ROOT_DEFAULT`，路径内容完全一致；L215 完全一致） |
| 3 | check_spec_id_collision.py L167 错误消息引用 `.ai-memory/spec-index.md` | ❌ 不一致 → 已修正为 L166（详见 §19.1 第 1 项） |
| 4 | spec_dependency_graph.py L396 生成内容引用 `.ai-memory/spec-index.md` | ✅ 一致（L396: `lines.append("> 详细清单见 \`.ai-memory/spec-index.md\` ⚠️ 同号多版本冲突段.")`） |
| 5 | scripts/README.md L64 脚本说明引用 `.ai-memory/session-context.md` | ✅ 一致（L64 完全匹配） |
| 6 | project_rules.md §6.1 L659 引用 tech-stack.md | ✅ 一致（L651 标题"### 6.1 L1/L2/L3 加载机制 (硬约束)" + L659 引用 `tech-stack.md`） |
| 7 | gaf_governance_batch.py CHECKS 列表当前 12 项（第 13 项是新增） | ✅ 一致（当前 12 项，spec §7.3 描述"加入第 13 项"准确） |
| 8 | failure-modes.md §Active 表格当前 4 列 | ✅ 一致（L55 表头 4 列 + L56 分隔行 4 列；列名实际为"硬约束 (1 行)"，与 §10.1 决策 28 注明一致） |
| 9 | lessons/README.md 现有 11 字段 schema | ✅ 一致（L224-236 共 11 字段：date/symptom/solution/related_files/created_by/priority/n_id/level/cross_refs/merged_n_ids/l2_candidate） |
| 10 | lessons/README.md 现有 5 个计数字段 | ✅ 一致（L13-21 共 5 个计数字段：lessons_count/active_n_count/retired_n_count/archived_n_count/dormant_n_count） |

#### 19.4 第十轮检查结论

经第十轮最终一致性补检，spec 文档已修正 2 个新问题 + 7 项跨章节一致性补检 + 10 项引用元素实地复核全部通过：

- ✅ check_spec_id_collision.py 行号 L167 → L166 已修正（4 处同步更新）
- ✅ §10.1 轮次计数 八轮→九轮 已修正（6 处同步更新）
- ✅ forgetting_check_once 五处描述完全统一（§4.1/§4.2/§5.1/§5.2/§10.2）
- ✅ project_rules.md §6.1 (L659) 四处引用全部一致
- ✅ §10.1 决策 36/37/38/39 在正文对应章节全部落地
- ✅ 4 函数调用顺序在 §5.1/§5.2/§10.2 三处完全一致
- ✅ §3.4 6 列表格与 §6.2 第 4 项描述一致
- ✅ §4.4 升级路径完整（含 Retired 路径 + "编号永不复用"4 处提及）
- ✅ §7.4 白名单与 §3.1 目录树完全对应
- ✅ 10 项引用元素实地复核 9 项通过 + 1 项已修正

**累计修正点**：10 轮共修正 54 个问题（决策 1-39 + 第一至四轮实测验证 + 第九轮 17 项引用元素验证 + 第十轮 2 项新问题修正）

**下一步**：通知用户审查 spec 文档，批准后创建 plan。

---

## §20 第十一轮 P0 实测修正（2026-07-26）

### 起因

用户批准 spec + plan 后，AI 开始执行 plan §2 "实施前实测确认（P0 启动前跑）"，按 plan §2.1 实测清单逐项核对。

### 实测结果（10 项）

| # | 实测项 | 实测结果 | 与 spec 假设是否一致 |
|---|--------|---------|---------------------|
| 1 | docs/general/design/ 文件清单 | 18 个 .md 文件全部确认 | ✅ 一致 |
| 2 | data-flow.md 存在性 | 不存在 | ✅ 一致（任务 P0-2 序号 18 跳过） |
| 3 | scripts/ 启动脚本 | 无 start_backend.py / start_gaf.sh | ✅ 一致 |
| 4 | lessons 最大 N 编号 | N188（67 个 N 编号 + 2 个无 N 编号 + 1 个 README = 70 个 .md 文件） | ✅ 一致 |
| 5 | evidence 目录数量 | 64 个 evidence 目录 + 1 个 templates/ = 65 个总目录 | ✅ 一致（spec 假设 50+） |
| 6 | sync_docs_index.py 现状 | 存在，v8.4 版本，REQUIRED_FIELDS = ("summary", "applies_to", "last_updated")，需扩展 | ✅ 一致 |
| 7 | business.game-profile 代码路径 | 实测 `backend/gamestate/**`（含 GameProfile 模型/views/serializers/migrations） + `frontend/src/pages/GameProfiles/**`（含 index.tsx/DetailPage.tsx/components/） | ❌ 不一致（spec 假设 `backend/game_profiles/**` + `frontend/src/views/game-profile/**`） |
| 8 | architecture.desktop 代码路径 | `desktop/**` 存在（Electron 应用：src/main + src/preload + package.json + vite.config.ts） | ✅ 一致 |
| 9 | lessons 无 N 编号文件清单 | 2 个：`circular_mode_no_continue_prompt.md` + `workflow_spec_concentration_2026-07-20.md` | ✅ 一致 |
| 10 | archived-early/ 现状 | 6 个 .md 文件（2026-06-10-agent-popup-bug / 2026-06-14-api-404-tasks / 2026-06-14-capability-mismatch / 2026-06-14-message-frame-format / 2026-06-14-pipeline-stuck-running / 2026-06-14-spec-overengineering） | ✅ 一致 |

### 唯一不一致项：§9.1 映射表 business.game-profile 代码路径错误

**根因**：spec 设计时基于"前端侧边栏模块名"猜测代码路径（`backend/game_profiles/` + `frontend/src/views/game-profile/`），未实地核对。

**实际代码路径**：

- 后端：`backend/gamestate/`（app 名 gamestate，但包含 GameProfile 模型/views/serializers/migrations）
  - models.py / views.py / serializers.py / urls.py / admin.py / apps.py
  - migrations/0001_initial.py ~ 0008_gameprofile_device_type_hint.py
  - tests/test_views.py / test_models.py / test_serializer_changes.py / test_game_profile_api.py
- 前端：`frontend/src/pages/GameProfiles/`
  - index.tsx / DetailPage.tsx / options.ts
  - components/BindResourceModal.tsx / DevicesTab.tsx / ResourcePacksTab.tsx / TaskChainsTab.tsx / TasksTab.tsx / AccountsTab.tsx / GameProfileEditorModal.tsx

**修正动作**：

1. ✅ spec §9.1 映射表：`backend/game_profiles/**` + `frontend/src/views/game-profile/**` → `backend/gamestate/**` + `frontend/src/pages/GameProfiles/**`
2. ✅ spec §9.1 后说明文字：加"P0 实测已完成（2026-07-26）"段，说明 business.game-profile 实测路径与原假设不一致已修正，architecture.desktop 实测路径与假设一致
3. ✅ spec §10.1 决策 40：新增第十一轮实测修正记录
4. ✅ plan §1.2 实施前必做清单：标记 §2 实测已完成
5. ✅ plan §2.1 实测清单：10 项全部标记 [x] 完成
6. ✅ plan §2.2 实测结果记录表：填写全部 10 项实测结果
7. ✅ plan §2.3 实测发现的不一致项：新增段落说明 business.game-profile 路径错误根因 + 修正方案 + 额外影响
8. ✅ plan §9 待办清单：标记 §2 实测已完成

**累计修正点**：11 轮共修正 55 个问题（前 10 轮 54 个 + 第十一轮 1 个 business.game-profile 代码路径修正）

**下一步**：实施 P0 阶段（任务 P0-1 ~ P0-18）。

---

## 待办

- [x] §1 设计目标与原则（已确认）
- [x] §2 docs/ 目标结构（已确认）
- [x] §3 .ai-memory/ 目标结构（已确认）
- [x] §4 AI 自我进化沉淀闭环（已确认，含修正）
- [x] §5 启动钩子 + AI 会话内触发（已确认，含修正）
- [x] §6 迁移阶段划分（已确认）
- [x] §7 旧路径零兼容（已确认，含修正）
- [x] §8 规格自检 + 风险评估（已确认）
- [x] §9 文档与代码同步更新机制（已确认，含修正）
- [x] §10 第一轮对齐检查（已确认）
- [x] §11 第二轮深度对齐检查（已确认）
- [x] §12 第三轮深度对齐检查（已确认）
- [x] 创建 spec 文档：`docs/specs/active/2026-07-25-docs-ai-memory-restructure.md`（含规格自检 + 内联修正）
- [x] §13 第四轮实地验证 + spec 自检（hooks 目录、check_doc_code_sync.py、check_path_consistency.py、无 N 编号文件、gaf_init.sh grep 模式）
- [x] §14 第五轮深度对齐检查（§3.3 标题混淆、§3.4 示例表格、grep 模式、§4.2 触发点 3、§9.3 R8 status_filter、§9.1 映射表补全、§9.6 maintainer 字段）
- [x] §15 第六轮深度对齐检查（§Dormant 段语义误解、N## 四档分布、§4.4 升级路径补 Retired、§6.2 P5 治本约束、§6.2 现有计数字段、§6.2 archived-early/ 现状、N## 最大编号 N188、grep 模式实测、§Active 表格列标题实测）
- [x] §16 第七轮跨章节一致性验证（§4.2 触发点 2 遗漏修正、§4.1 M0.M 闭环路径说明、§7.5 P2 源代码硬编码引用补全、cleanup_old_evidence 函数名冲突修正、§4.3 typo、§5.2 docstring 引用错误）
- [x] §17 第八轮最终验收检查（§10.1 决策 28 描述修正 + 13 项跨章节一致性补检全部通过）
- [x] §18 第九轮深度对比验证（forgetting_check_once 跨章节不一致修正 + project_rules.md §1.1→§6.1 修正 + 17 项引用元素实地验证）
- [x] §19 第十轮最终一致性补检（check_spec_id_collision.py L167→L166 修正 + §10.1 轮次计数八轮→九轮修正 + 7 项跨章节一致性补检 + 10 项引用元素实地复核）
- [x] 用户审查 spec 文档（已批准）
- [x] 创建 plan 文档：`docs/plans/2026-07-25-docs-ai-memory-restructure.md`
- [x] §20 第十一轮 P0 实测修正（business.game-profile 代码路径 `backend/gamestate/**` + `frontend/src/pages/GameProfiles/**` 修正）
- [x] §8.3 实施前实测确认（P0 启动前跑，已完成 2026-07-26，10 项中 9 项一致 + 1 项不一致已修正 spec §9.1）
- [ ] 实施 P0：双线索结构 + spec 合并 + §9.1 frontmatter 字段 + doc_sync_rules.py R3/R7 路径更新
- [ ] 实施 P1：lessons 改名 + evidence active/archived + 自我进化 + startup_checks
- [ ] 实施 P2：根目录收敛 + check_doc_path_drift hook + 扩展 check_doc_code_sync.py + SKILL.md 规则更新

---

## 上下文恢复指引（给下一个 AI 会话）

如果你是接手的 AI，请按以下步骤恢复上下文：

1. **读本文件全文** — 包含所有用户决策原文 20 条 + §1-§9 已确认内容（含 §8.1 的 15 个修正项）
2. **读 `.trae/rules/env-hardrules.md`** — L0 系统级硬约束（所有 Python 命令必用 `conda run -n gaf`）
3. **读 `.trae/rules/project_rules.md §0`** — 三份核心文档（最优方案/功能总览/架构总览）的引用路径
4. **读 `.ai-memory/meta/failure-modes.md`** — L1 硬加载的 N## 索引表
5. **下一步动作**：创建正式 spec + plan 文档，然后跑 §8.4 实测确认，再实施 P0

**关键约束**：
- 所有 Python 命令必须用 `conda run -n gaf python ...`
- 旧路径零兼容（§7），不保留任何回退路径
- **无定时任务**（§5 修正后）— 全部改为 GAF 启动时跑一次 + AI 会话内触发
- AI 自我进化沉淀闭环是核心需求（§4），但异步任务不调 LLM，只标记 pending_promotion
- 文档与代码同步是核心需求（§9），AI 访问文档时实时查 git log 检查 stale
- AI 改文档必须经 AskUserQuestion 用户确认，不能自作主张
