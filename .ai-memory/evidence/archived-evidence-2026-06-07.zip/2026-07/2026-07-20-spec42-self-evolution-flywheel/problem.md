---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, problem-step, evidence-problem]
solution: spec-42 problem — spec-41 doc health checker produced report.json but no consumed tracking; same issues reappeared every session, wasting AI context
related_files:
  - scripts/governance/doc_health_consumed.py
  - scripts/governance/doc_health_patch.py
  - .cache/doc_health_consumed.json
created_by: AI
last_updated: 2026-07-20
---
## Problem（症状 / 触发条件）

spec-41 静态层 7 维度文档健康检查器已交付 (`scripts/governance/doc_health_check.py`, commit `ebaa134b`), 每次对话开头 `gaf_init.sh` 跑完产出 `.cache/doc_health_report.json` 含 372 个 issues (P0=308 d4_path_drift + P1=30 + P2=34)。

但 AI 读 report 后无"已处理"标记,导致同一 issue 在每次对话都重新出现,AI 重复分析同一 issue 浪费上下文;且无 patch 验证流程 (C1/C2) + 无 lesson 沉淀触发 (D2/D3) + 无 recurrence 监控 (F2),无法形成"检查器跑 → 发现问题 → AI patch → commit → 下次不再犯"的自我进化飞轮。

触发条件: 用户原话 "完全自动化的自我进化飞轮: 检查器跑 → 发现问题 → AI 分析根因 → AI patch 规则文档 → AI commit → 下次不再犯" + "人工不要干预这个流程"。

影响范围: `.cache/doc_health_report.json` (372 issues) + `scripts/governance/` (新增 consumed + patch 模块) + `.trae/skills/gaf-orchestrator/SKILL.md` (§0.5 段) + `.ai-memory/meta/ai-operating-handbook.md` (AI patch 红线段)。
