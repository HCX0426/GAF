---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, solution-step, evidence-solution]
solution: spec-42 solution — 3 Phase 子代理驱动实施 (consumed 存储 + AI patch 流程 + 闭环验证)
related_files:
  - scripts/governance/doc_health_consumed.py
  - scripts/governance/doc_health_patch.py
  - scripts/governance/report_schema.py
  - scripts/governance/doc_health_check.py
  - .trae/skills/gaf-orchestrator/SKILL.md
  - .ai-memory/meta/ai-operating-handbook.md
  - .trae/specs/2026-07-19-spec42-self-evolution-flywheel-design.md
  - .trae/plans/2026-07-19-spec42-self-evolution-flywheel.md
created_by: AI
last_updated: 2026-07-20
---
## Solution（解决步骤）

按 spec-42 3 Phase 子代理驱动实施 (每 Phase: 1 实施 subagent + 1 审查 search subagent):

1. Phase 1 创建 `scripts/governance/doc_health_consumed.py` 定义 `ConsumedTracker` 类 (9 方法: load/save/is_consumed/mark_consumed/mark_failed/filter_unconsumed/get_recurrence_count/check_d2_lesson_trigger/check_td_escalation, 原子写 `tmp + os.replace`, schema_version=1 优雅降级); 修改 `scripts/governance/report_schema.py` 加 `consumed_count` 字段; 修改 `scripts/governance/doc_health_check.py` main() 延迟 import ConsumedTracker 加载 consumed.json 标记 Issue.consumed; 新增 `scripts/tests/test_doc_health_consumed.py` 15 单元测试 (I/O 5 + Query 5 + Mutation 2 + Integration 3)

2. Phase 2 创建 `scripts/governance/doc_health_patch.py` 定义 `PatchPlanner` (get_patchable_issues 过滤 P0/P1 + unconsumed + max=10, group_by_dimension, check_d3_sediment_trigger) + `PatchVerifier` (rerun_check 用 `conda run -n gaf python scripts/governance/doc_health_check.py --no-fail`, verify_patched, run_relevant_pytest dimension→test_file 映射); 修改 `.trae/skills/gaf-orchestrator/SKILL.md` 插入 §0.5 段 (8 步 AI patch 流程 + 8 条红线, 不破坏 Decision Tree hash); 修改 `.ai-memory/meta/ai-operating-handbook.md` Part 2 末尾追加 "AI patch 红线 (spec-42)" 段; 新增 `scripts/tests/test_doc_health_patch.py` 20 单元测试

3. Phase 3 在 `ConsumedTracker` 加 `check_d2_lesson_trigger` (≥3 distinct issue_id 且 recurrence_count ≥1) + `check_td_escalation` (任意 issue recurrence_count ≥2); 在 `PatchPlanner` 加 `check_d3_sediment_trigger` (patched_files ∩ RULES_FILES); 新增 `scripts/tests/test_doc_health_flywheel.py` 22 集成测试 (D2 5 + D3 5 + F2 4 + C1+C2 闭环 8); 跑 `python scripts/governance/doc_health_check.py --no-fail` 验证主流程 0.846s 通过
