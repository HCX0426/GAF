# spec35 #12 — .catch(() => {}) Silent Exception Swallowing Fix

**Date**: 2026-07-19
**Scope**: TD-259 #12 (P1) — 14 处 `.catch(() => {})` 静默吞异常
**Type**: Frontend fix + i18n

## Problem

14 处 `.catch(() => {})` 静默吞异常 — 用户可见的 fetch 失败无任何提示，开发者 debug 也无线索。违反 `frontend-conventions.md` 错误处理规范。

## Solution

每处评估后按场景分两类处理:

### 9 处加 `message.error` (用户可见 fetch 失败)

| File | Site | i18n key |
|------|------|----------|
| `frontend/src/pages/Tasks/TaskFormModal.tsx` | fetchGameAccounts | `tasks.load_accounts_failed` |
| `frontend/src/pages/Tasks/TaskFormModal.tsx` | fetchDevices | `tasks.load_devices_failed` |
| `frontend/src/pages/Tasks/TaskFormModal.tsx` | fetchGameProfiles | `tasks.load_profiles_failed` |
| `frontend/src/pages/Accounts/GameAccountEditor.tsx` | fetchAccountGroups | `accounts.load_groups_failed` |
| `frontend/src/pages/Accounts/GameAccountEditor.tsx` | fetchGameOptions | `accounts.load_game_options_failed` |
| `frontend/src/pages/Accounts/GameAccountEditor.tsx` | fetchResourcePacks | `accounts.load_resource_packs_failed` |
| `frontend/src/pages/Ops/Monitors/index.tsx` | fetchResourcePacks | `monitors.load_resource_packs_failed` |
| `frontend/src/pages/Tasks/Marketplace.tsx` | listPipelines | `marketplace.load_pipelines_failed` |
| `frontend/src/pages/Resources/TemplateAnnotation/TemplateAnnotationTab.tsx` | fetchTemplates | `templateAnnotation.load_templates_failed` |

每处模式: `.catch((err) => { message.error(t('...')); console.warn('[Component] fetch failed:', err); })`

### 5 处保留静默 + 加 `console.warn` (合理场景)

| File | Site | Reason |
|------|------|--------|
| `frontend/src/pages/Resources/TemplateAnnotation/TemplateAnnotationTab.tsx` | fetchResourcePacks | empty state 已渲染, 不需 toast |
| `frontend/src/pages/Tasks/PipelineEditor/PipelineEditorPage.tsx` | pipelineApi.listPipelines | 保留 `setCanExecute(false)` 安全默认值 |
| `frontend/src/pages/System/SystemSettings.tsx` | fetchAgentDebug | backend 可能不可用, 保留 defaults |
| `frontend/src/pages/System/SystemSettings.tsx` | fetchWindowBackgroundWait | 同上 |
| `frontend/src/hooks/useSSEStream.ts` | readerRef.current.cancel | SSE reader 已关闭, 静默合理 |

### i18n 4 locale × 5 files = 32 new entries

- `tasks.ts`: 3 keys × 4 locale = 12 entries
- `accounts.ts`: 3 keys × 4 locale = 12 entries
- `monitors.ts`: 1 key × 4 locale = 4 entries
- `marketplace.ts`: 1 key × 4 locale = 4 entries
- `templateAnnotation.ts`: 1 key × 4 locale = 4 entries

## Verification

### Type check
```
npx tsc --noEmit
```
**Result**: ✅ exit 0, 11.17s

### Unit tests
```
npx vitest run
```
**Result**: ✅ 20 test files / 154 tests passed, 11.33s (tests), 72.76s (total)

### Naming consistency fix
代码层最初用 `template_annotation.load_templates_failed` (snake_case), 与 i18n 文件已有 prefix `templateAnnotation` (camelCase) 不一致 → 修正为 `templateAnnotation.load_templates_failed`。

## Performance (N171)

| Command | Time | Baseline | Status |
|---------|------|----------|--------|
| `npx tsc --noEmit` | 11.17s | N/A (full project type check) | ✅ acceptable |
| `npx vitest run` | 72.76s (total) / 11.33s (tests) | < 30s tests | ✅ tests pass baseline |

## Files Changed (15 files)

**Code (9 files)**:
1. `frontend/src/pages/Tasks/TaskFormModal.tsx`
2. `frontend/src/pages/Accounts/GameAccountEditor.tsx`
3. `frontend/src/pages/Ops/Monitors/index.tsx`
4. `frontend/src/pages/Tasks/Marketplace.tsx`
5. `frontend/src/pages/Resources/TemplateAnnotation/TemplateAnnotationTab.tsx`
6. `frontend/src/pages/Tasks/PipelineEditor/PipelineEditorPage.tsx`
7. `frontend/src/pages/System/SystemSettings.tsx`
8. `frontend/src/hooks/useSSEStream.ts`

**i18n (5 files)**:
9. `frontend/src/i18n/locales/tasks.ts`
10. `frontend/src/i18n/locales/accounts.ts`
11. `frontend/src/i18n/locales/monitors.ts`
12. `frontend/src/i18n/locales/marketplace.ts`
13. `frontend/src/i18n/locales/templateAnnotation.ts`

**Tech debt (1 file)**:
14. `docs/general/tech-debt/active.md` — #12 ✅ FIXED + TD-259 进度行 + 顶部清单行

**Spec status (1 file)**:
15. `.trae/specs/2026-07-19-spec34-auditlog-p0-wire-to-viewsets.md` — Phase 4 commit hash 修正 (d68effe1)
