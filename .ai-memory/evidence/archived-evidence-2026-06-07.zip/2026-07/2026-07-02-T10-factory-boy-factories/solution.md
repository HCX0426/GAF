---
maintainer: AI
source: task T10 factory_boy test factories
created_at: 2026-07-02
---

## Solution

1. Created `backend/accounts/factories.py` with `UserFactory`, `AdminUserFactory`, `OperatorUserFactory`, and `GameAccountFactory`.
2. Created `backend/agents/factories.py` with `AgentFactory`, `DeviceFactory`, `WindowsDeviceFactory`, and `DeviceGroupFactory`.
3. Created `backend/tasks/factories.py` with `TaskFactory` and `TaskExecutionFactory`.
4. Extended `backend/conftest.py` with global pytest fixtures (`user`, `admin`, `operator`, `agent`, `device`, `task`, `task_execution`).
5. Migrated sample tests to use factories:
   - `backend/accounts/tests/test_accounts.py`
   - `backend/agents/tests/test_device_api.py`
   - `backend/tasks/tests/test_tasks.py`
6. Updated `docs/standards/backend-conventions.md` §10 with factory guidelines.
7. Set `skip_postgeneration_save = True` in all factories to avoid the factory_boy deprecation warning while relying on Django's `set_password()` to persist the password.
