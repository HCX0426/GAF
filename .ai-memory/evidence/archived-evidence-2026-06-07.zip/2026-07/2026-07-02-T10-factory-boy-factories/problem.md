---
maintainer: AI
source: task T10 factory_boy test factories
created_at: 2026-07-02
---

## Problem

Test data creation in `accounts/tests/`, `agents/tests/`, and `tasks/tests/` was using repetitive `User.objects.create_user(...)` and `Model.objects.create(...)` boilerplate. This made tests verbose, hard to maintain, and inconsistent. `factory_boy` was already listed in `requirements/dev.txt` and installed in the conda environment, but no factories or global fixtures existed.
