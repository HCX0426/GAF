---
maintainer: AI
source: task T10 factory_boy test factories
created_at: 2026-07-02
---

## Verification

```powershell
cd GAF/backend
conda run -n gaf pytest accounts/tests/test_accounts.py agents/tests/test_device_api.py tasks/tests/test_tasks.py -v
conda run -n gaf ruff check accounts/factories.py agents/factories.py tasks/factories.py conftest.py accounts/tests/test_accounts.py agents/tests/test_device_api.py tasks/tests/test_tasks.py
```

Expected:
- `45 passed`
- `All checks passed!`

Actual output matched expectations.
