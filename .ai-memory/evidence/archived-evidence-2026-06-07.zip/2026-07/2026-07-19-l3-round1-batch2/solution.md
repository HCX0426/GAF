# TD-259 Batch 2 — Solution

## Backend changes (subagent + main)

### #9 gaf_core docstrings `core.*` → `gaf_core.*` (8 fixes)
- `backend/gaf_core/exceptions.py:5` — `:class:`core.error_codes.ErrorCode`` → `gaf_core.error_codes.ErrorCode`
- `backend/gaf_core/middleware.py:22` — `:func:`core.exceptions.unified_exception_handler`` → `gaf_core.exceptions.unified_exception_handler`
- `backend/gaf_core/models.py:17` — `` ``core.handlers.DatabaseLogHandler`` `` → `gaf_core.handlers.DatabaseLogHandler`
- `backend/gaf_core/views.py:255` — `LogEntry (core.LogEntry)` → `LogEntry (gaf_core.LogEntry)`
- `backend/gaf_core/tests/test_responses.py:24,46,64,110` — 4 docstring fixes
- `apps.py:8` left alone — `agent/src/core/` is a legitimate cross-package path (not the renamed Django app)

### #15 ExecutionStep deletion — ABORTED (wontfix)
Subagent grep disproved "0 business callers" premise:
- `backend/agents/consumers.py:17,435,442` — imports + `ExecutionStep.objects.update_or_create(...)`
- `backend/tasks/heartbeat.py:11,42-44` — `ExecutionStep.objects.filter(...).update(...)`
- `backend/tasks/analytics_views.py:13,69,71,141` — analytics aggregation
- `backend/protocol/consumers.py:25,399,402` — persists ExecutionStep from `task.progress` frames
- `backend/tasks/signals.py:93,232` — 2 `post_save` receivers
- Tests: `test_agent_tools.py:124`, `test_step_progress_persistence.py`, `test_step_failure_e2e.py`, `test_recovery_signal.py`

ExecutionStep is the **step-level progress persistence** core model, not dead code. No deletion performed.

### #18 TaskExecution 3 composite indexes
`backend/tasks/models.py` TaskExecution.Meta.indexes added:
```python
models.Index(fields=["chain_execution", "status"], name="idx_taskexec_chain_status"),
models.Index(fields=["device", "status"], name="idx_taskexec_device_status"),
models.Index(fields=["game_account", "status"], name="idx_taskexec_account_status"),
```
New migration: `backend/tasks/migrations/0048_taskexec_composite_indexes.py` (depends on `0047_taskexecution_agent_blank`).

### #22 _map_agent_device_id cache
The function lives in `backend/protocol/consumers.py:663` (NOT `agents/services.py` as TD-259 guessed) as a `@database_sync_to_async` method on `AgentConsumer`. Takes 4 args + `self`, uses `self.agent_id` as key — `functools.lru_cache` doesn't fit (method + DB-backed + multiple args). 

Used module-level dict cache with manual invalidation:
- `protocol/consumers.py:54-69`: `_AGENT_DEVICE_ID_CACHE: dict[tuple, int | None] = {}` + `clear_agent_device_id_cache()`
- `protocol/consumers.py:680`: new async `_map_agent_device_id` wrapper (cache hit returns, miss awaits uncached lookup)
- `protocol/consumers.py:715`: original method renamed to `_lookup_agent_device_id_uncached`
- `agents/signals.py:99-141`: 2 new receivers (`post_save` + `post_delete` on Device) → `clear_agent_device_id_cache()` (lazy import to avoid circular)
- Cache key = `(self.agent_id, agent_device_id, device_name, device_type, window_handle)`
- Strategy: clear entire dict on any Device change (Device writes are rare vs 30 FPS frame rate)

## Frontend changes (main session)

### #14 WS reconnect-failed notification
**`frontend/src/websocket/client.ts`** (4 changes):
1. New private field: `onReconnectFailedCallbacks: Set<() => void>`
2. New public methods: `onReconnectFailed(cb)` + `offReconnectFailed(cb)`
3. New private method: `fireReconnectFailedCallbacks()` (try/catch per-cb, mirrors existing fire* patterns)
4. `tryReconnect()`: when `reconnectAttempts >= max`, also call `fireReconnectFailedCallbacks()` (in addition to existing `fireCloseCallbacks`)

**`frontend/src/providers/WebSocketProvider.tsx`** (3 changes):
1. Import `App` from antd + `useRef`
2. `const { notification } = App.useApp()` + `reconnectFailedKeyRef = useRef<string | null>(null)`
3. `onReconnectFailed` callback: idempotent (skip if key already set), shows `notification.warning({ key: 'ws-reconnect-failed', duration: 0, placement: 'top' })`
4. `onOpen` callback: `notification.destroy(key)` if previously shown (auto-dismiss on reconnect)
5. Cleanup: `wsClient.offReconnectFailed(onReconnectFailed)` in useEffect return

**`frontend/src/providers/__tests__/WebSocketProvider.test.tsx`** (3 changes):
1. Mock `antd` with stable singleton `mockAppApi` (notification.warning/destroy/close + message.*)
2. Add `onReconnectFailed`/`offReconnectFailed`/`emitReconnectFailed` to `mockWsClient`
3. New test "subscribes to reconnect-failed events and surfaces a notification (TD-259 #14)": verifies registration + warning call args + idempotency

### #5 frontend-conventions PageWrapper count
`docs/standards/frontend-conventions.md` §8 line 279 updated from "108 个页面仅 AdbLogViewerPage 用了 PageWrapper" → "88 个页面（不含 __tests__）中 35 个用 PageWrapper" (matches header line 17, 2026-07-18 TD-177 recount).

## Why antd v6 `App.useApp()` instead of static `notification`
- antd v6 deprecates static `notification.warning()` etc. (no ConfigProvider theme/locale)
- `WebSocketProvider` is rendered inside `<AntApp>` (App.tsx:161) so `App.useApp()` works
- `useRef` tracks active notification key for idempotency + auto-dismiss

## Why dict cache instead of `functools.lru_cache` for _map_agent_device_id
- Method on consumer class + DB-backed result + 5 args (self + 4 kwargs) → lru_cache doesn't fit cleanly
- Module-level dict allows external `clear_agent_device_id_cache()` for signal-driven invalidation
- Cache key is hashable tuple of all 5 inputs
- Invalidation = clear entire dict on Device save/delete (Device writes rare vs 30 FPS frame rate)
