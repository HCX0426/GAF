# TD-259 Batch 2 — Problem

## Context
Continuation of L3-1 round 1 scan [B] class cleanup, triggered by user "继续" (loop mode).

## Problems (7 items, 4 backend + 2 frontend + 1 doc)
1. **TD-259 #5 (P3 doc)**: `frontend-conventions.md` §8 PageWrapper count contradicts header — §8 says "108 页面仅 AdbLogViewerPage 用", header (updated 2026-07-18 TD-177) says "88 页面中 35 个用". §8 is stale.
2. **TD-259 #9 (P3 backend)**: `backend/gaf_core/` 5+ docstrings still reference `core/*` paths (leftover from TD-116 rename). Actual count was 8 (not 5).
3. **TD-259 #14 (P2 frontend)**: WS client `tryReconnect()` exhausts 10 retries then only fires `fireCloseCallbacks` — no UI notification. User has no idea live data (logs/screenshots/task progress) stopped flowing.
4. **TD-259 #15 (P3 backend)**: `ExecutionStep` model assumed dead code (0 business callers) → planned deletion. **Premise was wrong**: subagent grep found 5 active business callers + tests.
5. **TD-259 #18 (P2 backend)**: `TaskExecution` missing 3 composite indexes — `(chain_execution,status)`, `(device,status)`, `(game_account,status)`. Filtering by these combos does seq scan.
6. **TD-259 #22 (P2 backend)**: `_map_agent_device_id` called per screenshot frame (~30 FPS), each call hits DB. Causes DB load spike during long task executions.

## Why fix now
- All 6 are < 500 line diffs → [B] class small-fix path
- #15 disproven → wontfix, prevents bad delete
- #14 is user-facing UX issue (silent failure)
- #18 + #22 are perf wins (DB load)
- #5 + #9 are doc drift cleanup
