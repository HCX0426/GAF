---
spec_id: spec-46
phase: all
type: verification
created: 2026-07-20
related_files:
  - scripts/governance/check_dimensions/d4_path_drift.py
  - scripts/governance/thresholds.yaml
  - scripts/tests/test_doc_health_check.py
---

# Verification

## Phase 1 验证

### 单元测试 (d4_path_drift)

```
scripts/tests/test_doc_health_check.py::test_d4_path_drift_detects_missing_related_file PASSED
scripts/tests/test_doc_health_check.py::test_d4_path_drift_valid_path_no_issue PASSED
scripts/tests/test_doc_health_check.py::test_d4_path_drift_body_file_protocol_missing PASSED
scripts/tests/test_doc_health_check.py::test_d4_path_drift_body_backtick_path_existing_no_issue PASSED
scripts/tests/test_doc_health_check.py::test_d4_path_drift_body_http_url_skipped PASSED
scripts/tests/test_doc_health_check.py::test_d4_path_drift_body_skipped_in_docs_dir PASSED
scripts/tests/test_doc_health_check.py::test_d4_path_drift_ai_memory_path_not_truncated PASSED
scripts/tests/test_doc_health_check.py::test_d4_path_drift_dot_slash_prefix_normalized PASSED
scripts/tests/test_doc_health_check.py::test_d4_path_drift_evidence_dir_uses_evidence_severity PASSED  # NEW
scripts/tests/test_doc_health_check.py::test_d4_path_drift_lessons_dir_keeps_default_severity PASSED  # NEW
scripts/tests/test_doc_health_check.py::test_d4_path_drift_evidence_severity_defaults_to_severity PASSED  # NEW

11 passed, 39 deselected in 0.22s
```

✅ 8 原有测试全 PASS (无回归) + 3 新增测试全 PASS

### doc_health_check.py P0 降级验证

**Before (spec-46 前)**:
- d4_path_drift P0: 343
- d4_path_drift P2: 0
- Total: 404 issues

**After Phase 1 (evidence/ 降级)**:
- d4_path_drift P0: 181 (-162)
- d4_path_drift P2: 162 (+162, evidence 降级后的 P2)
- Total: 404 (数量不变,但 P0 大幅降低)

✅ evidence/ 降级生效

## Phase 2 验证

### 批量脚本执行

```
Total: stripped 174 GAF/ prefixes from 44 files
```

✅ 44 个文件修复,174 个 GAF/ 前缀 strip

### doc_health_check.py P0 进一步降低

**After Phase 1 + Phase 2**:
- d4_path_drift P0: 173 (-8 from Phase 1, lessons/ GAF/ 前缀修复)
- d4_path_drift P2: 36 (-126 from Phase 1, evidence/ GAF/ 前缀修复)
- Total: 270 issues (-134 from baseline, -33.2%)

### d4_path_drift 残留分布

```
== d4_path_drift total: 209 ==
  lessons           94  (P0, 真实漂移)
  summaries         60  (P0, 真实漂移 — architecture-mistakes.md 58 body path)
  evidence          36  (P2, 历史快照)
  platforms         11  (P0, 真实漂移)
  other              8  (P0, 真实漂移)
```

剩余 173 P0 = 真实漂移 (文件已删除/移动,引用过期) → 登记为 TD

## 全量回归

```
9 failed, 317 passed in 144.52s
```

**Before (spec-45 全量回归基线)**: 10 failed, 313 passed in 47.10s
**After (spec-46)**: 9 failed, 317 passed

✅ +4 passed (3 新增 d4_path_drift 测试 + 1 个之前失败的现在通过)
✅ -1 failed (改善)
✅ 无回归

### 9 failed 全为预存失败 (与 spec-46 无关):

- 5 e2e: cold_start / browser_login / devices_control_mode / ai_qa_chat / bootstrap_gaf (前端服务未启动 + .ai-memory 缺 4 个 auto-kb 文件)
- 4 extract_lessons: bug-tracker 0 items (与 spec-46 无关)
- 0 d4_path_drift 相关失败

## 性能验证

- doc_health_check.py: 0.94s (< 1s 可接受,比基线 0.66s 略慢,因为新增 evidence_severity 判断逻辑)
- pytest scripts/tests/: 144.52s (包含 2 次跑 — Measure-Command + 实际跑;单次约 72s)

## 飞轮读侧解锁效果

| 指标 | Before | After | 改善 |
|------|:------:|:-----:|:----:|
| d4_path_drift P0 | 343 | 173 | -170 (-49.6%) ✅ |
| Total issues | 404 | 270 | -134 (-33.2%) ✅ |
| evidence/ P0 | 162 | 0 | -162 (-100%) ✅ |
| evidence/ P2 | 0 | 36 | +36 (降级,不阻塞) |
| lessons/ P0 | 102 | 94 | -8 (GAF/ 前缀修复) ✅ |

✅ 飞轮读侧解锁: P0 从 343 降到 173,飞轮 patch 可聚焦处理真实漂移
