---
spec_id: spec-46
phase: all
type: solution
created: 2026-07-20
related_files:
  - scripts/governance/check_dimensions/d4_path_drift.py
  - scripts/governance/thresholds.yaml
  - scripts/tests/test_doc_health_check.py
---

# Solution

## N167 七维度评分

| 方案 | ① 架构 | ② 归一化 | ③ 兼容 | ④ 完善 | ⑤ 性能 | ⑥ 安全 | ⑦ 维护 | 总分 | 自决? |
|------|:----:|:------:|:----:|:----:|:----:|:----:|:----:|:----:|:----:|
| A: Phase 1 (降级 evidence/) + Phase 2 (批量修复 GAF/ 前缀) | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 21 | ✅ |
| B: 只 Phase 1 (降级 evidence/) | 3 | 3 | 3 | 2 | 3 | 3 | 3 | 20 | ❌ |
| C: 不开 spec,登记 TD | 1 | 1 | 3 | 1 | 1 | 3 | 1 | 11 | ❌ |

**自决决策**: A (总分 21/21, 领先 B 1 分,但 Phase 2 工作量极小 — 8 个 lessons 文件批量脚本,
合并到 spec-46 是自然组合,不需要 AskUserQuestion 弹窗)

**硬场景检查** (§7.4): ① FK 绊住? N ② schema 分裂? N ③ 业务语义? N ④ 不可逆? N

## Phase 1: d4_path_drift 检查器降级 evidence/ 到 P2

### 改动

#### `scripts/governance/check_dimensions/d4_path_drift.py`

`check()` 函数加目录级 severity 配置:

```python
default_severity = thresholds.get("severity", "P0")
evidence_severity = thresholds.get("evidence_severity", default_severity)
# ...
# Spec-46: evidence/ is a historical snapshot, use lower severity
if rel.startswith(".ai-memory/evidence/"):
    severity = evidence_severity
else:
    severity = default_severity
```

向后兼容: 如果 `evidence_severity` 未配置,回退到 `default_severity` (现有行为不变)。

#### `scripts/governance/thresholds.yaml`

```yaml
d4_path_drift:
  severity: "P0"
  # Spec-46: evidence/ is a historical snapshot, not a contract.
  evidence_severity: "P2"
```

### 测试

新增 3 个测试 in `scripts/tests/test_doc_health_check.py`:

1. `test_d4_path_drift_evidence_dir_uses_evidence_severity`:
   evidence/ frontmatter 引用不存在的文件 → P2 (不是 P0)

2. `test_d4_path_drift_lessons_dir_keeps_default_severity`:
   lessons/ frontmatter 引用不存在的文件 → P0 (保持契约)

3. `test_d4_path_drift_evidence_severity_defaults_to_severity`:
   未配置 evidence_severity → evidence/ 回退到 default severity (P0, 向后兼容)

## Phase 2: 批量修复 GAF/ 前缀错误

### 改动

写临时脚本 `.trash/strip_gaf_prefix.py` (跑完即删):

- 扫描 `.ai-memory/evidence/` 和 `.ai-memory/lessons/` 的 frontmatter
- 匹配 `^(\s*-\s+)GAF/(.+)$` 模式 (frontmatter list item with GAF/ prefix)
- 替换为 `\1\2` (strip GAF/ prefix)
- 跑完删除脚本

### 结果

- stripped 174 GAF/ prefixes from 44 files
- evidence/ 的 GAF/ 前缀错误全修复 (保持历史快照整洁,虽然已降级到 P2)
- lessons/ 的 GAF/ 前缀错误全修复 (8 个 P0 → 0)

## 关键决策

1. **evidence/ 降级到 P2,不忽略**: 保留检查,但降级严重性。如果 evidence 的 related_files 有真实漂移,仍然报 P2 (警告,不阻塞飞轮)。

2. **lessons/ 保持 P0**: lessons 是"当前有效的教训",related_files 是契约,必须指向现有代码。

3. **不修复真实漂移 (171 P0)**: 工作量大 (~30 文件,需逐个分析),登记为 TD,后续 spec 处理。

4. **向后兼容**: evidence_severity 未配置时回退到 default severity,现有配置无需改动。

5. **临时脚本不持久化**: `.trash/strip_gaf_prefix.py` 跑完即删,不污染 scripts/ 目录。
