---
spec_id: spec-46
phase: all
type: problem
created: 2026-07-20
related_files:
  - scripts/governance/check_dimensions/d4_path_drift.py
  - scripts/governance/thresholds.yaml
  - scripts/tests/test_doc_health_check.py
---

# Problem

## 现象

spec-45 commit 后跑 `doc_health_check.py` 报 **404 issues**,其中 **d4_path_drift P0 = 343**。
这是飞轮读侧的严重阻塞 — spec-42 飞轮 patch 应该处理 P0,但 343 个 P0 全是 evidence/lessons
的 `related_files` frontmatter 引用了已删除/迁移的历史文件,飞轮 patch 不知道如何修复
(不是规则文档路径漂移,是 evidence 文件路径漂移)。

## P0 分布 (L3-1 扫描结果)

| 类别 | 数量 | 性质 |
|------|:----:|------|
| `.ai-memory/evidence/` | 162 | 历史快照 (代码后续重构不应追溯更新) |
| lessons/ GAF/ 前缀错误 | 8 | 路径前缀错误 (写了 `GAF/scripts/...`) |
| evidence/ GAF/ 前缀错误 | 156 | 同上,但 evidence/ 已降级 |
| lessons/summaries/platforms 真实漂移 | 171 | 文件已删除/移动,引用过期 |
| **合计** | **343** | |

## 根因

`d4_path_drift.py` 注释 (line 64-65):
> "Frontmatter `related_files` is always scanned (it is a contract, not a historical mention)."

这个假设对 lessons/summaries 是合理的 (它们是"当前有效的教训/总结"),
但对 **evidence/ 是不合理的** — evidence 是"历史快照",记录当时改了哪些文件,
后续代码重构/删除不应追溯更新 evidence 的 `related_files`。

## 影响

- 飞轮读侧阻塞: spec-42 飞轮 patch 看到 343 P0,但不知道如何修复 evidence 历史快照
- AI 启动开销: gaf_init.sh 跑 doc_health_check.py 输出 404 issues,信息过载
- 真实问题被淹没: 173 个真实漂移 (lessons/summaries) 被 162 个 evidence 误报淹没
