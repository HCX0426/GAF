# P-010 Phase 3 — Solution

## 改动文件

### 1. `backend/tasks/signals.py`

**import 增量**：
```python
from scheduler.recovery_engine import handle_step_failure, handle_task_failure
```

**module-level 防递归集合**：
```python
_processing_step_ids: set[int] = set()
```

**新增 `trigger_recovery_on_step_failure` receiver**：
```python
@receiver(post_save, sender=ExecutionStep)
def trigger_recovery_on_step_failure(sender, instance, created, update_fields, **kwargs):
    if instance.status != ExecutionStep.Status.FAILED:
        return
    if instance.id is None:
        return
    if instance.id in _processing_step_ids:
        logger.debug('ExecutionStep %s 已在恢复中, 跳过 signal 触发 (防递归)', instance.id)
        return

    step_id = instance.id
    error_message = instance.error_message or ''
    _processing_step_ids.add(step_id)

    logger.info('ExecutionStep %s (execution=%s) 失败, 触发步骤级恢复',
                step_id, instance.task_result_id)

    def _run_step_recovery():
        try:
            result = handle_step_failure(execution_step_id=step_id, error_message=error_message)
            logger.info('ExecutionStep %s 恢复结果: action=%s, success=%s',
                        step_id, result.get('action'), result.get('success'))
        except Exception as exc:
            logger.error('ExecutionStep %s 恢复失败: %s', step_id, exc)
        finally:
            _processing_step_ids.discard(step_id)

    transaction.on_commit(_run_step_recovery)
```

### 2. `backend/tasks/tests/test_recovery_signal.py`

新增 `TestStepRecoverySignal` 类，7 个测试：

1. `test_step_failed_triggers_handle_step_failure` — status=FAILED → handle_step_failure called with (id, error)
2. `test_step_success_does_not_trigger` — status=SUCCESS → not called
3. `test_step_created_failed_triggers` — created=True + FAILED → called（区别于 task-level 的 skip）
4. `test_step_update_to_failed_triggers` — update RUNNING→FAILED → called
5. `test_anti_recursion_same_step_id` — 同 step save 两次 → called once
6. `test_recovery_completes_then_new_failure_triggers_again` — on_commit 完成后 id 释放，新 step 失败可再触发
7. `test_handle_step_failure_exception_clears_set` — handle_step_failure 抛异常时 finally 仍释放 set

## 设计决策

| 决策 | 理由 |
|------|------|
| 不跳过 `created=True` | Phase 2 `update_or_create` 可直接创建 status=FAILED 行；task-level 跳过是因为 TaskExecution 总以 PENDING 创建，step 无此保证 |
| `_processing_step_ids` 用 set[int] 不用模型字段 | 避免迁移；进程内集合足够（单进程 Django + celery worker 各自独立） |
| `add` 在 `on_commit` 之前 | 同事务内 re-entrant save 能被阻止 |
| `discard` 在 `finally` 块 | 保证异常时也释放，不泄漏 |
| `handle_step_failure` 用 kwargs 传参 | 与 task-level 一致，便于 mock 断言 |
| setUp 中 `_processing_step_ids.clear()` | 防止测试间状态泄漏（captureOnCommitCallbacks 未执行时 id 可能残留） |

## 与 task-level receiver 的对比

```python
# task-level (P-020-D): 跳过 created=True，用 recovery_attempts 字段防递归
if created:
    return
if instance.recovery_attempts > 0 or instance.recovery_layer > 0:
    return

# step-level (P-010 Phase 3): 不跳过 created，用 module-level set 防递归
if instance.id in _processing_step_ids:
    return
```
