# P-010 Phase 3 — Problem

## 背景

P-010 Phase 2 已让 protocol consumer 持久化 ExecutionStep 到数据库。但 `handle_step_failure` 函数（P-020-B ActionChain 重构时实现）在 production code 中仍是**零调用方** — 没有任何代码触发它。

Phase 3 的职责：**通过 Django post_save 信号将 ExecutionStep(status=FAILED) 接入 handle_step_failure**，完成 step 级恢复管线的最后一公里。

## 设计差异：step-level vs task-level

| 维度 | task-level (P-020-D) | step-level (P-010 Phase 3) |
|------|---------------------|---------------------------|
| 信号 sender | TaskExecution | ExecutionStep |
| `created=True` 处理 | 跳过（TaskExecution 总是以 PENDING 创建） | **不跳过**（Phase 2 `update_or_create` 可直接创建 status=FAILED 行） |
| 防递归机制 | 模型字段 `recovery_attempts > 0` | module-level `_processing_step_ids: set`（无迁移） |
| 触发函数 | `handle_task_failure(exec_id, consecutive)` | `handle_step_failure(step_id, error_message)` |

## 防递归设计

`handle_step_failure` 当前不 save ExecutionStep（已确认：`scheduler/recovery_engine.py` 不引用 ExecutionStep），但未来 retry action 可能会。防递归策略：

1. **module-level `_processing_step_ids: set[int]`** — 进程内集合，不加模型字段避免迁移
2. 信号触发前：检查 `instance.id in _processing_step_ids`，若在则跳过
3. 信号触发时：`_processing_step_ids.add(step_id)` **在 `transaction.on_commit` 之前**
4. on_commit 回调 `finally` 块：`_processing_step_ids.discard(step_id)` — 保证异常时也释放

这样：
- 同一 step 的 re-entrant save（恢复动作本身触发的 save）→ 被阻止
- 恢复完成后（on_commit 执行完毕）→ id 释放，后续真实失败可再次触发

## 范围

- ✅ ExecutionStep post_save → handle_step_failure（pipeline 模式）
- ✅ 防递归（_processing_step_ids set）
- ✅ 异常安全（finally 释放 set）
- ❌ E2E 测试（Phase 4）
- ❌ 全量回归（Phase 4）
