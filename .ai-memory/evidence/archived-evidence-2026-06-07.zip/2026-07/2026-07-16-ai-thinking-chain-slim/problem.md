## Problem（症状 / 触发条件）

AI 思维链规则文档存在 4 类膨胀问题：
1. **N## 只增不减**：编号永不复用 + dormant 靠人工判定 → failure-modes.md 必然膨胀
2. **单一权威源未脚本验证**：每条 N## 在 4-5 个文件留痕，靠人工"归一化注释"维护 → 必漂移
3. **反思矩阵形式化**：24 项 Y/N 让 AI 自决跑哪些 → 走形式 / 漏检查
4. **规则总量无上限**：无总量上限，规则总量必然超过单次会话上下文上限

影响范围：.ai-memory/meta/failure-modes.md (110 行) + .trae/skills/gaf-*/SKILL.md + .trae/rules/project_rules.md + scripts/lessons/promote_lessons.py + scripts/bootstrap/sync_skills.py + scripts/gaf_init.sh
触发条件：每次 AI 任务开工加载 L1/L2 文件时，规则膨胀导致上下文占用增加 + 单一权威源漂移导致 AI 读到不一致指令
