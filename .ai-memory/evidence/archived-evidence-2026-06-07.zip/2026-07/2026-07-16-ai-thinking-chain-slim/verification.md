## Verification（验证）

P6 全量回归 6 命令跑通：

$ python scripts/bootstrap/sync_skills.py --check
✅ 0 error (P3 治本机制: N## 索引行唯一性检测通过)

$ python scripts/lessons/promote_lessons.py --archive --dry-run
✅ 归档候选 0 条 (P2 机制工作: 当前所有 N## 都被引用, 无 dormant 候选)

$ python scripts/lessons/promote_lessons.py --enforce-limits --dry-run
✅ 无需归档 (P5 机制工作: 110 行 ≤ 120 硬上限)

$ python scripts/select_reflection_checks.py --diff HEAD~1
✅ 输出 6 项 Y/N: N95/N132/N112/N128/N117/N111 (P4 机制工作: 按 diff 自动选)

$ python scripts/bootstrap/sync_ai_memory.py --query workflow
✅ 找到 11 条匹配 (L3 按需加载机制工作)

$ PowerShell fallback 验证 L1+P5 (bash 不在 PATH):
  $fm = Get-Content .ai-memory/meta/failure-modes.md
  $lines = $fm.Count  # 110
  $nCount = ($fm | Select-String '^\| N[0-9]+').Count  # 52
  → ✅ L1 hard-load OK (52 ≥ 5) + P5 limit OK (110 ≤ 130 警告阈值)

预期：所有命令 exit 0，机制工作证明治本落地。failure-modes.md 110 行 ≤ 120 硬上限，反思矩阵 6 项 ≤ 6 上限。
