## Solution（解决步骤）

治本原则：每个 Phase 建立**机制**（脚本/自动验证），治标动作作为机制副产物自然完成。

1. **P2 N## 生命周期自动化**：`scripts/lessons/promote_lessons.py` 加 `--archive` 子命令，扫描 lessons/ front matter，6 个月未在 failure-modes.md / yn-matrices / SKILL.md 出现 + cross-ref ≤ 1 → 自动追加到 `.ai-memory/meta/archived-lessons.md` + 从 failure-modes.md 主索引移除
2. **P3 单一权威源脚本验证**：`scripts/bootstrap/sync_skills.py --check` 加 `check_n_index_duplication()` 规则，N## 索引行（4 列 + 第 4 列含 lessons/闭环/dormant/已合并）只能在 failure-modes.md / archived-lessons.md 出现，违反 → exit 1
3. **P4 反思矩阵按 diff 自动选**：新写 `scripts/select_reflection_checks.py`，输入 `git diff --name-only` + diff 内容，按 PATH_PATTERNS / CONTENT_PATTERNS / DEFAULT_CORE_CHECKS 关键词映射自动选 3-6 项 Y/N，输出选中清单 + 对应 yn-matrices sub-file 路径
4. **P5 规则总量上限硬约束**：`promote_lessons.py` 加 `--enforce-limits` 子命令，failure-modes.md > 120 行 → 自动归档"未被 yn-matrices 引用 + 最后引用时间最早"的 N## 直到 ≤ 120 行（被引用的 N## refcount > 0 → continue 跳过）；`scripts/gaf_init.sh` L1 检查增加行数验证 > 130 行警告
5. **P6 全量回归**：6 命令跑通验证机制工作（sync_skills 0 error / gaf_init L1+P5 OK / archive 0 候选 / enforce-limits 无需归档 / select_reflection_checks 6 项 / sync_ai_memory 11 匹配）

涉及文件：
- `scripts/lessons/promote_lessons.py`（P2 + P5）
- `scripts/bootstrap/sync_skills.py`（P3）
- `scripts/select_reflection_checks.py`（P4 新写）
- `scripts/gaf_init.sh`（P5 行数警告）
- `.ai-memory/meta/failure-modes.md`（P5 头部注释）
- `.ai-memory/meta/archived-lessons.md`（P2 自动归档）
- `.trae/skills/gaf-orchestrator/SKILL.md`（P4 脚本驱动）
- `.trae/skills/gaf-reflect-and-evolve/SKILL.md`（P4 治本机制段）
- `docs/general/specs/2026-07-16-ai-thinking-chain-slim.md`（spec）
