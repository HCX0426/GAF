---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-26-docs-restructure-p0/
load_when: [evidence, 3-step-evidence, b2, docs-restructure, p0]
priority: high
symptom: [kb:docs-restructure-p0, big-change, docs-migration, dual-track-navigation]
solution: Problem — docs/ + .ai-memory/ 结构混乱，文档查找困难，无业务/架构双线索导航
related_files:
  - .ai-memory/evidence/2026-07-26-docs-restructure-p0/solution.md
  - .ai-memory/evidence/2026-07-26-docs-restructure-p0/verification.md
  - docs/specs/active/2026-07-25-docs-ai-memory-restructure.md
  - docs/plans/2026-07-25-docs-ai-memory-restructure.md
created_by: AI
last_updated: 2026-07-26
---
## Problem（症状 / 触发条件）

1. **现象**：`docs/` 目录结构混乱，存在 `general/` + `superpowers/` + `governance/` 三个并行目录，业务文档与架构文档混在 `general/design/` 下，无业务/架构双线索导航入口
2. **触发条件**：AI 或人类查找文档时无法快速定位 — 业务模块（workspace/game-profile/tasks 等 9 模块）和架构分层（frontend/backend/agent/desktop/cross-cutting）无独立索引
3. **影响范围**：
   - `docs/general/` 18 份 design + 5 份 analysis + 1 份 troubleshooting + 4 份 tech-debt + 2 份 health-checks + 3 份顶层文件 = 33 文件需迁移
   - `docs/superpowers/specs/` + `docs/superpowers/plans/` 需合并到 `docs/specs/` + `docs/plans/`
   - `docs/general/specs/` 与 `docs/specs/` 存在重复（dependency-graph.md）
   - 全仓 50+ 处旧路径引用（`docs/general/...` / `docs/superpowers/...`）需同步更新
   - `scripts/bootstrap/sync_docs_index.py` 缺 `module` / `applies_to_code_paths` / `doc_last_updated` 字段生成
   - `scripts/hooks/doc_sync_rules.py` R3/R7 规则引用旧路径
4. **B2 触发**：P0 阶段改动规模 = 195 文件变动 + 846 insertions + 4260 deletions，远超 B2 阈值（500 行 / 2 跨 app），需 N151 5 步流程 + B2 证据
