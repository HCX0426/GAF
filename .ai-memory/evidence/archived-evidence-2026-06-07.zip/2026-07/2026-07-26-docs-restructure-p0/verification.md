---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-26-docs-restructure-p0/
load_when: [evidence, 3-step-evidence, b2, docs-restructure, p0]
priority: high
symptom: [kb:docs-restructure-p0, big-change, docs-migration, dual-track-navigation]
solution: Verification — P0 验证清单 10 项 + grep 旧路径零残留 + sync_docs_index 通过
related_files:
  - .ai-memory/evidence/2026-07-26-docs-restructure-p0/problem.md
  - .ai-memory/evidence/2026-07-26-docs-restructure-p0/solution.md
  - docs/specs/active/2026-07-25-docs-ai-memory-restructure.md
  - docs/plans/2026-07-25-docs-ai-memory-restructure.md
created_by: AI
last_updated: 2026-07-26
---
## Verification（验证）

P0 验证清单 10 项（per `docs/plans/2026-07-25-docs-ai-memory-restructure.md` §3.3）：

| # | 验证项 | 命令 | 结果 |
|---|--------|------|------|
| 1 | 文件数对比 | `conda run -n gaf python -c "import os; print(sum(1 for _ in os.walk('docs') for f in _[2] if f.endswith('.md')))"` | ✅ 迁移前后总数一致 |
| 2 | git mv 历史保留 | `git log --follow docs/architecture/overview.md` | ✅ 显示原 `docs/general/design/architecture-overview.md` 历史 |
| 3 | sync_docs_index 无报错 | `conda run -n gaf python scripts/bootstrap/sync_docs_index.py` | ✅ 退出码 0 |
| 4 | 旧路径零残留 | `git grep -E "docs/(general\|superpowers\|governance)/" -- scripts backend agent frontend .trae/skills .trae/rules .ai-memory/meta docs/business docs/architecture docs/analysis docs/tech-debt docs/health docs/standards docs/README.md` | ✅ exit code 1（0 匹配） |
| 5 | docs-index.md module 字段 | `grep "module:" .ai-memory/meta/docs-index.md` | ✅ 抽查 5 份条目正确 |
| 6 | docs-index.md applies_to_code_paths 字段 | `grep "applies_to_code_paths:" .ai-memory/meta/docs-index.md` | ✅ 字段存在 |
| 7 | docs-index.md doc_last_updated 字段 | `grep "doc_last_updated:" .ai-memory/meta/docs-index.md` | ✅ YYYY-MM-DD 格式 |
| 8 | doc_sync_rules.py R3/R7 路径 | `git grep -E "docs/general/" -- scripts/hooks/doc_sync_rules.py` | ✅ exit code 1（0 匹配） |
| 9 | 空目录 .gitkeep | `glob docs/business/*/.gitkeep` + `glob docs/architecture/*/.gitkeep` | ✅ 6 个空目录均有 .gitkeep |
| 10 | B2 证据检查 | `conda run -n gaf python scripts/check_big_change.py --staged --acknowledge` | ✅ 通过（B2 证据生成于本目录） |

**复现命令**：

```bash
$ conda run -n gaf python scripts/bootstrap/sync_docs_index.py
$ git grep -E "docs/(general|superpowers|governance)/" -- scripts backend agent frontend .trae/skills .trae/rules .ai-memory/meta docs
$ conda run -n gaf python scripts/check_big_change.py --staged --acknowledge
```

预期：
- sync_docs_index.py 退出码 0
- git grep exit code 1（0 匹配 in-scope 文件）
- check_big_change.py 写入 `.cache/b2_acknowledged.json`

**B2 触发说明**：
- P0 改动规模 = 195 文件变动 + 846 insertions + 4260 deletions
- 远超 B2 阈值（500 行 / 2 跨 app）
- B2 证据提前生成于 `.ai-memory/evidence/2026-07-26-docs-restructure-p0/`（本目录）
- N151 5 步流程已遵循：spec → plan → 实施 → 验证 → commit
