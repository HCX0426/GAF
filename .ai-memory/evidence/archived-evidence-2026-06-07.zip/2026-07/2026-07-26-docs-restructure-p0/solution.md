---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-26-docs-restructure-p0/
load_when: [evidence, 3-step-evidence, b2, docs-restructure, p0]
priority: high
symptom: [kb:docs-restructure-p0, big-change, docs-migration, dual-track-navigation]
solution: Solution — 双线索结构 + spec 目录合并 + sync_docs_index 升级 + 全量引用同步
related_files:
  - .ai-memory/evidence/2026-07-26-docs-restructure-p0/problem.md
  - .ai-memory/evidence/2026-07-26-docs-restructure-p0/verification.md
  - docs/specs/active/2026-07-25-docs-ai-memory-restructure.md
  - docs/plans/2026-07-25-docs-ai-memory-restructure.md
created_by: AI
last_updated: 2026-07-26
---
## Solution（解决步骤）

1. **新建双线索目录** `docs/business/{workspace,game-profile,tasks,devices,resources,accounts,ops,ai,system}/` + `docs/architecture/{frontend,backend,agent,desktop,cross-cutting}/`，6 个空目录加 `.gitkeep`（P0-1）
2. **git mv 迁移 18 份 design** `docs/general/design/*.md` → `docs/business/<module>/*.md` 或 `docs/architecture/<layer>/*.md`（按 spec §9.1 业务×架构映射表，P0-2）
3. **git mv 迁移 5 份 analysis** `docs/general/analysis/*.md` → `docs/analysis/`，`GAF-optimal-solution.md` → `docs/architecture/optimal-solution.md`（P0-3）
4. **git mv 迁移 troubleshooting + tech-debt + health-checks + 顶层 3 文件** 到 `docs/business/tasks/` + `docs/tech-debt/` + `docs/health/` + `docs/`（P0-4 ~ P0-6, P0-10）
5. **合并 spec 目录** `docs/general/specs/` + `docs/superpowers/specs/` → `docs/specs/{active,archived}/`，删重复 dependency-graph.md（P0-7）
6. **提升 plans 目录** `docs/superpowers/plans/` → `docs/plans/`（P0-8）
7. **删除空目录** `docs/general/` + `docs/superpowers/` + `docs/governance/`（P0-11）
8. **重写 `scripts/bootstrap/sync_docs_index.py` v9.0** 加 `_MODULE_CODE_PATHS` 映射表 + `_derive_module_from_path()` + `_get_applies_to_code_paths()` + `_get_doc_last_updated_from_git()`，重跑生成新 `docs-index.md`（P0-13）
9. **更新 `scripts/hooks/doc_sync_rules.py` R3/R7** 路径：R3 `required_docs=("docs/architecture/", "docs/business/")`，R7 `required_docs=("docs/architecture/desktop/deployment-design.md",)`（P0-15）
10. **全量引用路径同步更新**：grep 扫描 + 修复 8 个代码文件 + 5 个 skills 文件 + 13 个核心代码 + 22 个核心文档 + 2 个 evidence 文件的旧路径引用（P0-16a~g）
