---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-08/
load_when: [evidence, 3-step-evidence, pre-commit-broken, stale-hook-path, no-verify-bypass]
priority: high
symptom: [kb:evidence-2026-07-08, pre-commit-stale-path, no-verify-hidden-debt, migration-drift, lessons-frontmatter]
solution: Pre-commit hooks broken by stale INSTALL_PYTHON path (env moved C:\Users\hcx\miniconda3 → D:\code\environment\conda); --no-verify bypass hid 3 categories of pre-existing failures (evidence dir, lessons front-matter, spec consistency path bug) + settings/monitors migration drift.
related_files:
  - .git/hooks/pre-commit
  - .pre-commit-config.yaml
  - scripts/check_lessons_updated.py
  - scripts/check_spec_consistency.py
  - scripts/check_3step_evidence.py
created_by: AI
last_updated: 2026-07-08
---
## Problem（症状 / 触发条件）

**现象**: `git commit` 报 "pre-commit not found" / hook 找不到 python。

**触发条件**: conda env 从 `C:\Users\hcx\miniconda3\envs\gaf` 迁移到 `D:\code\environment\conda\envs\gaf` 后，`.git/hooks/pre-commit` 内硬编码的 `INSTALL_PYTHON` 路径失效。

**影响范围**:
1. **N105 `--no-verify` 被过度适用**: N105 原本只针对 `gaf-commit.sh` 透传 bug，但被泛化为"任何 pre-commit 失败都用 --no-verify 绕过"。
2. **3 类预存错误被隐藏** (10+ GAF 知识系统 hooks 静默跳过):
   - `gaf-3step-evidence`: today's evidence dir 缺失
   - `gaf-lessons-updated`: 6 个 lesson 文件 front-matter 缺字段 + 9 个 related_files 路径失效
   - `gaf-spec-consistency`: `check_spec_consistency.py` 路径 bug (`root.parent / ".trae"` 应为 `root / ".trae"`)
3. **settings/monitors migration drift**: LLMConfig/UnattendedStrategy/MonitorEvent/MonitorRule 字段 help_text/verbose_name 漂移，未生成 migration。
