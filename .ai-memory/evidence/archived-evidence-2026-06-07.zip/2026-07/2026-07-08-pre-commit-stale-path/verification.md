---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-08/
load_when: [evidence, 3-step-evidence, verification, pre-commit-passes, hooks-validated]
priority: high
symptom: [kb:evidence-2026-07-08, verification, all-hooks-pass, lessons-validated, spec-consistent]
solution: 3 hooks verified passing: lessons validator (40 lessons), spec consistency, full pre-commit run (all 10 hooks green).
related_files:
  - scripts/check_lessons_updated.py
  - scripts/check_spec_consistency.py
  - scripts/check_3step_evidence.py
  - .pre-commit-config.yaml
created_by: AI
last_updated: 2026-07-08
---
## Verification（验证）

```powershell
# 1. Lessons front-matter validator — 40 lessons, 0 warnings
conda run -n gaf python -B scripts/check_lessons_updated.py
# Expected: "✅ 40 lessons validated" (exit 0)

# 2. Spec / tasks / checklist consistency
conda run -n gaf python -B scripts/check_spec_consistency.py
# Expected: "✅ spec / tasks / checklist consistent" (exit 0)

# 3. Full pre-commit run (all 10 hooks) — via conda
conda run -n gaf pre-commit run --hook-stage pre-commit --all-files
# Expected: all hooks Passed (exit 0)

# 4. git commit (THE decisive test — hooks run via .git/hooks/pre-commit, not conda)
git commit -F .trash/commit_msg_n150.txt
# Expected: all 10 hooks Passed during actual git commit — no --no-verify needed
# Actual: commit 6e6676d created, 26 files changed, 734 insertions(+), 36 deletions(-)
```

**Expected results**:
- `check_lessons_updated.py` → exit 0, "✅ 40 lessons validated"
- `check_spec_consistency.py` → exit 0, "✅ spec / tasks / checklist consistent"
- `pre-commit run --all-files` → all 10 hooks Passed (via conda python)
- `git commit` → all 10 hooks Passed (via system PATH python — proves `language: python` fix works)
- Commit 6e6676d created, 26 files changed, 734 insertions(+), 36 deletions(-) ✅
