---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-08/
load_when: [evidence, 3-step-evidence, pre-commit-fix, root-cause, lessons-cleanup]
priority: high
symptom: [kb:evidence-2026-07-08, solution-steps, reinstall-hooks, fix-paths, generate-migrations]
solution: 5 步根因修复: (1) reinstall hooks (2) fix spec consistency path (3) fix 11 lessons front-matter + paths (4) generate drift migrations (5) fill evidence templates.
related_files:
  - .git/hooks/pre-commit
  - scripts/check_spec_consistency.py
  - .ai-memory/lessons/2026-07-02-n139-vite-proxy-localhost-ws-handshake.md
  - .ai-memory/lessons/2026-06-16-n111-command-timeout.md
  - .ai-memory/lessons/2026-06-16-n112-p024-frontend-sync.md
  - backend/settings/migrations/0004_alter_llmconfig_api_base_alter_llmconfig_api_key_and_more.py
  - backend/monitors/migrations/0004_alter_monitorevent_acknowledged_by_and_more.py
created_by: AI
last_updated: 2026-07-08
---
## Solution（解决步骤）

1. **Change `language: system` to `language: python`** (N150 true root-cause fix):
   - `.pre-commit-config.yaml`: 11 GAF hooks (10 pre-commit + 1 pre-push) changed from `language: system` to `language: python`
   - pre-commit creates a managed virtualenv; `entry: python scripts/...` uses venv python, not system PATH
   - Fixes Windows Store python stub (exit 9009) interception during `git commit`
   - Scripts only import stdlib + scripts/ local modules, no `additional_dependencies` needed
   - 4 manual-stage lint hooks (eslint/prettier/ruff/mypy) kept as `language: system` (Node/CLI tools)

2. **Reinstall pre-commit hooks** (INSTALL_PYTHON path fix):
   ```
   conda run -n gaf pre-commit install
   conda run -n gaf pre-commit install --hook-type pre-push
   ```
   Regenerated `.git/hooks/pre-commit` + `.git/hooks/pre-push` with correct `INSTALL_PYTHON='D:\code\environment\conda\envs\gaf\python.exe'`.

3. **Fix `check_spec_consistency.py` path bug** (2 locations):
   - `scripts/check_spec_consistency.py:52` — `SPEC_DIR_DEFAULT = REPO_ROOT_DEFAULT.parent / ".trae"` → `REPO_ROOT_DEFAULT / ".trae"`
   - `scripts/check_spec_consistency.py:229` — `spec_dir = root.parent / ".trae"` → `root / ".trae"`
   - Bug: script looked for `.trae` in `D:\code\` instead of `D:\code\GAF\`.

4. **Fix 11 lesson files** front-matter + related_files paths:
   - 6 files missing required fields (date/symptom/solution/related_files/created_by): n139, n146, n147, n148, n149, n30
   - 5 files with stale `GAF/` prefix or moved paths: n142, n143, n144, n111, n112, n132, n134
   - N110 (merged to N105 family) → repoint to n105-commit-bypass-rollback.md
   - Monitors/index.tsx → Ops/Monitors/index.tsx; SkillMarket/index.tsx → AI/SkillMarket.tsx

5. **Generate settings + monitors drift migrations**:
   ```
   conda run -n gaf python backend/manage.py makemigrations settings monitors
   conda run -n gaf python backend/manage.py migrate settings monitors
   ```

6. **Fill evidence templates** with real content (replace placeholder text that triggered gaf-3step-evidence hook).
