# Problem: BlueStacks screenshot placeholder

`backend/device_bridge/platforms/windows/_adb_screenshot.py` had a dedicated
`bluestacks` method registered, but `_capture_by_bluestacks()` returned `None`
unconditionally. This forced BlueStacks devices to fall back to the generic ADB
`screencap` chain, which is 2-3x slower than a native emulator screenshot path.
