# Solution: BSTKService HTTP forward + fallback

Implemented `_capture_by_bluestacks()` to:

1. Forward local TCP port 55555 to the device's port 55555 via `adb forward`.
2. Request `http://127.0.0.1:55555/screenshot` (and `/screenshot.png`) over HTTP.
3. Return the image bytes if the response is large enough to be a real image.
4. Log failures at debug level and return `None` so the existing fallback chain
   (`screencap` → `screencap_png`) continues to work.

Also cleaned up legacy `typing.Dict/List/Optional` annotations in the touched
file and added test coverage for:
- BlueStacks method appearing in the BlueStacks priority chain.
- Successful capture via mocked subprocess + urllib.
- Forward failure and empty response returning `None`.
