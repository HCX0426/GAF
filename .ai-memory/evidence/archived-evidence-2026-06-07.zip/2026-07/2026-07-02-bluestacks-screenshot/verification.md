# Verification

- `pytest backend/device_bridge/tests/test_adb_screenshot.py -v` → 12 passed.
- `ruff check backend/device_bridge/platforms/windows/_adb_screenshot.py backend/device_bridge/tests/test_adb_screenshot.py` → 0 errors.
- `mypy` could not run because of a pre-existing environment issue:
  `Plugin "mypy_django_plugin" does not define entry point function "plugin"`.
  This is not related to the changed code.
- Updated `docs/general/plans/2026-07-02-unimplemented-items.md` to mark T06 as ✅.
