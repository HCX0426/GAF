---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, problem-step, evidence-problem]
solution: Problem — TaskViewSet.validate 把 CheckItem 列表压成 list[str], 丢失 node_id/suggestion, 前端无法定位到具体节点
related_files:
  - .ai-memory/evidence/2026-07-28-task-1-5-validate-check-items/solution.md
  - .ai-memory/evidence/2026-07-28-task-1-5-validate-check-items/verification.md
  - backend/tasks/views.py
  - backend/pipeline/validators.py
created_by: AI
last_updated: 2026-07-28
---
## Problem（症状 / 触发条件）

N192 B3 P1: TaskViewSet.validate action 把校验结果压成 `list[str]`, 丢失 node_id/suggestion 字段:

1. 现象: 调用 `POST /api/v2/tasks/<pk>/validate/` 返回 `{"errors": ["nodes[0] 缺少 type/node_type 字段"]}`, errors 是字符串列表, 前端无法定位到具体节点
2. 触发条件: 用户在前端编辑器配置任务节点时, 任意节点缺必填字段 (templateId/threshold 等) 或结构错误 (nodes 不是数组等) 都会触发
3. 影响范围: 所有 pipeline 模式任务的校验接口; 前端只能展示字符串错误, 无法高亮失败节点; 用户必须数 nodes 索引才能找到出错节点 (B3 错误定位缺失)
