---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, solution-step, evidence-solution]
solution: Solution — validate action 改为返回 CheckItem dict 列表, 调用 PipelineValidator 跑完整校验
related_files:
  - .ai-memory/evidence/2026-07-28-task-1-5-validate-check-items/problem.md
  - .ai-memory/evidence/2026-07-28-task-1-5-validate-check-items/verification.md
  - backend/tasks/views.py
  - backend/tasks/tests/test_tasks.py
created_by: AI
last_updated: 2026-07-28
---
## Solution（解决步骤）

1. 重写 `backend/tasks/views.py` 的 `TaskViewSet.validate` action, 早期结构错误 (task_definition 空 / 不是 dict / nodes 缺失等) 用 `_early_error()` 包装成 CheckItem dict (`{check, status, message, node_id, suggestion}`), 保持响应结构一致
2. pipeline 模式调用 `PipelineValidator().validate({"nodes": nodes, "edges": edges})` 跑完整校验 (必填字段 + 模板引用 + Pipeline 引用 + 孤立节点 + 入口出口), 过滤掉 pass 状态只返回 fail+warn, `valid = all(item["status"] != "fail" for item in check_items)`
3. 替换 `backend/tasks/tests/test_tasks.py` 的 `test_validate_pipeline_task_missing_type` 为 `test_validate_pipeline_task_missing_required_field` (新实现不再早期检查 type/node_type, 交给 PipelineValidator); 新增 3 个测试验证 CheckItem dict 结构含 node_id/suggestion; 修复原测试用 `response.data['valid']` 在 UnifiedResponseMiddleware 包装下 KeyError 问题 (改用 `response.json()`)
