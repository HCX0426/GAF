---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, verification-step, evidence-verification]
solution: Verification — TestTaskValidationAction 7 passed (4 原有 + 3 新增), RED 阶段 4 FAIL 已验证
related_files:
  - .ai-memory/evidence/2026-07-28-task-1-5-validate-check-items/problem.md
  - .ai-memory/evidence/2026-07-28-task-1-5-validate-check-items/solution.md
  - backend/tasks/tests/test_tasks.py
created_by: AI
last_updated: 2026-07-28
---
## Verification（验证）

$ conda run -n gaf python -m pytest backend/tasks/tests/test_tasks.py::TestTaskValidationAction -v --no-header

预期：7 passed (test_validate_empty_task_definition / test_validate_empty_task_definition_returns_check_item_dict / test_validate_pipeline_task_missing_required_field / test_validate_pipeline_task_valid / test_validate_returns_check_items_for_failing_node / test_validate_returns_check_items_with_node_id / test_validate_state_machine_task_valid)

RED 阶段已验证: 修改 views.py 前 4 个新测试 FAIL (200 != 400 / 0 not greater than 0 / '任务定义不能为空' is not dict), 3 个原测试 PASS
GREEN 阶段已验证: 修改 views.py 后 7 个测试全部 PASS
