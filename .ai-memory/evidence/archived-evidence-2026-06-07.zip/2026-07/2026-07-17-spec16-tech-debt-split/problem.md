# Problem: tech-debt/active.md 134KB 超 Read 128KB 限制

## 症状

L3 Round 8 评估循环终止后, 用户反馈"每次扫描都好久, 是不是要瘦身了"。

## 根因

`docs/general/tech-debt/active.md` 单文件 134KB (97337 chars), 超 Read 工具 128KB 限制:
- 119 个 TD 条目, 其中 42 个 ✅ FIXED 残留 (违反 README.md 承诺"已关闭条目已迁移到 fixed.md")
- 真正活跃 🔧 待修 + 🚧 进行中 条目 76 个
- 每次 L3-1 扫描必须用 offset+limit 分段读取, 耗时

## 影响

- AI 无法一次性读取 active.md, 必须分段 Grep + Read
- L3-1 扫描 ② 代码层 / ⑤ 功能层时, tech-debt 扫描耗时占比高
- 用户感知"每次扫描都好久"

## 数据

- active.md 拆分前: 97337 chars, 119 TD (42 ✅ FIXED + 76 🔧 + 1 template)
- fixed.md 拆分前: 118228 chars, 100 TD (旧 89 + 后续 11)
- wontfix.md 拆分前: 8748 chars, 7 TD
- README.md 计数过期: 显示 active=4 / fixed=89 / wontfix=5 / 合=98 (实际 76/100/7/183)
