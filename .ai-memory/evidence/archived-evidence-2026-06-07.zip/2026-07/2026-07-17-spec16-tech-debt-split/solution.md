# Solution: spec-16 Phase 1-3 拆分 + 同步 + 退役评估

## Phase 1: active.md ✅ FIXED 条目迁出

**脚本**: `.trash/split_tech_debt.py` (可复用, 参数 `--dry-run` 支持预览)

**算法**:
1. 解析 active.md 为 header / TD entries / footer
2. 每个 TD entry 检测状态 (从标题或 `- **状态**:` 行)
3. ✅ FIXED → 追加到 fixed.md 末尾 (按 TD 编号排序)
4. ❌ WONTFIX/INVALIDATED/EVALUATED → 追加到 wontfix.md
5. 🔧/🚧 → 保留在 active.md
6. TD-NNN template (HTML 注释) 被误迁到 fixed.md → Edit 删除 + 在 active.md 顶部重新插入

**结果**:
- active.md: 97337 → 56219 chars (-42%, 56219 < 100KB ✅)
- fixed.md: 118228 → 159414 chars (+42 个 ✅ FIXED)
- wontfix.md: 8748 → 8749 chars (无变化, 0 条 WONTFIX 迁出)

**迁出的 42 个 ✅ FIXED**: TD-110, TD-111, TD-112, TD-113, TD-114, TD-115, TD-116, TD-117, TD-118, TD-120, TD-121, TD-122, TD-123, TD-124, TD-125, TD-126, TD-156, TD-157, TD-158, TD-159, TD-160, TD-161, TD-162, TD-163, TD-164, TD-165, TD-166, TD-167, TD-168, TD-169, TD-170, TD-171, TD-172, TD-173, TD-191, TD-195, TD-196, TD-209, TD-211, TD-212, TD-213, TD-216

## Phase 2: README.md 计数同步

Grep 验证 (`^## TD-\d+` 计数):
- active.md: 76
- fixed.md: 142 (旧 100 + 新 42)
- wontfix.md: 7
- 合计: 225

更新 README.md L23-26 表格 + frontmatter `last_updated` 2026-07-14 → 2026-07-17

## Phase 3: failure-modes.md 退役评估

按 §退役规则判定:
- 时间维度: N## entry ≥ 6 个月未触发 (2026-07-17 - 6 月 = 2026-01-17 前)
- 评估: 所有 51 条 Active N## 的 lesson 文件日期均在 2026-06 之后, 均 < 6 月
- 结论: **无 N## 满足退役条件**, 仅文档化评估结论

在 §退役规则段追加"退役评估记录" (2026-07-17 spec-16 Phase 3)

## 风险缓解

| 风险 | 缓解 |
|------|------|
| 迁出 ✅ FIXED 时遗漏条目 | 脚本 dry-run 预览 + Grep 验证 active.md 不含 ✅ FIXED 状态行 |
| fixed.md 编号顺序乱 | 脚本按 TD 编号升序追加 |
| TD-NNN template 被误迁 | Edit 从 fixed.md 删除 + active.md 重新插入 |
| 破坏其他文件对 TD-NNN 的引用 | TD 条目内容不变, 仅文件位置变化; 引用使用 `[active.md](active.md#td-NNN)` 形式 — 后续如发现 stale 引用再修 |
| pre-commit hook 失败 | Phase 4 验证, 失败则根因修复 (N150) |
