## Solution（解决方案）

B 阶段 4 个任务归一化 backend 日志路径 + trace_id 全链路贯穿:

1. **B1 FileLogHandler 路径重构**: `_resolve_exec_log_dir` 系统日志路径从 `_global/<YYYYMMDD>/` 改为 `debug/YYYYMMDD/backend/system/HH/` (五层结构对齐 + 小时分桶自动轮转); `emit` 按 execution_id 选 `django.log` (系统) / `run.log` (执行) 文件名区分两类日志。

2. **B2 BackendTaskLogger 新增**: 写 `debug/YYYYMMDD/backend/tasks/<safe_pipeline>/HH/execution.jsonl`; 每行 JSONL 含 `timestamp/level/trace_id/execution_id/pipeline_name/event` + payload 顶层合并; 小时滚转自动创建新文件; pipeline 名称 sanitize; 异常吞掉 (best-effort)。

3. **B3 trace_id 全链路贯穿**:
   - B3-1: `serialize_frame` 断点②修复 — `trace_id=None` 时优先从 `current_trace_id` ContextVar 取, 15 调用点零改动; 优先级: 显式参数 > ContextVar > uuid 兜底
   - B3-2: middleware `str(uuid.uuid4())[:16]` → `str(uuid.uuid4())` (完整 UUID, 与 WS 帧 UUIDField schema 对齐)
   - B3-3: `TaskExecution.trace_id` CharField(max_length=64, blank=True, db_index=True) + migration 0051
   - B3-4: `dispatch_task` + `views.execute` 从 ContextVar 取 trace_id 持久化到 TaskExecution.trace_id + meta.json + BackendTaskLogger; `write_meta_json` 加 trace_id 显式参数

涉及文件: `backend/gaf_core/{handlers,task_logger,debug_path}.py` + `backend/protocol/serializers.py` + `backend/tracing/middleware.py` + `backend/tasks/{models,tasks}.py` + `backend/pipeline/views.py` + migration 0051 + 4 个测试文件。
