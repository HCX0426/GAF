## Verification（验证过程 / 结果）

### 测试命令与结果

```powershell
# B1 FileLogHandler 测试 (14 passed)
D:\code\environment\conda\envs\gaf\python.exe -m pytest backend/gaf_core/tests/test_file_log_handler.py -v --no-header
# 14 passed

# B2 BackendTaskLogger 测试 (12 passed)
D:\code\environment\conda\envs\gaf\python.exe -m pytest backend/gaf_core/tests/test_task_logger.py -v --no-header
# 12 passed

# B3-1 serialize_frame ContextVar 测试 (5 new + 5 原 passed)
D:\code\environment\conda\envs\gaf\python.exe -m pytest backend/protocol/tests/test_message_frame.py::TestSerializeFrameContextVar backend/protocol/tests/test_message_frame.py::TestSerializeFrame -v --no-header
# 10 passed

# B3-2 middleware UUID 格式测试 (3 new + 5 原 passed)
D:\code\environment\conda\envs\gaf\python.exe -m pytest backend/tracing/tests/test_middleware.py -v --no-header
# 8 passed

# B3-3 migration 应用验证
D:\code\environment\conda\envs\gaf\python.exe backend\manage.py migrate tasks --no-input
# Applying tasks.0051_taskexecution_trace_id... OK

# B3-4 dispatch_task trace_id 注入测试 (3 new passed)
D:\code\environment\conda\envs\gaf\python.exe -m pytest backend/tasks/tests/test_execution_flow.py::DispatchTaskTraceIdTest -v --no-header
# 3 passed

# 全量 backend 回归测试 (2196 passed 无回归)
D:\code\environment\conda\envs\gaf\python.exe -m pytest backend/ --no-header -q
# 2196 passed
```

### 验证要点

- B1: 系统日志路径从 `_global/<YYYYMMDD>/run.log` 改为 `YYYYMMDD/backend/system/HH/django.log`; 文件名按 execution_id 区分 (`_global` → `django.log`, 其他 → `run.log`); 小时滚转测试通过
- B2: JSONL 路径 `YYYYMMDD/backend/tasks/<safe_pipeline>/HH/execution.jsonl`; 必填字段 (trace_id/execution_id/pipeline_name/event/timestamp/level) 齐全; payload 顶层合并; 小时滚转 + 名称 sanitize + 异常吞掉 全部测试通过
- B3-1: ContextVar trace_id 优先级正确 (显式 > ContextVar > uuid); 多次调用同 scope 内 trace_id 一致
- B3-2: 完整 UUID (36 字符) 通过 MessageFrameSerializer UUIDField schema 校验; 不再是 16 字符截断
- B3-3: migration 0051 应用成功; TaskExecution.trace_id 字段可持久化
- B3-4: dispatch_task 持久化 trace_id 到 TaskExecution.trace_id + meta.json + execution.jsonl; views.execute 同步注入
- 全量回归: 2196 passed (+23 新测试) 无回归
