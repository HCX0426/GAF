## Problem（症状 / 触发条件）

debug 目录结构存在 5 类问题: (1) 系统日志走旧 `_global/<YYYYMMDD>/run.log` 单文件路径, 长期运行无限增长; (2) backend 缺任务级 JSONL 日志, 任务事件散落在 Django 日志里无法按 pipeline 聚合; (3) HTTP trace_id 与 WS trace_id 两套体系不互通 — middleware 用 `str(uuid.uuid4())[:16]` 截断格式, WS 帧 schema 要求完整 UUID, 导致 schema 校验失败; (4) `serialize_frame` 15 个调用点每个手动传 trace_id, 易遗漏; (5) TaskExecution 无 trace_id 字段, 无法按 trace_id 反查执行记录。

影响范围: backend 全栈 (gaf_core / protocol / tracing / tasks / pipeline 5 个 app) + agent 侧 (A 阶段已处理) + DB migration。触发条件: 任何 HTTP 请求触发 task execution 时, trace_id 在 HTTP→WS→DB→log 链路中断。
