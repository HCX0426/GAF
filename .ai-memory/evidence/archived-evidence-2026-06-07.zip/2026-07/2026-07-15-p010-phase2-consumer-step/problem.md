# P-010 Phase 2 — Problem

## 背景

P-010 Phase 1 已让 agent 在 pipeline 模式下通过 `task.progress` 帧发送 step 级状态（含 step_index/status/error_msg/elapsed_time）。

但 protocol consumer 的 `_handle_task_progress` 只把进度帧转发到 dashboard group（前端实时显示），**不持久化 ExecutionStep**。这导致：

1. **数据丢失**：step 级状态无法跨连接保留，recovery engine 无从感知 step 失败。
2. **`handle_step_failure` 仍零调用方**：Phase 3 计划用 ExecutionStep post_save 信号触发该函数，但前提是 ExecutionStep 必须被写入数据库。
3. **双轨制反模式暴露**：legacy `agents/consumers.py:_update_execution_progress` 已经在写 ExecutionStep，但新 `protocol/consumers.py` 完全不写。

## 范围

- ✅ pipeline 模式 task.progress 帧（带 step_index）→ 持久化 ExecutionStep
- ❌ chain 模式（step 失败 = task 失败，已有 task 级恢复覆盖）
- ❌ 信号触发（Phase 3 处理）
- ❌ recovery engine 本体（P-020-B 已实现）

## 风险点

| 风险 | 缓解 |
|------|------|
| async consumer 中调用同步 ORM 抛 `SynchronousOnlyOperation` | 用 `@database_sync_to_async` 包装 `_persist_execution_step` |
| 未知 execution_id（agent 状态不一致）导致 consumer 崩溃 | catch `DoesNotExist`/`ValueError`，只 log warning，不抛 |
| retry 时同 step_index 重复写入 | 用 `update_or_create(task_result, step_index, defaults=...)` upsert |
| 未知 status 字符串 | status_map 回退到 `RUNNING`，不丢行 |
| FK task_result_id 是 BigAutoField 不是 UUID | 测试用 `ExecutionStep.objects.count()` 而非按 UUID 过滤 |
