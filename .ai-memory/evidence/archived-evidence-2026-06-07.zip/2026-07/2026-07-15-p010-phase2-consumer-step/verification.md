# P-010 Phase 2 — Verification

## 测试运行

```
conda run -n gaf python -m pytest backend/protocol/tests/test_step_progress_persistence.py --tb=short -v
```

### 结果

```
collected 6 items

backend/protocol/tests/test_step_progress_persistence.py::TestStepProgressPersistence::test_step_progress_failed_persists_execution_step_with_error PASSED [ 16%]
backend/protocol/tests/test_step_progress_persistence.py::TestStepProgressPersistence::test_step_progress_invalid_status_falls_back_to_running PASSED [ 33%]
backend/protocol/tests/test_step_progress_persistence.py::TestStepProgressPersistence::test_step_progress_success_persists_execution_step PASSED [ 50%]
backend/protocol/tests/test_step_progress_persistence.py::TestStepProgressPersistence::test_step_progress_unknown_execution_id_is_non_fatal PASSED [ 66%]
backend/protocol/tests/test_step_progress_persistence.py::TestStepProgressPersistence::test_step_progress_upserts_on_resend PASSED [ 83%]
backend/protocol/tests/test_step_progress_persistence.py::TestStepProgressPersistence::test_step_progress_without_step_index_skips_persistence PASSED [100%]

============================= 6 passed in 50.68s ==============================
```

**6/6 PASSED**

## Ruff

```
conda run -n gaf ruff check backend/protocol/consumers.py backend/protocol/tests/test_step_progress_persistence.py
```

```
All checks passed!
```

## 测试覆盖矩阵

| Test | 覆盖路径 | 关键断言 |
|------|---------|---------|
| `test_step_progress_success_persists_execution_step` | `_persist_execution_step` success 分支 | ExecutionStep(SUCCESS) + completed_at + duration |
| `test_step_progress_failed_persists_execution_step_with_error` | `_persist_execution_step` failed 分支 | ExecutionStep(FAILED) + error_message + completed_at |
| `test_step_progress_upserts_on_resend` | `update_or_create` upsert 语义 | 1 行（不重复），status 由 RUNNING → SUCCESS |
| `test_step_progress_without_step_index_skips_persistence` | `_handle_task_progress` 跳过分支 | ExecutionStep 0 行 |
| `test_step_progress_unknown_execution_id_is_non_fatal` | `DoesNotExist`/`ValueError` catch | consumer 不崩，ExecutionStep 0 行 |
| `test_step_progress_invalid_status_falls_back_to_running` | status_map fallback | ExecutionStep(RUNNING) |

## 历史问题与修复

| 错误 | 根因 | 修复 |
|------|------|------|
| `SynchronousOnlyOperation` | async test 方法直接调用 ORM | 所有 ORM 调用包 `sync_to_async` |
| `Field 'id' expected a number but got '00000000-0000-0000-0000-000000000000'` | task_result_id 是 BigAutoField FK，不接受 UUID | 用 `ExecutionStep.objects.count()` 而非按 sentinel UUID 过滤 |
| `Field 'id' expected a number but got '12345678-1234-1234-1234-123456789abc'` | 同上 | 同上 |

## 未覆盖项（Phase 3/4 处理）

- ❌ ExecutionStep post_save 信号触发 `handle_step_failure` → Phase 3
- ❌ 防递归测试（_processing_step_ids set）→ Phase 3
- ❌ 端到端（agent 帧 → consumer → ExecutionStep → signal → recovery）→ Phase 4
- ❌ 全量回归（backend/ + agent/）→ Phase 4
