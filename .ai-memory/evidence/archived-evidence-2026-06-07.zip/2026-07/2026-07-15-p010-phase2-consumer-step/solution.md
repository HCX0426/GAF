# P-010 Phase 2 — Solution

## 改动文件

### 1. `backend/protocol/consumers.py`

**import 增量**：
```python
from tasks.models import ExecutionStep, TaskExecution
```

**`_handle_task_progress` (line 339-380) — 加 step_index 分支**：
```python
async def _handle_task_progress(self, frame):
    payload = frame.get("payload", {})
    # ... existing logging ...
    step_index = payload.get("step_index")
    # P-010 Phase 2: persist ExecutionStep when the agent sends a
    # step-level progress frame (pipeline mode).
    if step_index is not None:
        await self._persist_execution_step(payload)
    # ... existing dashboard forward ...
```

**新增 `_persist_execution_step` 方法**（仿 `agents/consumers.py:_update_execution_progress` 的 update_or_create 模式）：

```python
@database_sync_to_async
def _persist_execution_step(self, payload: dict[str, Any]) -> None:
    execution_id = payload.get("execution_id", "")
    step_index = payload.get("step_index")
    if not execution_id or step_index is None:
        return

    try:
        execution = TaskExecution.objects.get(id=execution_id)
    except (TaskExecution.DoesNotExist, ValueError):
        logger.warning(
            "task.progress 收到未知 execution_id=%s, 无法持久化 ExecutionStep",
            execution_id,
        )
        return

    step_status_raw = (payload.get("status") or "").lower()
    status_map = {
        "pending": ExecutionStep.Status.PENDING,
        "running": ExecutionStep.Status.RUNNING,
        "success": ExecutionStep.Status.SUCCESS,
        "failed": ExecutionStep.Status.FAILED,
        "skipped": ExecutionStep.Status.SKIPPED,
    }
    step_status = status_map.get(step_status_raw, ExecutionStep.Status.RUNNING)

    step_name = payload.get("step_name") or f"step_{step_index}"
    node_id = payload.get("node_id") or str(step_index)
    error_msg = payload.get("error_msg", "") or ""
    elapsed_time = payload.get("elapsed_time")
    now = django_timezone.now()

    defaults: dict[str, Any] = {
        "node_id": node_id,
        "step_name": step_name,
        "step_type": "pipeline_node",
        "status": step_status,
    }
    if error_msg:
        defaults["error_message"] = error_msg
    if isinstance(elapsed_time, (int, float)) and elapsed_time >= 0:
        defaults["duration"] = float(elapsed_time)
        defaults["duration_ms"] = int(elapsed_time * 1000)
    if step_status in (ExecutionStep.Status.SUCCESS, ExecutionStep.Status.FAILED,
                       ExecutionStep.Status.SKIPPED):
        defaults["completed_at"] = now
        if not defaults.get("started_at"):
            defaults["started_at"] = now - timedelta(seconds=float(elapsed_time or 0))

    try:
        ExecutionStep.objects.update_or_create(
            task_result=execution,
            step_index=step_index,
            defaults=defaults,
        )
    except Exception as exc:
        logger.exception(
            "持久化 ExecutionStep 失败: execution_id=%s step_index=%s: %s",
            execution_id, step_index, exc,
        )
```

### 2. `backend/protocol/tests/test_step_progress_persistence.py` (新建)

6 个 async TestCase 测试：

1. `test_step_progress_success_persists_execution_step` — status=success → ExecutionStep(SUCCESS) + completed_at
2. `test_step_progress_failed_persists_execution_step_with_error` — status=failed + error_msg → ExecutionStep(FAILED) + error_message
3. `test_step_progress_upserts_on_resend` — 同 step_index 重发 → upsert 不重复
4. `test_step_progress_without_step_index_skips_persistence` — 无 step_index → 不持久化（task 级 heartbeat）
5. `test_step_progress_unknown_execution_id_is_non_fatal` — 未知 execution_id → 不崩溃，不抛
6. `test_step_progress_invalid_status_falls_back_to_running` — 未知 status → 回退 RUNNING，不丢行

## 设计决策

| 决策 | 理由 |
|------|------|
| `update_or_create(task_result, step_index, defaults=...)` | 保证 retry 时 upsert 不重复；ExecutionStep.Meta 已有 `unique_together = [('task_result', 'step_index')]` |
| `database_sync_to_async` 包装 | async consumer 中调用同步 ORM 必须用此装饰器，否则 `SynchronousOnlyOperation` |
| `status_map` 回退 RUNNING | 未知 status 不应丢失整行，记录 RUNNING 让 recovery engine 仍可观察 |
| 不在 chain 模式触发 | chain step 失败直接 return，per-step 状态无意义；已有 task 级恢复覆盖 |
| 不持久化 task 级 heartbeat | 无 step_index 的 progress 帧是 task 心跳，写 ExecutionStep 会污染表 |
