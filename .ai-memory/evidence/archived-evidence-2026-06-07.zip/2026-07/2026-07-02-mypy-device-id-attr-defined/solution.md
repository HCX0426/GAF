---
maintainer: AI
source: static analysis on backend/agents/views.py
created_at: 2026-07-02
updated_at: 2026-07-03
---

## Solution

1. **Device.id**: Applied `# type: ignore[attr-defined]` (or extracted a local `device_id`) wherever a typed `Device` instance accessed `.id`.
2. **User.Role**: Replaced `from django.contrib.auth import get_user_model` + `User = get_user_model()` with a direct import `from accounts.models import User`.
3. **InputResult**: Moved `from device_bridge.platforms.base import InputResult` to the module-level imports and removed the redundant local import.
4. **mypy plugin configuration**: Changed `pyproject.toml` from `plugins = ["mypy_django_plugin"]` to the official `plugins = ["mypy_django_plugin.main"]`.
5. **mypy type fixes**:
   - Added `_probe_process(self, process_name: str) -> tuple[bool, str]` method.
   - Added `_cached_adb_path: str | None = None` class attribute and annotated `_get_adb_path` returns `str`.
   - Wrapped `psutil.pid_exists(pid)` with `bool(...)`.
   - Made `_get_available_methods` fallback signature match the imported function: `(emulator_type: str = "") -> list[str]`.
6. **ruff cleanup**:
   - Removed unused `datetime` imports.
   - Moved module-level logger below imports.
   - Added `device_bridge` to ruff `known-first-party`.
   - Fixed dead/unused variables (`process_ok`/`proc_ok`, `fmt_val`, `client_x`, `client_y`).
   - Removed extraneous f-string prefix.
   - Applied `contextlib.suppress`, ternary expressions, `_i` loop variable, and `system_protected` naming.
7. **filter_backends type annotation**: Imported `Sequence` and `BaseFilterBackend`, then explicitly typed `filter_backends: Sequence[type[BaseFilterBackend]] = [DjangoFilterBackend, SearchFilter]` to satisfy both mypy and Pylance.
