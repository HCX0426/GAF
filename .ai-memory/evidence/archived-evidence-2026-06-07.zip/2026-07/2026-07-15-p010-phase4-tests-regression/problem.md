# P-010 Phase 4 — Problem

## 背景

Phase 1-3 分别实现了：
- Phase 1: agent 端发送 task.progress 帧（含 step_index/status/error_msg）
- Phase 2: protocol consumer 持久化 ExecutionStep
- Phase 3: ExecutionStep post_save 信号触发 handle_step_failure

但各 Phase 的测试都是**隔离单元测试**，没有验证完整管线的组合：
- Phase 1 tests: mock PipelineEngine，验证 handler 发帧
- Phase 2 tests: 验证 consumer 持久化，但 on_commit 不触发
- Phase 3 tests: 直接 save ExecutionStep，不走 consumer

Phase 4 需要：
1. **E2E 测试**：真实 WS 帧 → consumer → ExecutionStep → 信号触发（验证组合正确性）
2. **全量回归**：确保 Phase 1-3 改动未破坏既有测试
3. **文档同步**：completed-features / pending-roadmap / architecture-overview

## E2E 测试设计挑战

`captureOnCommitCallbacks(execute=True)` 在 async consumer 场景下**无法捕获** `database_sync_to_async` 内部注册的 `on_commit` 回调（不同 connection context）。解决方案：不验证 `handle_step_failure` 被调用（Phase 3 已证），改为验证信号**确实触发**了（通过 `_processing_step_ids` set 成员检查）。

## 范围

- ✅ 3 E2E tests (failed/success/mixed)
- ✅ 全量回归 (133 backend + 7 agent)
- ✅ ruff check 全部改动文件
- ✅ 文档同步 (C-037 / pending-roadmap / architecture-overview §13.1)
- ❌ `npx tsc --noEmit` — 无前端改动，跳过
