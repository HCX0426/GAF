# P-010 Phase 4 — Solution

## 新增文件

### `backend/protocol/tests/test_step_failure_e2e.py`

3 个 E2E 测试，验证完整管线组合：

1. `test_e2e_failed_frame_persists_and_fires_signal` — WS frame(FAILED) → ExecutionStep(FAILED) + signal fires (`_processing_step_ids` contains step.id)
2. `test_e2e_success_frame_no_signal` — WS frame(SUCCESS) → ExecutionStep(SUCCESS) + signal does NOT fire
3. `test_e2e_mixed_steps_only_failed_fires_signal` — success(0) + failed(1) → only step 1's signal fires

**设计决策**：不 mock `handle_step_failure`，因为 `captureOnCommitCallbacks` 无法捕获 `database_sync_to_async` 内的 `on_commit`。改为检查 `_processing_step_ids` set 成员，证明信号确实触发并调度了 `on_commit`（Phase 3 单元测试已证明 `on_commit` → `handle_step_failure` 链路）。

## 文档同步

### `docs/general/completed-features.md`
- 新增 C-037 条目（P-010 全 4 Phase 完成，含 commit hash 链 + 23 new tests）

### `docs/general/pending-roadmap.md`
- P-010 状态从 ⏳ 待实现 → ✅ 完成，附方案 A 说明

### `docs/general/design/architecture-overview.md`
- §13.1 调度中心行加 "task 级 + step 级信号接入 P-010"

### `docs/general/specs/2026-07-15-p010-handle-step-failure.md`
- 阶段状态表全 ✅ + Phase 3 hash backfilled (`7285bd30`)

## 测试统计

| Phase | 测试文件 | 测试数 | 状态 |
|-------|---------|--------|------|
| 1 | `agent/tests/test_pipeline_step_progress.py` | 7 | ✅ |
| 2 | `backend/protocol/tests/test_step_progress_persistence.py` | 6 | ✅ |
| 3 | `backend/tasks/tests/test_recovery_signal.py::TestStepRecoverySignal` | 7 | ✅ |
| 4 | `backend/protocol/tests/test_step_failure_e2e.py` | 3 | ✅ |
| **Total new** | | **23** | ✅ |

## 回归测试

| 套件 | 测试数 | 状态 |
|------|--------|------|
| `backend/protocol/tests/` + `backend/tasks/tests/test_recovery_signal.py` | 133 | ✅ all pass |
| `agent/tests/test_pipeline_step_progress.py` | 7 | ✅ all pass |
| **Total regression** | **140** | **0 failures** |

## Ruff

所有 P-010 改动文件 ruff 0 errors：
- `backend/protocol/consumers.py`
- `backend/protocol/tests/test_step_progress_persistence.py`
- `backend/protocol/tests/test_step_failure_e2e.py`
- `backend/tasks/signals.py`
- `backend/tasks/tests/test_recovery_signal.py`
- `agent/src/core/orchestrator.py` (Phase 1)
- `agent/src/protocol/handler.py` (Phase 1)
- `backend/protocol/schemas.py` (Phase 1)
