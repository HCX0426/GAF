# spec34 Phase 4 — Solution

## 文件清单 (5 个)

### 1. `frontend/src/i18n/locales/auditLog.ts` (修改)

每个 locale (zh-CN / en-US / ja-JP / ko-KR) 新增 30 个 `auditLog.resource_*` 键:

- agent / agent_token / pipeline / scheduled_task / task_chain / task_folder /
  custom_task / recording / template_version / template_annotation / tag / plugin /
  time_window / notification / webhook_config / alert_rule / monitor_rule /
  agent_session / qa_session / qa_message / crash_report / debug_log_archive /
  game_state_rule / task_execution / user_session / game_account_group /
  rotation_rule / llm_config / app_settings / unattended_strategy /
  device_group / marketplace

4 locale × 30 key = 120 entries。

### 2. `frontend/src/pages/System/AuditLogPage.tsx` (修改)

`RESOURCE_TYPE_LABEL_KEYS` dict 从 8 项扩展到 38 项, 与 `AuditResourceType.all_values()`
一一对应。

### 3. `backend/gaf_core/tests/test_audit_i18n_meta.py` (新建)

5 个 meta-test:
1. `test_i18n_file_exists` — auditLog.ts 存在
2. `test_all_backend_values_have_i18n_keys` — AuditResourceType 38 值在 4 locale 都有对应 key
3. `test_no_orphan_i18n_keys` — 反向: 每个 i18n key 都映射到真实 backend value (无孤儿 key)
4. `test_backend_values_are_unique` — AuditResourceType 值唯一 (无重复)
5. `test_all_locales_have_same_key_set` — 4 locale key set 完全相同

实现细节:
- `_LOCALE_BLOCK_RE` 正则匹配 `'zh-CN': {` 等 locale block opener
- `_RESOURCE_KEY_RE` 正则匹配 `'auditLog.resource_xxx': 'some text'`
- `_parse_i18n_keys_by_locale(text)` 返回 `{locale: {keys}}` dict
- 路径解析: `Path(__file__).resolve().parents[3]` 从 tests/ 到仓库根

### 4. `docs/standards/api-contract.md` (修改)

新增 §16 审计日志章节, 6 子节:
- §16.1 数据模型 (7 字段表)
- §16.2 resource_type 合法取值 (38 项 + 新增流程)
- §16.3 details 字段敏感字段保护 (deny-list + 调用方扩展)
- §16.4 接入模式 (3 种: AuditMixin / 显式 log_audit / @audit_action)
- §16.5 接入统计 (15 app × 4 列表)
- §16.6 验证机制 (31 mixin tests + 5 i18n meta-test + 1149 全量回归)

### 5. `docs/general/tech-debt/active.md` (修改)

- TD-259 #11 标 ✅ FIXED (spec34, 4 Phase 详情)
- 顶部 TD-259 清单行更新 "共 26 项闭环"
- 底部 TD-259 进度行更新

### 6. `docs/general/completed-features.md` (修改)

新增 C-045 条目: spec34 AuditLog P0 接入 (4 Phase 详情 + 验证 + 完成时间)。

### 7. `.trae/specs/2026-07-19-spec34-auditlog-p0-wire-to-viewsets.md` (修改)

状态表 Phase 4 标 ✅, 整体 Status 改 "Done (4 Phase all complete)"。

## 关键设计决策

### 为什么用 meta-test 而非 lint rule?
meta-test 可以做跨语言 (Python + TypeScript) 一致性校验, lint rule 难以跨文件类型。
meta-test 还能跑在 CI 上, 阻止任何一方单独修改 (backend 加常量必须同步前端 i18n)。

### 为什么 4 locale 都要完整?
AuditLogPage 用 `t(key)` 查找, 缺失的 locale 会 fallback 到 key 本身 (如
`auditLog.resource_agent`), 用户体验差。强制 4 locale 完整避免漂移。

### 为什么 deny-list 而非 allow-list?
- allow-list 需列举所有合法字段, 维护成本高 (40+ ViewSet, 字段数 100+)
- deny-list 集中管理已知敏感字段名 (password/token/...), 误判风险低
- 调用方可通过 `extra_sensitive` 临时扩展 (per-resource)
