# spec34 Phase 4 — Problem

## 背景
Phase 3 完成后, 后端 114 个接入点已就位, 但前端 i18n 只覆盖 8 个 resource_type
(原 AuditLogPage 已有), 30 个新 resource_type 在 UI 中会渲染为 raw slug。

## Phase 4 范围
1. 扩展前端 i18n (4 locale × 30 new key = 120 entries)
2. 扩展 AuditLogPage.tsx 的 RESOURCE_TYPE_LABEL_KEYS
3. 写 meta-test 强制 AuditResourceType ↔ auditLog.ts 一一对应 (防漂移)
4. api-contract.md §16 文档新增审计日志章节
5. 全量回归 + TD-259 #11 标 ✅

## 验收门槛
- 5/5 i18n meta-test pass
- 4 locale × 38 key (8 已有 + 30 新) 完整
- api-contract.md §16 文档完整
- TD-259 #11 标 ✅
- 全量 backend tests 无 regression
