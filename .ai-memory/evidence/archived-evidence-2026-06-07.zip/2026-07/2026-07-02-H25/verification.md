# H25 Verification

Commands run and results:

- `pytest protocol/tests/test_message_frame.py agents/tests/ -v` → 82 passed
- `ruff check protocol/tests/test_message_frame.py protocol/consumers.py agents/consumers.py` → all checks passed
- `cd frontend && npx tsc --noEmit` → passed (no output)
- Commit: `e527ac5 fix(ws): unify WebSocket protocol on payload with legacy data fallback (H25)`
