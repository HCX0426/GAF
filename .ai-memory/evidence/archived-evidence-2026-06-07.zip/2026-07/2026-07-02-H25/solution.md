# H25 Solution

1. Fixed `TestFrontendConsumer` tests:
   - Added `query_string = b'token=dummy'` so `_extract_access_token()` returns a token.
   - Replaced the synchronous `lambda` mock with an `async` mock for `_verify_access_token` so `await self._verify_access_token(token)` works.
   - Imported `get_channel_layer()` and used `channel_layer.group_send("dashboard", ...)` to trigger `agent_heartbeat` / `agent_status` broadcast handlers.

2. Cleaned up lint errors in touched files:
   - `agents/consumers.py`: unused datetime imports, unused JWT imports/variables, unused loop variable, unnecessary `dict()` call, SIM105 `try/except/pass` blocks.
   - `protocol/consumers.py`: SIM105 heartbeat cancellation, trailing newline.
   - `protocol/tests/test_message_frame.py`: B017 blind `Exception` assertions replaced with `serializers.ValidationError`, trailing newline.

3. Verified the WebSocket protocol unification remains intact: canonical `payload` field is emitted, legacy `data` is normalized to `payload`.
