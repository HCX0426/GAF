# H25 Problem

FrontendConsumer tests for the WebSocket protocol unification (H25) failed with TimeoutError and AssertionError:

1. `test_connect_welcome_uses_payload` failed because `connected` was False — the test bypassed JWT verification but did not provide any token in the WebSocket scope, so `FrontendConsumer.connect()` closed the connection with code 4003.
2. `test_broadcast_agent_heartbeat_uses_payload` and `test_broadcast_legacy_data_fallback` timed out because they sent JSON directly to the consumer via `send_json_to`, but `FrontendConsumer.receive()` is a no-op; broadcast messages are delivered through the channel layer, not via the WebSocket receive path.
3. Several lint errors (B017, SIM105, C408, N806, F841, W292) existed in the touched files.
