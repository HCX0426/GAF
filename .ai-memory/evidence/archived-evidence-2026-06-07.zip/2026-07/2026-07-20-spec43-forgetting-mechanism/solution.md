---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, solution-step, evidence-solution, forgetting, archive]
solution: spec-43 solution — 3 Phase 实施: Phase 1 ForgetPolicy 类 + 11 单元测试 / Phase 2 forget_expired 集成 + §0.5 步骤 2.5 + 3 集成测试 / Phase 3 3 闭环测试 + 软上限 800 警告
related_files:
  - scripts/governance/doc_health_forget.py
  - scripts/governance/doc_health_consumed.py
  - .trae/skills/gaf-orchestrator/SKILL.md
  - scripts/tests/test_doc_health_forget.py
created_by: AI
last_updated: 2026-07-20
---
## Solution（解决步骤）

1. **Phase 1**: 创建 `scripts/governance/doc_health_forget.py` (167 行) 定义 `ForgetPolicy` 类作为遗忘策略单一权威源:
   - `_RETENTION_DAYS = {("P0", 0): 90, ("P0", 1): None, ("P1", 0): 30, ("P1", 1): 90}` (None = 永留)
   - `_HARD_CAP = 1000` 硬上限
   - 4 方法: `should_forget(entry)` / `forget_expired(consumed)` / `enforce_hard_cap(consumed)` / `_parse_iso(ts)`
   - `__init__(now_fn=None)` 注入测试用 FIXED_NOW 实现确定性验证
   - 11 单元测试覆盖 5 优先级策略 + invalid timestamp + forget_expired splits + enforce_hard_cap 3 场景

2. **Phase 2**: 修改 `scripts/governance/doc_health_consumed.py` 在 `ConsumedTracker` 类末尾追加 `# ---- Forgetting (spec-43 Phase 2) ----` 区段:
   - `forget_expired()`: lazy import ForgetPolicy → forget_expired + enforce_hard_cap → save(kept) + _archive(forgotten) → 返回 `(forgotten_count, kept_count)`
   - `_archive(forgotten)`: 月度分片 `.cache/doc_health_consumed_archive_YYYYMM.json`, 合并非覆盖, 原子写 (tmp + `os.replace`)
   - 在 `gaf-orchestrator/SKILL.md` §0.5 步骤 2 (Read consumed.json) 之后插入步骤 2.5 调用 `forget_expired()`, 不阻塞主流程
   - 3 集成测试: `forget_expired_integration` + `archive_created` + `archive_merges`
   - 跑 `python scripts/bootstrap/sync_skills.py --check` 验证 Decision Tree hash 未破坏

3. **Phase 3**: 追加 3 闭环测试 + `load()` 软上限警告:
   - `test_hard_cap_force_forget_in_integration`: 验证 enforce_hard_cap 在集成环境强制遗忘 priority 5
   - `test_forget_does_not_touch_patch_failed`: 验证 patch_failed=true entry 永不被遗忘
   - `test_full_lifecycle`: mark_consumed → forget_expired → archive → save 完整闭环
   - 在 `doc_health_consumed.py` `load()` 方法 return 前加 `if len(issues) > 800: print(..., file=sys.stderr)` 软上限警告 (80% of hard cap, 不影响返回值)

4. **全量回归**: 跑 `pytest scripts/tests/test_doc_health_*.py --tb=short -q` 验证 121 tests PASS (47 spec-41 + 57 spec-42 + 17 spec-43) in 7.79s

5. **状态表更新**: 在 `.trae/specs/2026-07-20-spec43-forgetting-mechanism-design.md` 阶段状态表把 3 Phase 从 ⏳ 改为 ✅ + frontmatter status 改为 ✅ done + 追加全量回归 evidence
