---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, verification-step, evidence-verification, forgetting, pytest]
solution: spec-43 verification — 121 tests PASS in 7.79s / doc_health_check.py 0.722s / ForgetPolicy.should_forget 0.0029ms/call / sync_skills.py --check 通过 / 3 Phase 两阶段审查全 ✅ PASS
related_files:
  - scripts/tests/test_doc_health_forget.py
  - scripts/governance/doc_health_forget.py
  - scripts/governance/doc_health_consumed.py
  - .trae/specs/2026-07-20-spec43-forgetting-mechanism-design.md
created_by: AI
last_updated: 2026-07-20
---
## Verification（验证）

$ cd d:\code\GAF && conda run -n gaf pytest scripts/tests/test_doc_health_forget.py --tb=short -q
  → 17 passed in 0.41s (spec-43 17 tests: Phase 1 11 unit + Phase 2 3 integration + Phase 3 3 closed-loop)

$ cd d:\code\GAF && conda run -n gaf pytest scripts/tests/test_doc_health_consumed.py scripts/tests/test_doc_health_patch.py scripts/tests/test_doc_health_check.py scripts/tests/test_doc_health_forget.py --tb=short -q
  → 121 passed in 7.79s (47 spec-41 + 57 spec-42 + 17 spec-43, 全量回归 PASS)

$ cd d:\code\GAF && conda run -n gaf python scripts/governance/doc_health_check.py --no-fail
  → exit 0, internal runtime 0.722s (< 2s budget, 不退化)

$ cd d:\code\GAF && conda run -n gaf python -c "import time; from scripts.governance.doc_health_forget import ForgetPolicy; from datetime import datetime, timezone, timedelta; p=ForgetPolicy(); now=datetime.now(timezone.utc); e={'severity':'P0','recurrence_count':0,'patch_failed':False,'consumed_at':(now-timedelta(days=100)).isoformat()}; t0=time.perf_counter(); [p.should_forget(e) for _ in range(10000)]; print(f'{(time.perf_counter()-t0)/10000*1000:.4f}ms/call')"
  → 0.0029ms/call (< 1ms budget, 性能基线达标)

$ cd d:\code\GAF && conda run -n gaf python scripts/bootstrap/sync_skills.py --check
  → exit 0, Decision Tree hash 未破坏 (§0.5 步骤 2.5 在 Decision Tree 块外)

预期:
- 121 tests PASS (含 spec-43 17 tests: should_forget 5 规则 / invalid timestamp / forget_expired splits / enforce_hard_cap 3 场景 / forget_expired_integration / archive_created / archive_merges / hard_cap_force_forget_in_integration / forget_does_not_touch_patch_failed / full_lifecycle)
- doc_health_check.py 内部 0.722s, 不因 spec-43 改动退化 (load 软上限警告仅在 > 800 entries 时触发)
- ForgetPolicy.should_forget 0.0029ms/call, 远低于 1ms budget
- sync_skills.py --check 通过 (gaf-orchestrator/SKILL.md Decision Tree hash 与 5 skills 副本同步)
- 3 Phase 两阶段审查全 ✅ PASS:
  - Phase 1: A1-A7 全过 (ForgetPolicy 类设计 + 11 单元测试 + 性能 0.0029ms)
  - Phase 2: B1-B8 全过 (forget_expired 集成 + _archive + §0.5 步骤 2.5 + 3 集成测试 + sync_skills 通过; 5 项 WARN 非阻塞: §0.5 标题未改 "(8 步)→(9 步)" / forget_expired 未捕获 _archive 异常 / 测试追加 6 而非 3 / _archive 依赖 save() 副作用 / 月度边界微秒级竞态)
  - Phase 3: 实施报告自验 (3 闭环测试 + 软上限 800 警告)
