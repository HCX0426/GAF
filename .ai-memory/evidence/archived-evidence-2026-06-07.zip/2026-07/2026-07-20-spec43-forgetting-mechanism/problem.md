---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, problem-step, evidence-problem, forgetting, consumed-growth]
solution: spec-43 problem — spec-42 飞轮交付后 consumed.json 无界增长, 估算 2600 entries/年 × 200B = 520KB/年, 10x 后突破 100ms 性能基线, 需按重要性×频率×时间三维度遗忘
related_files:
  - scripts/governance/doc_health_forget.py
  - scripts/governance/doc_health_consumed.py
  - .cache/doc_health_consumed.json
  - .cache/doc_health_consumed_archive_YYYYMM.json
created_by: AI
last_updated: 2026-07-20
---
## Problem（症状 / 触发条件）

spec-42 自我进化飞轮交付后 (commit `c4c67153` + `8883c851`), `.cache/doc_health_consumed.json` 持续累积已 consumed issues (每次对话开头 patch 成功后 mark_consumed 追加 1 个 entry)。

但 consumed.json **没有遗忘机制**: 已 patch 的 P0/P1 issue 永远留在文件中,即使该 issue 已 patch 成功且未复发。

估算增长速率 (基于 spec-42 飞轮首次真实运行):
- 5 issues/对话 × 4 对话/天 × 52 周/年 ≈ **2600 entries/年**
- 每个 entry ≈ 200B (dimension + severity + consumed_at + commit_hash + action_taken)
- 年增量 ≈ **520KB/年**

性能影响 (基于 spec-41 doc_health_check.py 0.722s 基线):
- 当前 5 entries → `ConsumedTracker.load()` < 1ms (无感)
- 10x 后 50 entries → 估算 < 5ms (仍 OK)
- 100x 后 500 entries → 估算 ~50ms (开始感知)
- 1000x 后 5000 entries → 估算 ~500ms (突破 100ms 性能基线, 退化 `doc_health_check.py` 整体性能)

且 spec-42 §3.3 设计的 recurrence 监控 (D2 lesson 触发 + F2 TD 升级) 需要扫描 consumed.json 历史 entries, 无界增长会让 recurrence 检测越来越慢。

触发条件: 用户原话 (spec-42 设计阶段) "consumed.json 增长需要有遗忘机制, 按重要性 × 触发频率 × 时间三维度制定遗忘策略" + spec-42 §1.4 非目标已声明 "遗忘机制 → spec-43"。

影响范围: `scripts/governance/doc_health_consumed.py` (新增 `forget_expired()` + `_archive()`) + `scripts/governance/doc_health_forget.py` (新建 ForgetPolicy 类) + `.trae/skills/gaf-orchestrator/SKILL.md` (§0.5 步骤 2.5) + `.cache/doc_health_consumed_archive_YYYYMM.json` (月度分片 archive)。
