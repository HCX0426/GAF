# sync_ai_memory.py --query 全 14 topic 验证 — Evidence

> **Task**: B.4 验证 sync_ai_memory.py --query 全 14 topic 可用
> **Date**: 2026-07-07
> **Spec**: `gaf-4-dimension-resume-2026-07-07.md` Phase B.4
> **Verification method**: 对 14 个 topic 各跑一次 `sync_ai_memory.py --query <topic>`，记录命中数
> **Result**: ✅ 14/14 topic 全部命中 ≥ 1（B.4 修复 concurrency 后）

---

## 验证结果

| # | Topic | 命中数 | 状态 | 备注 |
|:-:|-------|:-----:|:----:|------|
| 1 | `workflow` | 9 | ✅ | 含 N105/N108/N117/N121/N122/N124/N125/N134/N140 |
| 2 | `ai-autonomy` | 7 | ✅ | 含 N109/N111 + 误匹配（"autonomy" substring） |
| 3 | `honest-status` | 2 | ✅ | N126/N129 |
| 4 | `cross-layer-sync` | 7 | ✅ | N106/N112/N142/N143 + 误匹配 |
| 5 | `concurrency` | 2 | ✅ | N116 + N124 误匹配（"sync" substring）— **B.4 修复** |
| 6 | `testing` | 1 | ✅ | N118（其他 testing lessons 用 N133/N135/N147 编号，需用 N## 查） |
| 7 | `hook-failure` | 10 | ✅ | N91 + 误匹配（"hook" substring 命中多 hook-passthrough lessons） |
| 8 | `browser-automation` | 1 | ✅ | N131 |
| 9 | `version-compat` | 4 | ✅ | N137/N144 + 误匹配 |
| 10 | `agent-platform` | 10 | ✅ | N138/N146 + 误匹配（"agent" substring） |
| 11 | `doc-governance` | 2 | ✅ | N132/N30 |
| 12 | `api-design` | 4 | ✅ | N136 + 误匹配（"api" substring） |
| 13 | `agent-protocol` | 10 | ✅ | N145/N148 + 误匹配（"agent" substring） |
| 14 | `pipeline` | 2 | ✅ | archived-early 文件仍被扫到（sync_ai_memory 扫子目录） |
| 15 | `spec` | 4 | ✅ | archived-early 文件 + 误匹配 |

**总计**: 14/14 topic 全部命中 ≥ 1 ✅

---

## 修复记录

### `concurrency` topic 修复 (Task B.4)

**问题**: `concurrency` topic 命中 0 条，因为 `symptom_synonyms.py` 没有 `concurrency` category。

**根因**: N116 lesson 创建时（2026-06-16）未在 symptom_synonyms.py 注册 `concurrency` category，导致后续 `--query concurrency` 无法匹配。

**修复**: 在 `scripts/symptom_synonyms.py` L73-74 新增 `concurrency` category：
```python
# 🆕 v9.0 Task B.4: concurrency topic (N116)
"concurrency": ["并发", "concurrent", "race condition", "sync race", "R-M-W", "sync_lock"],
```

**验证**: 修复后 `--query concurrency` 命中 2 条（N116 预期 + N124 误匹配可接受）。

---

## 已知问题（非本 task 范围）

1. **archived-early/ 子目录仍被 sync_ai_memory 扫描**: `pipeline` 和 `spec` topic 命中包含 archived-early/ 下的文件。这些文件已归档但仍被索引。
   - **影响**: 低（archived 文件仍含相关 symptom，查询命中不影响正确性）
   - **修复方案**: 后续可在 sync_ai_memory.py 加排除 `archived-early/` 子目录的逻辑（TD 候选）

2. **误匹配较多**: `hook-failure` / `agent-platform` / `agent-protocol` 等 topic 命中 10 条，其中多数是 substring 误匹配（如 "agent" 匹配所有含 "agent" 的 symptom）。
   - **影响**: 中（AI 查询时需人工筛选）
   - **修复方案**: 后续可改进 expand_query 的匹配精度（要求 whole word 匹配而非 substring）（TD 候选）

---

## 引用文件

- `scripts/sync_ai_memory.py` — 查询工具
- `scripts/symptom_synonyms.py` — 同义词字典（B.4 修复 concurrency category）
- `.ai-memory/lessons/README.md` — 14 topic 分类索引
- `.ai-memory/lessons/2026-06-16-n116-m1g-concurrency-and-tier-benchmark.md` — N116 concurrency lesson
