---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-25-logging-pipeline-hardening-spec/
load_when: [evidence, 3-step-evidence, spec, logging, pipeline, race-condition]
priority: high
symptom: [kb:logging-pipeline-hardening, jsonl-gap, click-race, ai-diagnostic-blindspot, db-boundary]
solution: Problem — AI 无法从日志完整追踪 bug；点击-导航竞态未防护；数据库承载临时日志
related_files:
  - .ai-memory/evidence/2026-07-25-logging-pipeline-hardening-spec/solution.md
  - .ai-memory/evidence/2026-07-25-logging-pipeline-hardening-spec/verification.md
  - docs/specs/active/2026-07-25-logging-pipeline-hardening.md
  - agent/src/utils/structured_logger.py
  - agent/src/engine/nodes/click.py
  - agent/src/core/wait_freezes.py
  - backend/gaf_ai/agent/tools.py
created_by: AI
last_updated: 2026-07-25
---
## Problem（症状 / 触发条件）

**现象**：AI 诊断 pipeline 失败时，无法定位到具体 node_id / 节点类型 / 错误码；点击后画面未跳转就开始下一步，导致后续识别节点读到旧画面而失败；ReAct Agent 拿不到截图二进制，只能看到路径字符串。

**触发条件**：
1. 任何 pipeline 失败时调用 AI 诊断（`backend/gaf_ai/agent/views.py:76` 的 ReAct Agent 或 `agent/src/core/orchestrator.py:1033-1051` 的即时诊断）
2. ClickNode 执行后下一节点是识别类节点（template_match / ocr），且设备/UI 渲染慢于节点切换间隔
3. `LogEntry` / `TraceSpan` 表持续累积临时性日志数据，导致数据库承载非持久化数据

**影响范围**：
- `agent/src/utils/structured_logger.py` — JSONL 缺 click 坐标 / OCR 文本 / variables_snapshot / previous_node_id / error_code
- `agent/src/engine/nodes/click.py:106-198` — fire-and-forget，零画面变化验证
- `agent/src/core/wait_freezes.py:125-170` — `wait_for_change` 已实现但零调用
- `backend/gaf_ai/agent/tools.py` — 4 个内置工具与 ContextCollector 解耦，拿不到截图二进制
- `backend/gaf_core/handlers.py` / `backend/tracing/middleware.py` — 临时日志写入 DB
