---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-25-logging-pipeline-hardening-spec/
load_when: [evidence, 3-step-evidence, spec, logging, pipeline, race-condition]
priority: high
symptom: [kb:logging-pipeline-hardening, jsonl-gap, click-race, ai-diagnostic-blindspot, db-boundary]
solution: Verification — 规格文档 commit 通过 pre-commit hooks
related_files:
  - .ai-memory/evidence/2026-07-25-logging-pipeline-hardening-spec/problem.md
  - .ai-memory/evidence/2026-07-25-logging-pipeline-hardening-spec/solution.md
  - docs/specs/active/2026-07-25-logging-pipeline-hardening.md
created_by: AI
last_updated: 2026-07-25
---
## Verification（验证）

$ git log -1 --stat docs/specs/active/2026-07-25-logging-pipeline-hardening.md

预期：commit 成功，文件 `docs/specs/active/2026-07-25-logging-pipeline-hardening.md` 被加入，行数约 890 行

$ python scripts/check_big_change.py --staged --json

预期：`is_big: true`，`diff_lines` > 500，B2 evidence 已生成（`.cache/b2_acknowledged.json`）

$ git diff HEAD~1 -- docs/specs/active/2026-07-25-logging-pipeline-hardening.md | head -20

预期：显示规格文档前 20 行 diff，包含标题、日期、状态字段
