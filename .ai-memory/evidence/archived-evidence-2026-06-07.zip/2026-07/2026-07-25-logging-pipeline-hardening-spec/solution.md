---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-25-logging-pipeline-hardening-spec/
load_when: [evidence, 3-step-evidence, spec, logging, pipeline, race-condition]
priority: high
symptom: [kb:logging-pipeline-hardening, jsonl-gap, click-race, ai-diagnostic-blindspot, db-boundary]
solution: Solution — 4 阶段实施计划（竞态修复 + 日志补全 + 截图双保留 + DB 边界）
related_files:
  - .ai-memory/evidence/2026-07-25-logging-pipeline-hardening-spec/problem.md
  - .ai-memory/evidence/2026-07-25-logging-pipeline-hardening-spec/verification.md
  - docs/specs/active/2026-07-25-logging-pipeline-hardening.md
created_by: AI
last_updated: 2026-07-25
---
## Solution（解决步骤）

1. 写规格文档 `docs/specs/active/2026-07-25-logging-pipeline-hardening.md`，覆盖 4 阶段实施计划
2. 阶段 1（竞态修复 + 日志补全）：实现 `wait_for_change_lightweight`（`agent/src/core/wait_freezes.py`），ClickNode 集成默认防护（`agent/src/engine/nodes/click.py`），`extract_result_fields` 补 click/ocr/wait/swipe_until 分支（`agent/src/utils/structured_logger.py`），`AutoResult` 增加 node_id/node_type/error_code（`agent/src/core/result.py`）
3. 阶段 2（截图双保留 + 视觉工具）：`DebugImageSaver` 增加原图保存到 `screenshots/raw/`（`agent/src/utils/debug_image_saver.py`），新增 `get_screenshot_base64` + `get_structured_log` 工具（`backend/gaf_ai/agent/tools.py`）
4. 阶段 3（post_verify + 恢复增强）：抽出 `agent/src/core/verify.py` 模块，PipelineEngine 集成 post_verify，`interface_recovery` 换路径策略
5. 阶段 4（DB 边界 + 异常检测闭环）：`DatabaseLogHandler` → `FileLogHandler`（`backend/gaf_core/handlers.py`），异常检测改扫 JSONL（`backend/gaf_ai/views_anomaly.py`），每天 2 点定时扫描
