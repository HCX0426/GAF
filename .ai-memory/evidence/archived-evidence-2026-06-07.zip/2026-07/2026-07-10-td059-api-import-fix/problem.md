---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-10/td059-api-import-fix/
load_when: [evidence, 3-step-evidence, TD-059, frontend, api-import]
priority: medium
symptom: [td-059, frontend-import-error, api-module-mismatch, unattended-strategy]
solution: Fix UnattendedStrategyPanel import path and function name to match existing API client
related_files:
  - frontend/src/components/Settings/UnattendedStrategyPanel.tsx
  - frontend/src/api/misc.ts
  - docs/general/tech-debt-register.md
created_by: AI
last_updated: 2026-07-10
---
## Problem（症状 / 触发条件）

TD-059 记录前端组件引用 API 模块中不存在的函数。本轮验证发现 `UnattendedStrategyPanel.tsx` 仍在从 `@/api/settings` 导入 `fetchUnattendedStrategy` / `updateUnattendedStrategy`：

1. 现象：`@/api/settings` 未导出这两个函数，构建/运行时会触发模块解析错误。
2. 触发条件：打开 `/system/settings/unattended-strategy` 页面或执行 `npx tsc --noEmit`。
3. 影响范围：无人值守策略配置面板无法加载。

`AnalyticsDashboard` 部分已在前一轮修复；`UnattendedStrategyPanel` 部分遗漏。
