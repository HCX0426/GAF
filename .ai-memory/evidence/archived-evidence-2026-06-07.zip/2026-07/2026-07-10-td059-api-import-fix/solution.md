---
maintainer: AI
source: GAF/.ai-memory/evidence/2026-07-10/td059-api-import-fix/
load_when: [evidence, 3-step-evidence, TD-059, frontend, api-import]
priority: medium
symptom: [td-059, frontend-import-error, api-module-mismatch, unattended-strategy]
solution: Fix UnattendedStrategyPanel import path and function name to match existing API client
related_files:
  - frontend/src/components/Settings/UnattendedStrategyPanel.tsx
  - frontend/src/api/misc.ts
  - docs/general/tech-debt-register.md
created_by: AI
last_updated: 2026-07-10
---
## Solution（解决步骤）

1. 确认 `@/api/misc.ts` 已导出 `fetchUnattendedStrategy` / `saveUnattendedStrategy`。
2. 修改 `frontend/src/components/Settings/UnattendedStrategyPanel.tsx`：
   - 导入路径从 `@/api/settings` 改为 `@/api/misc`。
   - 保存函数从 `updateUnattendedStrategy` 改为 `saveUnattendedStrategy`。
3. 更新 `docs/general/tech-debt-register.md` 中 TD-059 状态为 ✅ FIXED。
