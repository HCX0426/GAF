---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-09/fix-log-center-recovery-log-pagination/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [frontend, log-center, recovery-log, TypeError, rawData.some, white-screen]
solution: Set RecoveryLogViewSet.pagination_class = None to return a plain array matching frontend expectations.
related_files:
  - backend/scheduler/views.py
  - frontend/src/api/scheduler.ts
  - frontend/src/pages/Ops/Logs/SpecialtyLogTabs.tsx
  - frontend/src/pages/Ops/Monitors/RecoveryLogTab.tsx
  - backend/scheduler/tests/test_recovery_log_api.py
created_by: AI
last_updated: 2026-07-09
---
## Solution（解决步骤）

1. 在 `backend/scheduler/views.py` 的 `RecoveryLogViewSet` 上添加 `pagination_class = None`。
2. 保留现有 `get_queryset` 过滤与 `-created_at` 排序逻辑不变。
3. 运行后端 API 测试：`pytest backend/scheduler/tests/test_recovery_log_api.py -v`。
4. 浏览器登录验证：运行 `.trash/check_logs_page.py` 与 `.trash/check_log_tabs.py`，确认所有 7 个标签页无 `rawData.some` 报错。
