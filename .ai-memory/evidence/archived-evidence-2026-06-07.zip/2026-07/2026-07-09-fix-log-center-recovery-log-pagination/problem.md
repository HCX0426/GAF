---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-09/fix-log-center-recovery-log-pagination/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [frontend, log-center, recovery-log, TypeError, rawData.some, white-screen]
solution: RecoveryLogViewSet used DRF global pagination and returned {count, results}, but fetchRecoveryLogs expected RecoveryLogEntry[], causing Ant Table to crash.
related_files:
  - backend/scheduler/views.py
  - frontend/src/api/scheduler.ts
  - frontend/src/pages/Ops/Logs/SpecialtyLogTabs.tsx
  - frontend/src/pages/Ops/Monitors/RecoveryLogTab.tsx
  - backend/scheduler/tests/test_recovery_log_api.py
created_by: AI
last_updated: 2026-07-09
---
## Problem（症状 / 触发条件）

1. 用户报告点击“6 条日志”后日志中心页面白屏，无法打开。
2. 浏览器控制台报错 `TypeError: rawData.some is not a function`。
3. 触发条件：后端 `RecoveryLogViewSet` 未禁用分页，DRF 全局 `PageNumberPagination`（PAGE_SIZE=20）使其返回 `{count, next, previous, results}` 对象；前端 `fetchRecoveryLogs()` 声明返回 `RecoveryLogEntry[]`，`SpecialtyLogTabs.tsx` 直接把整个对象传给 `<Table dataSource={res ?? []} />`，Ant Design Table 内部对非数组调用 `.some()` 崩溃。
4. 影响范围：日志中心“恢复日志”标签页及 Ops > Monitors 的 RecoveryLogTab。
