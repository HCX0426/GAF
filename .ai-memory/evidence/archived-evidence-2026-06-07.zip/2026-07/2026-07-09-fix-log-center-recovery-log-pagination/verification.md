---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-09/fix-log-center-recovery-log-pagination/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [frontend, log-center, recovery-log, TypeError, rawData.some, white-screen]
solution: RecoveryLogViewSet.pagination_class = None; pytest + Playwright browser checks passed.
related_files:
  - backend/scheduler/views.py
  - frontend/src/api/scheduler.ts
  - frontend/src/pages/Ops/Logs/SpecialtyLogTabs.tsx
  - frontend/src/pages/Ops/Monitors/RecoveryLogTab.tsx
  - backend/scheduler/tests/test_recovery_log_api.py
created_by: AI
last_updated: 2026-07-09
---
## Verification（验证）

```powershell
cd d:\code\GAF\backend
conda run -n gaf pytest scheduler/tests/test_recovery_log_api.py -v
```

实际输出：10 passed, 1 warning in 13.97s

```powershell
cd d:\code\GAF
conda run -n gaf python .trash/check_logs_page.py
conda run -n gaf python .trash/check_log_tabs.py
```

实际结果：
- 日志中心 `/ops/log-center` 页面可正常加载，URL 正确。
- 7 个标签页（统一时间线、应用日志、审计日志、恢复日志、消息帧日志、LLM 调用日志、崩溃报告）全部可点击。
- 控制台不再出现 `TypeError: rawData.some is not a function`。
- 仅存在 antd Alert/Drawer 的 deprecation warnings，不影响功能。
