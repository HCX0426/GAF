---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-22-td324-n181-retirement-eval/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-td324, n181-retirement, manual-eval-gap]
solution: TD-324 problem — N181 月度退役机制已建立但无自动化评估脚本, 依赖 AI/人工手动检查
related_files:
  - .ai-memory/evidence/2026-07-22-td324-n181-retirement-eval/solution.md
  - .ai-memory/evidence/2026-07-22-td324-n181-retirement-eval/verification.md
  - .ai-memory/meta/failure-modes.md
  - .trae/rules/project_rules.md
created_by: AI
last_updated: 2026-07-22
---
## Problem（症状 / 触发条件）

N181 月度退役机制已建立 (spec-59-C 2026-07-21, spec-62 TD-311 强化):
- 月度评估 failure-modes.md §Active N## 索引, 识别可退役候选
- Active N## > 70 硬阈值紧急评估
- 退役条件 A/B/C (连续 3 spec 未触发 / 已被新 N## 覆盖 / AI 默认行为已符合)

但机制落地存在 2 个缺口:
1. **无自动化评估脚本**: 退役条件 A (连续 3 spec 未提及) 需手动 grep `.trae/specs/*.md`, 依赖 AI/人工记忆, 易遗漏
2. **gaf_init.sh 无 Active > 70 警告**: L1 hard-load failure-modes.md 只统计 N## 总行数 (含 Retired/Dormant), 不区分 Active 段, 无法触发紧急评估提示

影响: 若不主动退役将触发紧急评估 (Active 已达 60, 距 70 硬阈值仅 10 条余量); N181 机制仅执行 1 次 (N165+N170 spec-59-D), 月度评估的执行频率和效果待观察, 缺自动化工具支撑难以持续.

触发条件: 月度评估时点 / Active N## 接近 70 阈值时, AI 需手动扫描 spec 文件统计 N## 提及次数.
