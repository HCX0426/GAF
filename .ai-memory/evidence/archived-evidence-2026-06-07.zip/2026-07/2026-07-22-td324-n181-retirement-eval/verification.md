---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-22-td324-n181-retirement-eval/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-td324, n181-retirement, verification-passed]
solution: TD-324 verification — 12/12 tests passed + n181_retirement_eval.py 真实 repo 跑通 + gaf_init.ps1 N181 警告触发
related_files:
  - .ai-memory/evidence/2026-07-22-td324-n181-retirement-eval/problem.md
  - .ai-memory/evidence/2026-07-22-td324-n181-retirement-eval/solution.md
  - scripts/tests/test_n181_retirement_eval.py
  - scripts/governance/n181_retirement_eval.py
created_by: AI
last_updated: 2026-07-22
---
## Verification（验证）

$ conda run -n gaf python -m pytest scripts/tests/test_n181_retirement_eval.py -v

预期: 12/12 passed
实际输出:
```
scripts/tests/test_n181_retirement_eval.py::test_parse_active_n_ids_returns_non_empty_for_real_repo PASSED [  8%]
scripts/tests/test_n181_retirement_eval.py::test_parse_active_n_ids_returns_empty_for_missing_file PASSED [ 16%]
scripts/tests/test_n181_retirement_eval.py::test_parse_active_n_ids_parses_only_active_section PASSED [ 25%]
scripts/tests/test_n181_retirement_eval.py::test_scan_recent_specs_counts_mentions_correctly PASSED [ 33%]
scripts/tests/test_n181_retirement_eval.py::test_scan_recent_specs_respects_recent_count PASSED [ 41%]
scripts/tests/test_n181_retirement_eval.py::test_scan_recent_specs_returns_empty_for_missing_dir PASSED [ 50%]
scripts/tests/test_n181_retirement_eval.py::test_find_retirement_candidates_returns_zero_mention_n_ids PASSED [ 58%]
scripts/tests/test_n181_retirement_eval.py::test_find_retirement_candidates_returns_empty_when_all_mentioned PASSED [ 66%]
scripts/tests/test_n181_retirement_eval.py::test_find_retirement_candidates_handles_missing_keys PASSED [ 75%]
scripts/tests/test_n181_retirement_eval.py::test_render_report_contains_candidates_and_stats PASSED [ 83%]
scripts/tests/test_n181_retirement_eval.py::test_render_report_handles_no_candidates PASSED [ 91%]
scripts/tests/test_n181_retirement_eval.py::test_render_report_shows_threshold_exceeded_warning PASSED [100%]
============================= 12 passed in 0.11s ==============================
```

$ conda run -n gaf python scripts/governance/n181_retirement_eval.py

预期: 输出 Active N## 计数 + 退役候选清单 (条件 A)
实际输出:
```
📊 N181 月度退役评估报告
============================
Active N## 计数: 60
退役候选 (条件 A, 最近 3 spec 未提及): 58
  - N91, N92, N93, ... (58 个候选)

⚠️ Active N## 60 ≤ 70 阈值 (硬阈值未超限, 常规月度评估)
```

$ pwsh scripts/gaf_init.ps1 --fast

预期: §3.7.2 N181 警告段正确触发 (N_COUNT=77 含 Retired, > 70 → WARN)
实际输出:
```
✅ [fast] L1 hard-load OK: failure-modes.md (77 entries, 索引格式)
⚠️ [fast] N181 紧急评估: Active N## 77 > 70 硬阈值
   (project_rules.md §4.12) — 跑 python scripts/governance/n181_retirement_eval.py 评估退役候选
```
(注: gaf_init.ps1 的 N_COUNT=77 含 Retired/Dormant 行, 与脚本的 Active-only 60 语义不同; 作为紧急阈值触发器, 含 Retired 反而更保守, 安全)

$ conda run -n gaf python scripts/governance/sync_tech_debt_counts.py

预期: README.md 计数同步 (active=13, fixed=293)
实际输出:
```
✅ sync_tech_debt_counts: updated README.md:overview-table
   active=13 fixed=293 wontfix=30 total=336
```
