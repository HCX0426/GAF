---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-22-td324-n181-retirement-eval/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-td324, n181-retirement, n181-retirement-eval-script]
solution: TD-324 solution — 新建 n181_retirement_eval.py + gaf_init.sh/ps1 §3.7.2 N181 紧急评估警告 + 12 tests
related_files:
  - .ai-memory/evidence/2026-07-22-td324-n181-retirement-eval/problem.md
  - .ai-memory/evidence/2026-07-22-td324-n181-retirement-eval/verification.md
  - scripts/governance/n181_retirement_eval.py
  - scripts/tests/test_n181_retirement_eval.py
  - scripts/gaf_init.sh
  - scripts/gaf_init.ps1
created_by: AI
last_updated: 2026-07-22
---
## Solution（解决步骤）

1. 新建 `scripts/governance/n181_retirement_eval.py` (~265 行):
   - `parse_active_n_ids(failure_modes_path)`: 按 `## Active N##` / `## Retired N##` / `## Dormant N##` 段边界解析, 只提取 Active 段 `| N91 |` 行的 N## 编号 (区分 Active/Retired/Dormant, 避免误把已退役条目算入)
   - `scan_recent_specs(specs_dir, n_ids, recent_count=3)`: 按文件名倒序取最近 N 个 spec, whole word match `\bN91\b` 统计每个 N## 提及次数 (避免 N9 误匹配 N91)
   - `find_retirement_candidates(active_n_ids, mention_map)`: 条件 A 候选 (mention_count=0, 最近 3 spec 未提及)
   - `render_report(...)`: 生成 markdown 报告 (候选清单 + 提及统计表 + 条件 B/C 提示)
   - 4 个 CLI flags: `--check` (CI 模式, 非阻塞) / `--threshold 70` (覆盖默认阈值) / `--recent-specs 3` (覆盖默认扫描数) / `--root <path>`

2. `scripts/gaf_init.sh` 加 §3.7.2 N181 紧急评估警告段 (+6 行):
   - 在 L1 hard-load failure-modes.md 之后, 检查 N_COUNT > 70 时打印警告
   - 非阻塞 (仅 WARN), 指向 `n181_retirement_eval.py` 跑详细评估
   - 注: gaf_init.sh 的 N_COUNT 是 `| N` 行总数 (含 Retired/Dormant), 与脚本的 Active-only 计数语义不同, 但作为紧急阈值触发器够用

3. `scripts/gaf_init.ps1` 同步加 §3.7.2 N181 紧急评估警告段 (+6 行, TD-320 PowerShell 等价版本), 语法适配 PowerShell

4. 新建 `scripts/tests/test_n181_retirement_eval.py` (12 tests):
   - `test_parse_active_n_ids_*` ×3 (真实 repo 非空 + 缺失文件返回空 + 只解析 Active 段不混入 Retired)
   - `test_scan_recent_specs_*` ×3 (计数正确 + recent_count 参数 + 缺失目录返回空 dict)
   - `test_find_retirement_candidates_*` ×3 (零提及候选 + 全提及空列表 + 缺 key 处理)
   - `test_render_report_*` ×3 (含候选 + 无候选 + 阈值超限警告)

5. 迁移 TD-324 从 `docs/general/tech-debt/active.md` 到 `fixed.md`, 跑 `sync_tech_debt_counts.py` 同步计数 (active=13, fixed=293, wontfix=30)

6. 条件 B/C 不自动判定 (需 AI 判断语义覆盖/默认行为符合), 仅在报告打印提示, 保持脚本职责单一.
