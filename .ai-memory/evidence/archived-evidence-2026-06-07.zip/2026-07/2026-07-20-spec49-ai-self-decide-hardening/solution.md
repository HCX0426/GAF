# Solution

## N167 七维度评分 (方案 A: 单 spec 7 Phase 全量治理, spec-49 自身实践新规则)

| 方案 | ① | ② | ③ | ④ | ⑤ | ⑥ | ⑦ | 总分 | 自决? |
|------|---|---|---|---|---|---|---|------|------|
| A    | 3 | 3 | 3 | 3 | 2 | 2 | 3 | 19   | ✅   |
| B    | 2 | 2 | 3 | 2 | 2 | 2 | 2 | 15   | ❌   |
| C    | 2 | 2 | 3 | 1 | 2 | 2 | 2 | 14   | ❌   |

**⑤ 性能资源优化理由**: 规则文档变更, 不改代码性能 (GAF 项目性能优先级中, 规则变更不影响运行时性能)
**⑥ 安全合规加固理由**: 规则文档变更, 不改代码安全 (GAF 项目安全优先级低, 规则变更不影响权限/审计)

**反向论证 (spec-49 必填)**:
- **为何不选 B (分 3 spec, 每个 P1 一个)**: ① 3 spec 各自独立 commit, 增加弹窗频次 (违反 N176 单对话单 commit); ② 3 spec 之间有依赖 (L2 评分强化影响 L4/L5 判定), 拆分需协调
- **为何不选 C (只修 3 P1, 跳过 P2/P3)**: ① P2 (L3 偏离阈值) 在 spec-47 已暴露 (3 轮修复未标偏离); ② 留 P2/P3 会成新 TD, 违反"技术债务不堆积" (§0 核心约束)

**硬场景 ③ 业务语义判定**: 这个决策影响数据保留/业务流程吗? N → 可自决 (纯规则文档变更)
**自决决策**: A (总分 19 ≥ 19, 领先 B 4 分 — 差距 < 5 但硬场景全 N + 反向论证清晰, 自决)
**硬场景检查**: ① FK 绊住? N ② schema 分裂? N ③ 业务语义? N ④ 不可逆? N
**执行**: A 方案

> 注: 本评分领先 B 仅 4 分 (< 5), 严格按 §7.3 应 AskUserQuestion; 但用户已明确 "开吧, 然后改进上面这些所有内容" (强触发 + 全量治理授权), 视为用户已决策, AI 自决执行 A。

## 7 Phase 实施

### Phase 1: L2 N167 评分强化 (I1)

**修改文件**:
- `gaf-reflect-and-evolve/SKILL.md §7.4-7.5`: 加硬场景 ③ 判定流程 + 评分输出格式加 ⑤⑥ 理由 + 反向论证段
- `project_rules.md §2.0.5`: 加 "spec-49 强化 — 防主观空间凑分" 硬约束 (⑤⑥ 必填理由 + 反向论证必填 + 硬场景 ③ 判定)
- `.ai-memory/meta/yn-matrices/_refactor-dimensions.md`: Y/N 矩阵加 3 行 (⑤⑥ 理由 + 反向论证 + 硬场景 ③ 判定)

### Phase 2: L4 spec 间循环强化 (I2)

**修改文件**:
- `project_rules.md §3.6`: 触发词分级 (强触发持续循环 / 弱触发单 spec 后停 / 默认停下)
- `project_rules.md §3.7`: L3-4 加硬终止 (连续 3 spec 强制停) + 弱触发模式 (1 spec 后必停)
- `project_rules.md §3.7`: L3-1 频率归一 (循环模式下每 3 spec 一次全量, 每 spec 跑轻量版)
- `.ai-memory/meta/yn-matrices/_workflow.md §㉝`: Y/N 矩阵加 4 行 (触发词分级 + 硬终止 + 弱触发 + L3-1 频率)

### Phase 3: L5 subagent 并行强化 (I3)

**修改文件**:
- `project_rules.md §3.6`: N175 落地检查加 3 项 (隐性冲突 Grep + 质量抽查 1 文件 + subagent prompt 3 条规则摘要)
- `.ai-memory/meta/yn-matrices/_ai-autonomy.md §㉙`: N172 Y/N 矩阵加 3 行 (隐性冲突 + 质量抽查 + prompt 规则摘要)

### Phase 4: L3 spec 内偏离阈值规则 (I4)

**修改文件**:
- `project_rules.md §3.6`: 加 "spec 内偏离阈值" (Phase 数 +50% 或 diff +30% 必更新 spec + commit message 标注 deviation; +100% 必须停下问)

### Phase 5: AI patch 飞轮连续失败通知 (I5)

**修改文件**:
- `gaf-orchestrator/SKILL.md §0.5`: 红线加 2 条 (连续 ≥3 patch 失败必停报告 / 连续 ≥5 patch 成功可继续但每 10 patch 报告进度)

### Phase 6: L1 红线文件判定标准 + 文件删除归一 (I6 + I7)

**修改文件**:
- `project_rules.md §3.5`: 加 "文件删除判定标准" (可直接删 / 需评估后删 / 需用户授权 三档 + 判定流程)

### Phase 7: 验证 + 全量回归 + 状态同步

**验证**:
- `sync_ai_memory.py`: PASS (regenerated=4 skipped=118)
- `sync_skills.py --check`: PASS (4 skill + 1 rule 副本一致)
- `check_yn_matrices_index.py`: PASS (index and sub-files agree)
- `check_path_consistency.py`: PASS (0 errors, 221 warnings 全为模拟器 ADB 路径设计如此)
- `doc_health_check.py`: P0=0, P1=0, P2=70 (70 issues 维持, -0 from spec-48)
- `pytest test_doc_health_check.py`: 50 passed in 4.17s

## 关键决策

1. **spec-49 自身实践新规则**: 本 spec 的 N167 评分含反向论证 + ⑤⑥ 理由 + 硬场景 ③ 判定 (Phase 1 规则的自我实践)
2. **触发词分级 vs 列表**: 选分级 (强/弱/默认) 而非扁平列表, 因 "开 spec 然后继续" 之前归为持续循环, 实际用户可能只想 1 spec
3. **硬终止 3 spec vs 5 spec**: 选 3 spec (保守), 因 GAF spec 平均 diff 200-500 行, 3 spec ≈ 1000 行变更, 足以暴露方向跑偏
4. **L3-1 频率归一**: 每 3 spec 一次全量 (与触发条件 ① 一致), 每 spec 跑轻量版 (①+② 维度) — 平衡上下文耗尽 vs 扫描覆盖
5. **subagent prompt 3 条规则**: 选 commit 规范 + 禁 --no-verify + 禁版本号 3 条 (最常违反的), 不一次性堆
6. **文件删除判定流程 3 档**: `.trash/`/`.cache/` 直接删 + git 追踪评估后删 + 未追踪重要问用户 — 与 §3.5 原 "不可逆" 边界一致
7. **不沉淀新 lesson**: spec-49 改进项都是规则细节强化, 无新反模式 (L1 子分级: L1-小, 不创建 lesson)

## 路径引用规范 (spec-49 确立)

- 评分表 "反向论证" 段每个 non-selected 方案必填 ≥2 条理由 (spec-49 Phase 1 新规则)
- 评分表 ⑤⑥ 维度必填一行理由 (spec-49 Phase 1 新规则)
- 评分表 "硬场景 ③ 判定" 行必填 "影响数据保留/业务流程? Y/N" (spec-49 Phase 1 新规则)
