## Problem（症状 / 触发条件）

C3 阶段前, 前端错误上报到 backend 后只写入 Django logger `gaf_core.frontend_error` (单行文本格式), 没有按 spec §2.1.3 的 page_slug 分桶落盘到 `debug/YYYYMMDD/frontend/<page_slug>/HH/console.jsonl`。导致 AI 调试时: (1) 前端错误与其他 backend 错误混在 Django log 里, 无法按页面浏览; (2) 缺少 trace_id 字段, 无法 grep trace_id 串联 agent/backend 三端日志; (3) 缺少 page_slug 字段, 无法定位"用户在哪个页面遇到错误"。

影响范围: backend/gaf_core (FrontendErrorReportView + 新增 frontend_logger.py) + frontend/src/utils (pageSlug.ts 新增 + reportFrontendError.ts 加 trace_id/page_slug 自动采集) + frontend 测试套件。触发条件: 任何前端错误 (window.onerror / unhandledrejection / ErrorBoundary) 上报到 `/api/v2/logs/frontend-errors/` 时, 缺少 console.jsonl 落盘 + trace_id 串联。
