## Solution（解决步骤）

1. 新建 `backend/gaf_core/frontend_logger.py`: FrontendConsoleLogger 类, 复用 BackendTaskLogger 的小时桶切换 + swallow-all-exceptions 兜底契约, 写入 `debug/<YYYYMMDD>/frontend/<safe_page_slug>/<HH>/console.jsonl`; _sanitize_page_slug 在 backend 再做一次 sanitize (defense in depth — `../etc/passwd` → `.._etc_passwd` 单段目录名, 防路径逃逸)。
2. 修改 `backend/gaf_core/views.py`: 加 `get_debug_root()` helper (薄包装 `getattr(settings, "DEBUG_DIR", "./debug")`, 便于测试 patch); FrontendErrorReportView.post 接收 trace_id + page_slug, 调用 FrontendConsoleLogger 落盘, 失败时 logger.warning 但仍返回 204 (镜像 BackendTaskLogger swallow 契约)。
3. 新建 `frontend/src/utils/pageSlug.ts`: pathnameToPageSlug 实现 spec §2.1.3 规则 (去首尾 / → 切段 → 过滤纯数字 id → 用 _ 连接保留层级 → 不安全字符替换为 _ → 长度截断 40); getPageSlug 从 window.location.pathname 取, SSR 兜底 'unknown'。
4. 修改 `frontend/src/utils/reportFrontendError.ts`: fullReport 中**自动**采集 trace_id (getLastTraceId) + page_slug (getPageSlug), caller 不应也不可手动传 (测试覆盖验证 caller 传入值会被覆盖)。
5. 测试: backend `test_frontend_error_report.py` 加 6 个 C3 用例 (路径/缺 trace_id/缺 page_slug/sanitize/同小时 append/落盘失败不阻塞); frontend 新增 `pageSlug.test.ts` (10 用例) + `reportFrontendError.test.ts` (5 用例)。
