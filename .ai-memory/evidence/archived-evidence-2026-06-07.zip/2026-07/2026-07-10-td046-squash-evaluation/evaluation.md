# TD-046 — tasks/migrations squash evaluation

## Date: 2026-07-10

## Evaluation context

- 40 migration files in `backend/tasks/migrations/` (0001_initial — 0040_remove_tracespan)
- 1 data migration (0021 with RunPython `migrate_m2m_to_fk_forward`/`_reverse`)
- 14 "remove_*" cleanup migrations (0027-0040) from TD-039 model extraction
- 3 downstream cross-app dependencies:
  - `tracing.0001_initial` → `tasks.0040_remove_tracespan`
  - `pipeline.0004_pipeline_consolidate` → `tasks.0038_remove_pipeline`
  - `pipeline.0005_recording` → `tasks.0039_remove_recording`

## Squash attempt

Executed `python manage.py squashmigrations tasks 0040 --noinput`.

Result: `0001_squashed_0040_remove_tracespan.py` created (331 optimized operations from 360).

### Manual porting

Copied `migrate_m2m_to_fk_forward` and `migrate_m2m_to_fk_reverse` from 0021 into the squashed migration file. Updated the `RunPython` operation to reference the local functions instead of `tasks.migrations.0021_remove_customtask_resource_packs_and_more.*`.

### Circular dependency error

Running `python manage.py migrate --plan` after porting:

```
django.db.migrations.exceptions.CircularDependencyError:
  tasks.0001_squashed_0040_remove_tracespan,
  scheduler.0003_phase5_bindings,
  scheduler.0004_phase6_unattended_scheduler,
  scheduler.0005_alter_deviceresourcemapping_device,
  scheduler.0006_delete_deviceresourcemapping
```

### Root cause

Original migration sequence interleaves tasks and scheduler:

```
tasks.0013_task_preflight_config_... ──▶ scheduler.0003_phase5_bindings ──▶ tasks.0014_phase5_bindings
```

- `scheduler.0003_phase5_bindings` depends on `tasks.0013`
- `tasks.0014_phase5_bindings` depends on `scheduler.0003`

Squashing `tasks.0001 — tasks.0040` into one migration merges `tasks.0013` and `tasks.0014` into a single node. The interleaved dependency chain becomes a cycle:

```
tasks.squashed ──▶ scheduler.0003 ──▶ tasks.squashed  (cycle!)
```

## Decision: keep migration history

- **Risk of fixing**: would need to either (a) split the squashed migration at the `tasks.0013 | scheduler.0003 | tasks.0014-0040` boundary, or (b) refactor `scheduler.0003` to remove the `tasks.0013` dependency. Both approaches risk corrupting the migration graph.
- **Benefit of squashing**: cleaner history, faster fresh-DB `migrate` (saves ~1-2 seconds).
- **Priority**: P3 (lowest).

For a P3 TD with no production database and minimal performance impact, the risk of cross-app migration refactoring outweighs the benefit. **TD-046 closed as ❌ EVALUATED (squash not feasible without cross-app refactoring).**

## Cleanup

- Deleted `0001_squashed_0040_remove_tracespan.py`
- Verified `migrate --plan` returns "No planned migration operations" (DB intact)
- All 40 original migrations preserved unchanged
