---
maintainer: AI
source: task T09 OpenAPI-to-TypeScript type generation
created_at: 2026-07-02
---

## Problem

Frontend TypeScript types were manually maintained and often drifted from the DRF backend. Attempting to generate an OpenAPI schema with `drf-spectacular` failed for two reasons:

1. `REST_FRAMEWORK["DEFAULT_SCHEMA_CLASS"]` was not set to `drf_spectacular.openapi.AutoSchema`, so spectacular used an incompatible schema class.
2. `TemplateEffectivenessSerializer` declared `success_rate = serializers.FloatField(source='success_rate', read_only=True)`, which is redundant (the model already exposes `success_rate` as a property) and causes spectacular to raise a field collision error.

Without an automated pipeline, the frontend lacked authoritative API types and had to rely on hand-written interfaces that could become stale.
