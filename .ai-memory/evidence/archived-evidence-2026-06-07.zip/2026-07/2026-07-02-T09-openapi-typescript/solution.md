---
maintainer: AI
source: task T09 OpenAPI-to-TypeScript type generation
created_at: 2026-07-02
---

## Solution

1. Removed the redundant `success_rate` field from `TemplateEffectivenessSerializer` in `backend/tasks/serializers.py`.
2. Set `REST_FRAMEWORK["DEFAULT_SCHEMA_CLASS"]` to `drf_spectacular.openapi.AutoSchema` in `backend/config/settings/base.py`.
3. Added `openapi-typescript` as a frontend dev dependency.
4. Created `frontend/scripts/generate-api-types.js`, a cross-platform Node script that:
   - Runs Django's `spectacular` command to emit `.trash/schema.json`.
   - Feeds the schema into `openapi-typescript` to generate `frontend/src/types/api.generated.ts`.
5. Added a stable re-export namespace in `frontend/src/types/api.ts` so UI code imports `paths`/`components`/`operations` from a non-generated file.
6. Added the npm script `generate:api-types` to `frontend/package.json`.
7. Updated `docs/standards/api-contract.md` with the generation workflow and usage examples.
