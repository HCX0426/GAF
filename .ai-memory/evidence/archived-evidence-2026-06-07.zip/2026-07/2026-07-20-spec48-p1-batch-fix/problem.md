# Problem

## 现象

spec-47 commit (`929237b3`) 后,doc_health_check 报 97 issues,P0=0 但 P1=27:
- d5_frontmatter P1: 16 (frontmatter 字段缺失)
- d3_count_drift P1: 9 (硬编码数字 vs 实际计数)
- d2_bloat P1: 2 (文件行数超阈值)

## P1 模式归类

### d5_frontmatter P1 (16) — 3 类字段缺失

- 10 处 `maintainer=derived-manual` 缺 `last_manual_edit` 字段
- 3 处 `maintainer=manual` 缺 `source` 字段 (summaries/architecture-mistakes.md + code-rules.md + library-conflicts.md)
- 3 处 `maintainer=manual` 缺 `load_when` 字段 (同上 3 文件)

### d3_count_drift P1 (9) — 4 类硬编码漂移

- 4 处 `completed-features.md`: 硬编码 `10`/`1`/`26`/`27` vs actual `7`/`36`/`36`/`36` (count_yn_matrices_subfiles / count_docs_in_directory)
- 2 处 `health-checks/2026-07.md`: 硬编码 `43`/`10` vs actual `36`/`36` (含 commit hash `3dc3d10` 中 "10" 被误匹配)
- 2 处 `architecture-mistakes.md`: 硬编码 `11`/`17` vs actual `7`/`36` (历史记录 "11 个 sub-file" + "17 docs/ 文件")
- 1 处 `spec-evolution.md`: 硬编码 `16` vs actual `36`

### d2_bloat P1 (2) — 历史累积

- `docs/general/tech-debt/fixed.md` 4848 行 (阈值 2000, 2.42x) — 多 spec 修复追加未拆分
- `.trae/plans/2026-07-19-spec41-doc-health-checker.md` 2089 行 (阈值 1000, 2.09x) — 已完成 spec plan

## 根因

- **d5_frontmatter**: spec-39 frontmatter 规范引入 `last_manual_edit`/`source`/`load_when` 字段后, 既有 `derived-manual`/`manual` 文件未批量补字段
- **d3_count_drift**: 文档中硬编码计数 (如 "10 个 Y/N 矩阵") vs 实际计数 (动态变化) 漂移; sync_ai_memory.py 自动统计后未同步文档; 检查器 regex 误匹配 commit hash 中的数字
- **d2_bloat**: fixed.md 多 spec 修复追加未拆分; spec41 plan 文件完成后未归档

## 影响

- P1 不阻塞飞轮读侧 (P0=0 已解锁), 但影响 doc_health_check 整体健康度 (97 issues)
- AI 读 frontmatter 缺字段时无法判断 maintainer 模式, 可能误用
- d3_count_drift 误匹配 commit hash 是检查器 regex 缺陷 (false positive)
