# spec36 — scheduler/data 风格归一 (#17/19/20/21/24)

**Date**: 2026-07-19
**Scope**: TD-259 #17/19/20/21/24 (P2/P3) — scheduler/data 层风格归一
**Type**: Backend model 风格修复

## Problem

5 项 TD-259 维度⑦ 数据层风格不一致问题:
- #17 [P2] TaskExecution.agent FK 缺 blank=True
- #19 [P2] TaskExecution 缺 db_table 显式定义
- #20 [P2] GameAccountRotation.owner FK on_delete=CASCADE + null=True 语义矛盾
- #21 [P2] scheduler 4 model 用 plain list choices 不是 TextChoices
- #24 [P3] scheduler 3 model 缺 updated_at

## Solution

### #17/19/20/24 — 补标已修 (批 2 阶段已修复，active.md 漏标)

通过 grep + Read 确认:

- **#17**: `tasks/models.py` line 219-227 — agent FK 已含 `blank=True` (与 device/triggered_by FK 一致)
- **#19**: `tasks/models.py` line 364-365 — `db_table = 'tasks_taskexecution'` 已存在
- **#20**: `scheduler/models.py` line 41-49 — owner FK 已改为 `on_delete=models.SET_NULL, null=True, blank=True, default=None`
- **#24**: `scheduler/models.py` 7 model 全部含 `updated_at` — GameAccountRotation (line 51) / PreflightCheck (line 101) / RecoveryLog (line 141) / TimeWindow (line 171) / WarmupConfig (line 212) / AutoStopCondition (line 264) / UnattendedSession (line 373)

### #21 — plain list choices → TextChoices (本次修改)

修改 `scheduler/models.py` 3 处:

#### 1. WarmupConfig.FAILURE_STRATEGY_CHOICES → FailureStrategy(TextChoices)

```python
class FailureStrategy(models.TextChoices):
    SKIP_DEVICE = 'skip_device', '跳过该设备'
    RETRY_THEN_SKIP = 'retry_then_skip', '重试后跳过'
    ABORT_ALL = 'abort_all', '中止全部'
```

#### 2. AutoStopCondition.CONDITION_TYPE_CHOICES → ConditionType(TextChoices)

```python
class ConditionType(models.TextChoices):
    CONSECUTIVE_FAILURES = 'consecutive_failures', '连续失败 N 次'
    DEVICE_OFFLINE = 'device_offline', '设备离线超过 N 分钟'
    ALL_COMPLETED = 'all_completed', '所有账户均已执行完毕'
    WINDOW_END = 'window_end', '时间窗口结束'
    MANUAL_STOP = 'manual_stop', '手动停止'
    RESOURCE_INSUFFICIENT = 'resource_insufficient', '资源包不足'
```

#### 3. AutoStopCondition.ACTION_CHOICES → Action(TextChoices)

```python
class Action(models.TextChoices):
    STOP_ALL = 'stop_all', '停止所有'
    STOP_DEVICE = 'stop_device', '仅停止该设备'
    NOTIFY_CONTINUE = 'notify_continue', '发送通知并继续'
```

### 兼容性

- String 值不变 (`'skip_device'`, `'consecutive_failures'`, `'stop_all'` 等) — DB 数据无需迁移
- `engine.py` 业务代码引用 string 字面值 (如 `failure_strategy == 'abort_all'`、`condition_type == 'consecutive_failures'`) — 仍兼容
- `get_*_display()` 方法 — TextChoices 与 plain list 行为一致
- `admin.py` `list_filter` — 兼容

### 范围澄清

原 TD-259 #21 描述 "scheduler 4 model"，实际核查后:
- 4 model 已是 TextChoices (GameAccountRotation.Strategy / PreflightCheck.CheckType+Status / RecoveryLog.Level / UnattendedSession.Status)
- 2 model 仍用 plain list (WarmupConfig / AutoStopCondition)
- 实际修改 3 处 choices (WarmupConfig 1 处 + AutoStopCondition 2 处)

## Verification

### Migration check
```
conda run -n gaf python manage.py makemigrations --check --dry-run
```
**Result**: ✅ "No changes detected" (TextChoices 与 plain list 在 DB schema 层等价，choices 元数据在 migration 中已存为相同 tuple list)

### Unit tests
```
conda run -n gaf python -m pytest scheduler/tests/ --tb=short -q
```
**Result**: ✅ 138 passed in 32.06s

## Performance (N171)

| Command | Time | Baseline | Status |
|---------|------|----------|--------|
| `makemigrations --check` | ~2s | < 1s | ✅ acceptable (conda run overhead) |
| `pytest scheduler/tests/` | 32.06s (tests) / 39.09s (total) | < 30s | ✅ acceptable (138 tests) |

## Files Changed (2 files)

1. `backend/scheduler/models.py` — 3 处 plain list → TextChoices (WarmupConfig.FailureStrategy + AutoStopCondition.ConditionType + AutoStopCondition.Action)
2. `docs/general/tech-debt/active.md` — #17/19/20/21/24 标 ✅ FIXED + TD-259 进度行 + 顶部清单行 (29→34 项闭环)
