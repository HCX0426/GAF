---
task: TD-070 fix antd deprecated Alert.message / Drawer.width props
date: 2026-07-09
---

# Solution

Replaced all deprecated props according to antd v5 migration guidance.

## Changes

### `Alert.message` → `Alert.title`

- `frontend/src/components/Settings/SecuritySettings.tsx`
  - L144: TOTP setup info alert
  - L183: TOTP disable warning alert
- `frontend/src/pages/AI/AiConfigPage.tsx`
  - L300: LLM connection test result alert
- `frontend/src/pages/Ops/Logs/LogCenterPage.tsx`
  - L213: Unified timeline tab hint alert
  - L461: Real-time entries banner alert
- `frontend/src/pages/Ops/Monitors/index.tsx`
  - L916: Diagnose fix-success alert
  - L919: Diagnose fix-failed alert

### `Drawer.width` → `Drawer.size`

- `frontend/src/pages/Ops/Logs/LogCenterPage.tsx`
  - L492: Log detail drawer `width={560}` → `size={560}`

## Why not a minimal page-only fix?

Following N150 "从整体框架看问题", a global `message\s*=` grep was run across `.tsx` files to catch all instances rather than only the page where the warning was first observed.
