---
task: TD-070 fix antd deprecated Alert.message / Drawer.width props
date: 2026-07-09
---

# Verification

## Static checks

| Check | Command | Result |
|-------|---------|--------|
| TypeScript compile | `cd frontend && npx tsc --noEmit -p tsconfig.json` | ✅ exit 0, no errors |

## Browser checks

Script: `.trash/check_antd_deprecation.py` (Playwright, headless)

| Page | antd Alert warnings | antd Drawer warnings | console errors |
|------|--------------------:|---------------------:|---------------:|
| `/ops/logs` | 0 | 0 | 0 |
| `/ops/monitors` | 0 | 0 | 0 |
| `/system/settings` | 0 | 0 | 0 |
| `/ai/config` | 0 | 0 | 0 |

## Global deprecation grep (post-fix)

```powershell
# Alert.message usages
PS> grep -n "message\s*=" frontend/src -r --include="*.tsx"
# Result: only App.tsx AntApp message config + non-Alert usages (Form rules, ws onmessage, etc.)

# Drawer.width usages
PS> grep -n "<Drawer" -A5 frontend/src -r --include="*.tsx"
# Result: no direct `width=` prop on Drawer components
```

All identified `Alert.message` and `Drawer.width` usages have been migrated.
