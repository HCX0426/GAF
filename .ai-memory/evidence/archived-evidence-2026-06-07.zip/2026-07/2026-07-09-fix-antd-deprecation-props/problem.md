---
task: TD-070 fix antd deprecated Alert.message / Drawer.width props
date: 2026-07-09
---

# Problem

Browser console showed antd deprecation warnings on several pages:

- `[antd: Alert] 'message' is deprecated. Please use 'title' instead.`
- `[antd: Drawer] 'width' is deprecated. Please use 'size' instead.`

These warnings were first noticed on `/ops/logs` (LogCenterPage) during the N152 pagination fix verification, but a global grep revealed the same `Alert.message` pattern in multiple other files.

## Affected files/lines

| File | Occurrence | Deprecated prop |
|------|------------|-----------------|
| `frontend/src/components/Settings/SecuritySettings.tsx` | 2 × Alert | `message` |
| `frontend/src/pages/AI/AiConfigPage.tsx` | 1 × Alert | `message` |
| `frontend/src/pages/Ops/Logs/LogCenterPage.tsx` | 2 × Alert + 1 × Drawer | `message` / `width` |
| `frontend/src/pages/Ops/Monitors/index.tsx` | 2 × Alert | `message` |

## Impact

- Console noise makes real errors harder to spot.
- Future antd major versions may remove the deprecated props, causing runtime failures.
