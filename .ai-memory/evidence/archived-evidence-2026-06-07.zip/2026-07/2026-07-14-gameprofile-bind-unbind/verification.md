---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-14-gameprofile-bind-unbind/
load_when: [evidence, 3-step-evidence]
priority: high
symptom: [gameprofile-bind-ui-verified, playwright-0-console-errors, drf-action-verified]
solution: Verification — Playwright UI 检查通过 + 0 console errors + 后端 API 测试通过
related_files:
  - backend/gamestate/views.py
  - frontend/src/pages/GameProfiles/components/BindResourceModal.tsx
created_by: AI
last_updated: 2026-07-14
---
## Verification（验证）

$ conda run -n gaf python manage.py check
预期：System check identified no issues (exit 0)

$ Invoke-WebRequest -Uri "http://127.0.0.1:8000/api/v2/gamestate/game-profiles/1/bind-task/" -Method POST -Body '{"task_id":1}' -Headers @{Authorization="Bearer $token"} -ContentType "application/json"
预期：200 OK，返回 Task serializer 数据，task 出现在 profile 的 tasks 列表

$ Invoke-WebRequest -Uri "http://127.0.0.1:8000/api/v2/gamestate/game-profiles/1/unbind-task/" -Method POST -Body '{"task_id":1}' -Headers @{Authorization="Bearer $token"} -ContentType "application/json"
预期：200 OK，task 从 profile 的 tasks 列表移除

$ conda run -n gaf python .trash/test_bind_ui.py
预期：exit 0
- All 4 tabs render bind UI (任务/任务链/账户 + 添加按钮，资源包 Alert)
- BindResourceModal opens/closes correctly on all 3 bind tabs
- Console errors: 0
- All UI checks PASSED

实际结果（2026-07-14）：
- manage.py check: passed
- bind-task API: 200 OK ✅
- unbind-task API: 200 OK ✅
- Playwright UI: exit 0, Console errors: 0, All UI checks PASSED ✅
