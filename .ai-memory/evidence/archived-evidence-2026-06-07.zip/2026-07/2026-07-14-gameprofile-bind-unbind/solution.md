---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-14-gameprofile-bind-unbind/
load_when: [evidence, 3-step-evidence]
priority: high
symptom: [gameprofile-bind-unbind-solution, drf-action, bind-modal]
solution: Solution — 6 个 DRF @action 端点 + BindResourceModal + 3 个 Tab 加按钮 + ResourcePacksTab 只读说明
related_files:
  - backend/gamestate/views.py
  - frontend/src/api/gameProfiles.ts
  - frontend/src/pages/GameProfiles/components/BindResourceModal.tsx
  - frontend/src/pages/GameProfiles/components/TasksTab.tsx
  - frontend/src/pages/GameProfiles/components/TaskChainsTab.tsx
  - frontend/src/pages/GameProfiles/components/AccountsTab.tsx
  - frontend/src/pages/GameProfiles/components/ResourcePacksTab.tsx
  - frontend/src/i18n/locales/gameProfiles.ts
created_by: AI
last_updated: 2026-07-14
---
## Solution（解决步骤）

1. 后端 `backend/gamestate/views.py` 新增 6 个 `@action(detail=True, methods=['post'])` 端点（bind-task / unbind-task / bind-task-chain / unbind-task-chain / bind-account / unbind-account），共享 `_bind_child` / `_unbind_child` 辅助方法验证所有权
2. 前端 `frontend/src/api/gameProfiles.ts` 新增 6 个对应 API 函数
3. 新建 `frontend/src/pages/GameProfiles/components/BindResourceModal.tsx`：搜索式 Select 选择未绑定资源 → 调用 bind API
4. TasksTab / TaskChainsTab / AccountsTab：顶部加"+ 添加"按钮（打开 BindResourceModal），操作列加"解绑"按钮（Popconfirm 确认）
5. ResourcePacksTab：加 Alert 只读说明（资源包绑 Account 不绑 Profile，架构 §3.2）
6. i18n `frontend/src/i18n/locales/gameProfiles.ts`：4 语言（zh-CN/en-US/ja-JP/ko-KR）新增 20+ key
