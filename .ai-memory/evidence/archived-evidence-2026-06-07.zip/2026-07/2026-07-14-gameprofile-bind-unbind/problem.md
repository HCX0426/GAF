---
maintainer: manual
source: GAF/.ai-memory/evidence/2026-07-14-gameprofile-bind-unbind/
load_when: [evidence, 3-step-evidence]
priority: high
symptom: [gameprofile-detail-readonly, no-bind-ui, bind-unbind-missing]
solution: GameProfile 详情页 4 个 Tab（任务/任务链/账户/资源包）只读，无法绑定/解绑子资源；用户必须导航到每个子资源独立页面才能修改 game_profile FK
related_files:
  - backend/gamestate/views.py
  - frontend/src/pages/GameProfiles/components/TasksTab.tsx
  - frontend/src/pages/GameProfiles/components/BindResourceModal.tsx
created_by: AI
last_updated: 2026-07-14
---
## Problem（症状 / 触发条件）

GameProfile 详情页（`/game-profiles/:id`）的 4 个 Tab 只显示子资源列表，
没有"+ 添加"或"解绑"按钮。用户反馈："我怎么加任务链啊，资源包啊等等，
你能通过界面加上去？" — 必须导航到每个子资源的独立页面才能修改绑定关系，
体验割裂。架构上 GameProfile 是聚合根，子资源通过 FK `game_profile` 指向它，
详情页应负责管理绑定/解绑。
