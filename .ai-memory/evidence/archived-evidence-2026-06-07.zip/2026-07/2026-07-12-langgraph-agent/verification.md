---
maintainer: manual
source: GAF/.ai-memory/evidence/templates/
load_when: [evidence, 3-step-evidence, 反思, 写教训]
priority: high
symptom: [kb:evidence-template, 3-step-template, verification-step, evidence-verification]
solution: Verification for LangGraph ReAct agent feature — API tests, TSC, Playwright E2E
related_files:
  - backend/ai/agent/views.py
  - backend/ai/agent/graph.py
  - frontend/src/pages/AI/LogAnalysisPanel.tsx
created_by: AI
last_updated: 2026-07-12
---
## Verification（验证）

### V1: Backend migration applied

$ cd backend && conda run -n gaf python manage.py showmigrations ai
预期：[X] 0003_agent_session

### V2: API endpoint — missing execution_id returns 400

$ Invoke-WebRequest -Uri "http://localhost:8000/api/v2/ai/agent/analyze/" -Method POST -Headers @{Authorization="Bearer $token"} -ContentType "application/json" -Body '{}' -UseBasicParsing
预期：400 Bad Request, {"error":"execution_id is required"}

### V3: API endpoint — non-existent execution returns 404

$ Invoke-WebRequest -Uri "http://localhost:8000/api/v2/ai/agent/analyze/" -Method POST -Headers @{Authorization="Bearer $token"} -ContentType "application/json" -Body '{"execution_id":999999}' -UseBasicParsing
预期：404 Not Found

### V4: API endpoint — real call returns 200 with reasoning chain

$ Invoke-WebRequest -Uri "http://localhost:8000/api/v2/ai/agent/analyze/" -Method POST -Headers @{Authorization="Bearer $token"} -ContentType "application/json" -Body '{"execution_id":63}' -UseBasicParsing
预期：200 OK, response contains: session_id, status, model_used, reasoning_steps[], summary, suggestions[], total_tokens

实测：AgentSession #1 已保存到 DB，model_used 反映实际 LLM（本地 Qwen2.5-7B 不支持 function calling，reasoning_steps 回落到 fallback 解析；不崩溃，错误优雅处理）

### V5: Frontend TypeScript compiles

$ cd frontend && npx tsc --noEmit
预期：0 errors

实测：0 errors（LogAnalysisPanel.tsx 新增 AgentAnalysisResult + Timeline + 深度分析按钮均通过类型检查）

### V6: Playwright E2E — login + navigate to log analysis

$ conda run -n gaf python scripts/e2e/run_all.py browser_login
预期：浏览器登录成功，0 console errors

实测扩展验证：
- 页面 http://localhost:5173/ai/log-analysis 加载成功
- "深度分析" 按钮 (ThunderboltOutlined, red) 已渲染
- "分析" 按钮已渲染
- 0 console errors

### V7: Pre-commit hooks pass

$ git commit -F .trash/_commit_msg.txt
预期：pre-commit hooks 全部通过（session active + evidence dir 存在 + 3-step-evidence 校验通过）
