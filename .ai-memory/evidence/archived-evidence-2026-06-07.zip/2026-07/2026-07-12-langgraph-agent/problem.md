# Problem: LangGraph ReAct Agent for Deep Log Analysis

## Context
GAF needs an AI agent that can autonomously diagnose execution failures by
calling tools (get execution detail, get steps, search similar errors, get
task config) in a multi-turn ReAct loop, rather than the single-shot LLM
call in the existing execution_analysis_view.

## Requirement
- LangChain + LangGraph integration for ReAct pattern
- Multi-level LLM fallback (preferred → backup → local) via .with_fallbacks()
- AgentSession model for Memory / reasoning chain persistence
- POST /api/v2/ai/agent/analyze/ endpoint (manual trigger)
- Frontend: "深度分析" button + reasoning chain Timeline display
