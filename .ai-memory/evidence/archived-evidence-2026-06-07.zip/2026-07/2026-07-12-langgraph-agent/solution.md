# Solution: LangGraph ReAct Agent

## Architecture
- `backend/ai/agent/llm_adapter.py` — builds ChatOpenAI with .with_fallbacks()
  reading GAF's LLMConfig DB + LLM_BACKUP_* + LLM_LOCAL_* env (3 levels, no offline)
- `backend/ai/agent/tools.py` — 4 @tool functions wrapping TaskExecution/TaskStep/Task
- `backend/ai/agent/graph.py` — build_log_analysis_agent() using create_react_agent
- `backend/ai/agent/models.py` — AgentSession (messages, reasoning_steps, summary, etc.)
- `backend/ai/agent/views.py` — POST endpoint: invoke agent, extract reasoning chain,
  parse final JSON, save to AgentSession
- `backend/ai/models.py` — re-export AgentSession with app_label='ai' for Django discovery
- `backend/ai/urls.py` — path('agent/analyze/', ...)

## Frontend
- `frontend/src/api/ai.ts` — AgentAnalysisResult interface + analyzeExecutionWithAgent()
- `frontend/src/pages/AI/LogAnalysisPanel.tsx` — "深度分析" button + reasoning chain Timeline
- `frontend/src/i18n/locales/ailab.ts` — 11 new keys x 4 locales

## Dependencies
- langchain 1.3.13, langgraph 1.2.9, langchain-openai 1.3.5, langchain-core 1.4.9
