# N94 SKILL.md 分发修复 evidence (2026-06-15)

> 本次 commit 是 N94 修复, 3 步 evidence inline 在此文件。

## Problem（症状 / 触发条件）

用户反馈："`d:\Programming\AUTO_PROJECTS\GAF\.trae\skills` 这里的是不是要复制到 `d:\Programming\AUTO_PROJECTS\.trae\skills` 下,目前 gaf 是在一个大项目文件夹中,你放在小的他好像识别不到"

**根因**:
- Trae IDE 只扫描 workspace 根的 `.trae/skills/`,不递归扫描子目录
- AI 把 4 份决策树 SKILL.md 副本放在 `GAF/.trae/skills/{name}/SKILL.md`(GAF 仓库内)
- IDE 看不到 → 决策树触发不了 → M0 投入价值丢失
- AI 缺自动分发机制,让用户手动复制 5 个文件(违反 N93)

## Solution（修复方案）

1. **手动复制 5 个文件到 workspace 根** (即时修复):
   - `_shared/decision-tree.md`
   - `gaf-orchestrator/SKILL.md`
   - `gaf-knowledge-base/SKILL.md`
   - `gaf-task-execution/SKILL.md`
   - `gaf-reflect-and-evolve/SKILL.md`

2. **sync_decision_tree.py v8.4 双根同步** (长期机制):
   - `detect_workspace_root()` 自动检测 (gaf-dev-workflow 标记文件)
   - 默认行为: 同时同步仓库内 4 份 + workspace 根 4 份
   - `--workspace-root <path>` 显式指定
   - `--workspace-root none` 禁用

3. **gaf_init.sh 验证清单加项** (N94 强制):
   - 输出: `🌳 SKILL.md 决策树分发: 仓库内 4/4   workspace 根 4/4`
   - 不齐时自动跑 `sync_decision_tree.py` 修复

4. **failure-modes.md N94 + ai-lessons #26** (永久记录):
   - 触发条件 / 检测 / 根因 / 兜底 / 预防
   - 关联 N93(同根因: AI 不擅长"分发到哪"判断)

## Verification（验证）

```bash
# 验证 1: 仓库内 4 份 SKILL.md
ls GAF/.trae/skills/gaf-*/SKILL.md | wc -l
# 预期: 4

# 验证 2: workspace 根 4 份 SKILL.md (Trae IDE 识别)
ls D:/Programming\AUTO_PROJECTS/.trae/skills/gaf-*/SKILL.md | wc -l
# 预期: 4

# 验证 3: 8 份决策树 hash 一致 (sync_decision_tree.py --check)
python GAF/scripts/sync_decision_tree.py --check
# 预期: ✅ 8 份 SKILL.md 决策树一致 (hash: 571ec826b6e725c4)
#       workspace 根: D:\Programming\AUTO_PROJECTS

# 验证 4: gaf_init.sh 输出双根状态
bash GAF/scripts/gaf_init.sh 2>&1 | grep "SKILL.md 决策树分发"
# 预期: 🌳 SKILL.md 决策树分发: 仓库内 4/4   workspace 根 4/4
```

**结果**:
- ✅ 4+4 = 8 份副本已就位
- ✅ hash 571ec826b6e725c4 一致
- ✅ workspace 根自动检测到 D:\Programming\AUTO_PROJECTS
- ✅ 用户主动操作: 0 (分发自动化 + 自动验证)

**学习**:
- AI 不擅长"我要分发到哪"的判断 → 分发操作必须自动化
- 同一反模式(N93+N94)都出在"分发"环节 → 根因相同,统一解决
- 反思环节必查项加: "AI 写的文件,Trae IDE 看得见吗？"
