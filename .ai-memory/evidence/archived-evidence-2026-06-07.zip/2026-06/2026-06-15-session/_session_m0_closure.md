# M0 闭环验证 evidence（2026-06-15）

> 本次 commit 是知识库 bootstrap 阶段，不是新功能代码交付。
> 3 步 evidence inline 在此文件（按 check_3step_evidence.py 注释允许的 inlined 模式）。

## Problem（症状 / 触发条件）

M0 闭环验证暴露 2 个反模式：

1. **N92 CJK 乱码** — PowerShell 5 (cp936/cp437) 下，5 个 CLI check 脚本输出 mojibake：
   - `✅ → 鉁?`
   - `含 5 个 → 鍚?5 涓?`
2. **N93 AI 强制用户操作** — 用户反馈"这次实现很多时候都需要我主动点击运行"：
   - 写完代码后输出"请手动跑 `pip install pre-commit`"
   - 写完验证后输出"请执行 `bash gaf_init.sh`"
   - 引入新工具后让用户跑 `pip install`

## Solution（修复方案）

**N92 3 层全覆盖**：

1. **Layer 1 (Python 端)** — 创建 `_encoding_safe.py` + 5 个 CLI 脚本首行 `import _encoding_safe`
2. **Layer 2 (Bash 端)** — `gaf_init.sh` 头部 `export PYTHONIOENCODING=utf-8` + `export LC_ALL=C.UTF-8`
3. **Layer 3 (PowerShell 5 端 — 🆕 发现)** — 创建 `gaf_capture.ps1` helper，绕过 PS5 native command stdout 解码 bug（用 `> file` 重定向 + `Get-Content -Encoding UTF8` 读取）

**N93 全面自动化**：

1. `gaf_init.sh v8.4` 全面自包含：自装 `pre-commit` + 自跑 `pre-commit install` + 自 `sync_ai_memory` + 自 `sync_decision_tree --check` + 自 `check_session_active --create`
2. spec.md §14.5 加硬约束条款 7："AI 必须自跑所有验证命令，禁止把命令甩给用户"
3. gaf-dev-workflow §3.2 反思清单加"X/Y 比例"必查项
4. failure-modes.md 新增 N92 + N93 entry（根因 + 3 步兜底 + 预防规则）
5. ai-lessons/architecture-mistakes.md 新增 #24 + #25（AI 被动执行 + CJK 静默回归）

## Verification（验证）

```bash
# 验证 1: gaf_capture.ps1 解决 N92 Layer 3
powershell -ExecutionPolicy Bypass -File GAF\scripts\gaf_capture.ps1 -Command "python GAF/scripts/sync_ai_memory.py" -Head 3
# 预期: ✅ sync_ai_memory: regenerated=0 skipped=8 warning=6 （中文不乱码）

# 验证 2: gaf_init.sh 全面自包含（用户 0 操作）
bash GAF/scripts/gaf_init.sh
# 预期: 输出 "✅ gaf_init 完成,AI 可直接开始工作,无需用户操作"
#       末尾清单 5 项全 ✅ (pre-commit / KB sync / decision tree / session / encoding)

# 验证 3: 5 CLI 脚本 import _encoding_safe
python -c "import sys; sys.path.insert(0, r'GAF/scripts'); import _encoding_safe; print('✅ _encoding_safe 加载')"
# 预期: ✅ _encoding_safe 加载

# 验证 4: pre-commit 6 hooks 全过
pre-commit run --all-files
# 预期: 6 个 GAF hooks 全 Passed

# 验证 5: failure-modes N92/N93 写入
grep -c "^### N" GAF/.ai-memory/meta/failure-modes.md
# 预期: 至少 11 (N1-N8 + N91 + N92 + N93)
```

**结果**: 全部 5 项验证通过 → N92+N93 已闭环。

**用户主动操作次数**: 0 (gaf_init.sh 自跑全部依赖)
**中文乱码**: 0 (3 层 UTF-8 全覆盖)
