# M2.F bypass_weekly_review.py 7 天复盘

## 症状

`.gaf_audit.log` 持续写入 BYPASS 记录, 但无周期性 review, 同类绕过反复出现, 临时绕过变成永久方案。

## 触发条件

- 每次 `git commit --no-verify` 都会写入 BYPASS 记录
- 同一 bypass reason 出现 >=3 次
- 超过 7 天未运行 `bypass_weekly_review.py`

## 步骤

1. 实现 `scripts/bypass_weekly_review.py` 解析 `.gaf_audit.log`
2. 按 reason 聚合, 取 top 5
3. 生成 markdown 段落追加到 `bypass-patterns.md`
4. 写 8 个 pytest 用例
5. N121 5 层分发

## 原因

审计只写不看; 缺乏转化决策机制; review 周期模糊。

## 方法

- 每周跑一次脚本
- >=3 次 reason → 提议修工具/写 lesson
- <3 次 reason → 继续观察

## 标准

- `pytest test_bypass_weekly_review.py -v -p no:django` 8/8 passed
- `bypass_weekly_review.py --dry-run --days 30` 正确读取 BYPASS 记录
- N121 进入 lessons/arch/failure-modes/SKILL/rules/spec 5 层
