## 症状

`conda run -n gaf python script.py` 和 `git log --oneline -20` 在 PowerShell 5 环境下卡死，用户必须手动结束命令 AI 才能继续。

## 触发条件

- AI 跑 `git log` / `git diff` / `git show` 默认走 pager (less/winpty)，TraeAI 终端被识别为 interactive，等用户按 q
- AI 跑 `conda run -n gaf python long_script.py` 默认 `blocking=true`，脚本输出大 / 交互等待
- AI 跑 `pytest tests/` / `pip install torch` 等长命令不设 `wait_ms_before_async`

## 步骤

1. 跑 `git log --oneline -20` 在 PowerShell 5 → 卡 pager
2. 跑 `conda run -n gaf python scripts/sync_ai_memory.py` → 卡 5min+ 输出缓冲
3. 用户反馈 "总要让我自己结束你才能继续"
4. AI 反思 N119 命令模式治理缺位

## 原因

- **git pager**: PowerShell 5 + TraeAI 终端被 git 识别为 interactive，自动走 less/winpty
- **python blocking**: `RunCommand` 工具默认 `blocking=true` 等命令完成，长命令用户等不及
- **`wait_ms_before_async=0` 默认**: 拿不到输出就傻等，用户必须手动结束

## 方法

1. **git 命令默认加 `--no-pager`**: `git --no-pager log --oneline -20`
2. **长命令 `blocking=false`**: `pytest tests/` + `blocking=false` + `wait_ms_before_async=60000`
3. **`wait_ms_before_async` 显式设档位**: 5/15/30/60/120s 按命令类型选
4. **轮询用 `CheckCommandStatus`**: 超预期 `StopCommand` 杀后台进程
5. **conda run 必加 `-n gaf`**: 环境隔离
6. **PYTHONIOENCODING=utf-8**: 防 PowerShell 5 GBK 编码错

## 标准

- ✅ `git log --oneline -20` 用 `git --no-pager` 不卡
- ✅ `conda run -n gaf python long_script.py` 用 `blocking=false` + `wait_ms_before_async=30000` + 轮询
- ✅ 用户从不需要手动结束命令
- ✅ `project_rules.md §5.9` N119 4 原则 + 档位表 + 正确模式 vs 反模式
- ✅ 17/17 e2e 测试通过 (含 N91 14 hook 映射 + N119 引用)
