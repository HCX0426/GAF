---
maintainer: manual
source: runtime verification
symptom: [ui:loading-spinner, ui:tabs-overflow, agent:ldplayer-screenshot-method]
solution: Playwright UI assertions + API test-screenshot + DB read confirm all fixes
related_files:
  - .trash/verify_device_ui.py
  - .trash/device_detail_verify.png
---
## Verification（验证）

1. Start backend and frontend:
```powershell
# backend (port 8000)
cd GAF/backend && conda run -n gaf python manage.py runserver
# frontend (port 5174 because 5173 was occupied)
cd GAF/frontend && npm run dev
```

2. Run Playwright UI verification:
```powershell
conda run -n gaf python GAF/.trash/verify_device_ui.py
```

Actual output:
```
✅ screenshot_method: ld_opengl
✅ tabs flex-wrap: nowrap, width=662px, overflow-btn=1
✅ DeviceOperationPanel title shows static ToolOutlined
📸 screenshot saved: d:/code/AUTO_PROJECTS/GAF/.trash/device_detail_verify.png
✅ all UI assertions passed
```

3. Trigger test-screenshot API for LDPlayer-5555 (device id=8):
```powershell
$body = @{ username='admin'; password='admin123' } | ConvertTo-Json -Compress
$r = Invoke-WebRequest -Uri "http://localhost:8000/api/v2/accounts/auth/login/" -Method POST -Body $body -ContentType "application/json" -UseBasicParsing
$token = ($r.Content | ConvertFrom-Json).access
Invoke-WebRequest -Uri "http://localhost:8000/api/v2/agents/devices/8/test-screenshot/" -Headers @{Authorization="Bearer $token"} -UseBasicParsing
```

Actual response:
```json
{
  "success": true,
  "screenshot_method": "ld_opengl",
  "fps": 34,
  "resolution": {"width": 1318, "height": 754},
  "screenshot_base64": "<449316 chars>"
}
```

4. Read device record to confirm persistence:
```powershell
Invoke-WebRequest -Uri "http://localhost:8000/api/v2/agents/devices/8/" -Headers @{Authorization="Bearer $token"} -UseBasicParsing
```

Actual output:
```
id=8 name=LDPlayer-5555 screenshot_method=ld_opengl screenshot_fps=34
```

Expected: method persists as `ld_opengl`, tabs render in single line, loading icon is static when idle.
Result: all assertions passed.
