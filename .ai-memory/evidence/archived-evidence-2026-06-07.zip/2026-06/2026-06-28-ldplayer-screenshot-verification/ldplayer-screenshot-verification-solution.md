---
maintainer: manual
source: previous session implementation
symptom: [ui:loading-spinner, ui:tabs-overflow, agent:ldplayer-screenshot-method]
solution: Conditional icon rendering + CSS nowrap + ADB chain returns method name + JPEG format detection + LDOpenGL v1/v2/v3 API
related_files:
  - frontend/src/components/Device/DeviceOperationPanel.tsx
  - frontend/src/styles/components.css
  - backend/agent/platforms/windows/_adb_screenshot.py
  - backend/agent/platforms/windows/ld_opengl.py
  - backend/agents/views.py
---
## Solution（解决步骤）

1. `DeviceOperationPanel.tsx`: render `LoadingOutlined` only when `loading=true`; otherwise render static `ToolOutlined`; add 5s safety timeout via functional `setLoading` update.
2. `components.css`: add `.gaf-tabs-nowrap .ant-tabs-nav-list { flex-wrap: nowrap !important; white-space: nowrap !important; }` and apply the class to the panel `Tabs`.
3. `_adb_screenshot.py`: change `capture()` return type to `(bytes, method_name)` and return the successful method name from the emulator-aware chain.
4. `ld_opengl.py`: expand registry/install-path discovery for LDPlayer 14 and implement v1/v2/v3 `ldopengl64.dll` capture; output JPEG bytes.
5. `agents/views.py`: in `DeviceTestScreenshotView`, detect PNG/JPEG/raw magic bytes and decode JPEG with `cv2.imdecode`; persist `actual_method = adb_method` (falls back to format detection only when chain did not report a method).
