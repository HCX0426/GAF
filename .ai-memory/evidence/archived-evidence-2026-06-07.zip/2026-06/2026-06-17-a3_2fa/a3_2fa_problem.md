---
maintainer: manual
source: A3 二次验证 2FA 实施
load_when: [2fa, totp, auth, login]
priority: high
symptom: [2fa:totp:setup, 2fa:login:temp-token, auth:test:url-drift]
solution: A3 2FA 实现过程中发现 accounts 测试 URL 前缀过时、JWT 黑名单未启用、serializers 导入错误
related_files:
  - backend/accounts/tests/test_accounts.py
  - backend/accounts/tests/test_jwt_refresh.py
  - backend/accounts/tests/test_game_account.py
  - backend/config/settings/base.py
  - backend/accounts/serializers.py
created_by: AI
last_updated: 2026-06-17
---
## Problem（症状 / 触发条件）

1. 运行 `python manage.py test accounts.tests` 时，大量测试返回 404（URL 前缀不匹配）。
2. `test_jwt_refresh.TestTokenBlacklist.test_rotated_token_cannot_be_reused` 期望 401，实际返回 200，旧 refresh token 刷新后未被加入黑名单。
3. `CustomTokenObtainPairSerializer.validate` 中 `from rest_framework.simplejwt.exceptions import AuthenticationFailed` 触发 `ModuleNotFoundError`。
4. 影响范围：accounts 模块全部 45 个测试无法通过，阻塞 A3 2FA 验证。
