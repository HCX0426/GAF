---
maintainer: manual
source: A3 二次验证 2FA 实施
load_when: [2fa, totp, auth, login]
priority: high
symptom: [2fa:totp:setup, 2fa:login:temp-token, auth:test:url-drift]
solution: 修正测试 URL 前缀、启用 JWT 黑名单旋转、修复 serializer 导入路径，并补全 2FA 测试
related_files:
  - backend/accounts/tests/test_accounts.py
  - backend/accounts/tests/test_jwt_refresh.py
  - backend/accounts/tests/test_game_account.py
  - backend/config/settings/base.py
  - backend/accounts/serializers.py
created_by: AI
last_updated: 2026-06-17
---
## Solution（解决步骤）

1. 将 `accounts/tests/*.py` 中所有 `/api/v2/auth/`、`/api/v2/users/`、`/api/v2/init/`、`/api/v2/game/` 修正为 `/api/v2/accounts/*`。
2. 在 `backend/config/settings/base.py` 中将 `SIMPLE_JWT["BLACKLIST_AFTER_ROTATION"]` 从 `False` 改为 `True`。
3. 将 `backend/accounts/serializers.py:330` 的 `from rest_framework.simplejwt.exceptions` 改为 `from rest_framework_simplejwt.exceptions`。
4. 在 `test_accounts.py` 中新增 `Test2FA` 类，覆盖 setup / verify-setup / disable / login-2fa 完整流程。
