---
maintainer: manual
source: A3 二次验证 2FA 实施
load_when: [2fa, totp, auth, login]
priority: high
symptom: [2fa:totp:setup, 2fa:login:temp-token, auth:test:url-drift]
solution: 运行 accounts 测试套件验证修复与 2FA 新功能
related_files:
  - backend/accounts/tests/test_accounts.py
  - backend/accounts/tests/test_jwt_refresh.py
  - backend/accounts/tests/test_game_account.py
  - backend/config/settings/base.py
  - backend/accounts/serializers.py
created_by: AI
last_updated: 2026-06-17
---
## Verification（验证）

```powershell
cd d:\Programming\AUTO_PROJECTS\GAF\backend
$env:PYTHONIOENCODING='utf-8'
conda run -n gaf python manage.py test accounts.tests -v 2
```

预期：

```
Ran 45 tests in 53.458s
OK
```

前端 TypeScript 检查（A3 相关文件无新增错误）：

```powershell
cd d:\Programming\AUTO_PROJECTS\GAF\frontend
npx tsc -b
```

A3 新增/修改文件（SecuritySettings.tsx、SystemSettings/index.tsx、authStore.ts、types/models.ts）未出现在错误列表中。
