---
maintainer: manual
source: (removed — scripts/check_skip_rate.py was deleted)
load_when: [evidence, skip-rate, bypass-monitoring]
priority: medium
symptom: [workflow:bypass-rate, pre-push, threshold]
solution: Bypass rate 10% threshold was too strict during early development and counted all historical commits.
related_files:
  - .pre-commit-config.yaml
created_by: AI
last_updated: 2026-06-17
---

## Problem（症状 / 触发条件）

1. The original bypass rate guard used a 10% threshold over the full commit history.
2. During active development every early commit legitimately used `--no-verify`, so the rate quickly exceeded 10% and blocked pushes.
3. Merge and revert commits were also counted in the denominator, distorting the rate.
