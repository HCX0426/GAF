---
maintainer: manual
source: GAF/scripts/check_skip_rate.py
load_when: [evidence, skip-rate, bypass-monitoring]
priority: medium
symptom: [workflow:bypass-rate, pre-push, threshold]
solution: Verified with unittest and pre-commit config syntax check.
related_files:
  - scripts/tests/test_check_skip_rate.py
  - .pre-commit-config.yaml
created_by: AI
last_updated: 2026-06-17
---

## Verification（验证）

$ conda run -n gaf python -m unittest scripts.tests.test_check_skip_rate -v

Expected:
- Ran 10 tests in ~0.3s
- OK

$ python -c "import yaml; yaml.safe_load(open('GAF/.pre-commit-config.yaml').read())"

Expected:
- Exit 0 (valid YAML)
- `gaf-skip-rate` hook configured with `stages: [pre-push]`
