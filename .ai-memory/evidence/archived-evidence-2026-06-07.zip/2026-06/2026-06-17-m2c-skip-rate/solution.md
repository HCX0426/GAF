---
maintainer: manual
source: (removed — scripts/check_skip_rate.py was deleted)
load_when: [evidence, skip-rate, bypass-monitoring]
priority: medium
symptom: [workflow:bypass-rate, pre-push, threshold]
solution: Implement rolling 30-commit window + 30% threshold + 10-commit warmup + exclude merge/revert/rollback.
related_files:
  - scripts/tests/test_check_skip_rate.py
  - .pre-commit-config.yaml
created_by: AI
last_updated: 2026-06-17
---

## Solution（解决步骤）

1. Create `GAF/scripts/check_skip_rate.py` with `_git_log_commits(window)`, `_filter_effective_commits()`, and `_load_bypass_timestamps()` helpers.
2. Implement `compute_bypass_rate(effective_commits, bypass_ts_list)` to count bypasses whose timestamps fall inside the commit time window.
3. Add CLI flags `--window 30`, `--min-commits 10`, `--threshold 0.30`, and `--dry-run`.
4. Add `gaf-skip-rate` hook to `.pre-commit-config.yaml` with `stages: [pre-push]`.
5. Add 10 unit tests in `GAF/scripts/tests/test_check_skip_rate.py` covering below/at/above threshold, merge/revert exclusion, and malformed audit log lines.
